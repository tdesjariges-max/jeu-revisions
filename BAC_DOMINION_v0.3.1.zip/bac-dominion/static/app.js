'use strict';
const $ = sel => document.querySelector(sel);
const state = {
  profile:null, strategy:null, quests:null, leaderboard:null, quest:null, questResult:null,
  room:null, tab:'strategy', authMode:'register', busy:false, ws:null, wsReady:false,
  target:null, power:'attack', toastTimer:null, reconnectTimer:null, allowReconnect:true,
  lastFinishCode:null, curriculum:null,focusDraft:null,bosses:null,boss:null,bossResult:null,
  kingdoms:null,visiting:null,raid:null,raidResult:null,raidLog:[],dailyDraw:null,story:null,siegeInvite:null,siegeWaiting:null,focusOpen:false
};
const nav=[['strategy','🏰','Royaume'],['party','🎲','Party game'],['arena','⚔️','Arène'],['quests','🧭','RPG solo'],['bosses','🐉','Boss'],['kingdoms','🌍','Royaumes'],['leaderboard','🏆','Classement']];
const buildingIcons={mine:'🪙',sawmill:'🪵',quarry:'🪨',academy:'📚',barracks:'🛡️',wall:'🏯'};
const unitIcons={soldiers:'🛡️',archers:'🏹',mages:'🧙'};
const questIcons={faille:'🗻',valmy:'⚔️',conscience:'🧠',memoire:'📜'};
const E=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=n=>new Intl.NumberFormat('fr-FR').format(n||0);
const costHtml=c=>`<span>🪙 ${fmt(c.gold)}</span><span>🪵 ${fmt(c.wood)}</span><span>🪨 ${fmt(c.stone)}</span>`;
const resourceHtml=p=>`<span class="chip gold">🪙 ${fmt(p.gold)}</span><span class="chip wood">🪵 ${fmt(p.wood)}</span><span class="chip stone">🪨 ${fmt(p.stone)}</span>`;
function toast(msg,error=false){const node=$('#toast');if(!node)return;clearTimeout(state.toastTimer);node.textContent=msg;node.className='toast show'+(error?' error':'');state.toastTimer=setTimeout(()=>node.className='toast',3800)}
async function api(path,data,method){
 const opts={method:method||(data===undefined?'GET':'POST'),credentials:'same-origin',headers:{'Accept':'application/json'}};
 if(data!==undefined){opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(data)}
 let res;try{res=await fetch('/api/'+path,opts)}catch(e){throw new Error('Connexion au serveur impossible.')}
 let out;try{out=await res.json()}catch(e){throw new Error('Réponse du serveur invalide.')}
 if(!res.ok){if(res.status===401&&path!=='login'&&path!=='register'){state.profile=null;render()}
   throw new Error(typeof out.detail==='string'?out.detail:'Une erreur est survenue.')}
 return out;
}
function authView(){
 const create=state.authMode==='register';
 const specs=['SVT','HGGSP','Maths','Physique-chimie','SES','HLP','NSI'];
 const opts=(current)=>specs.map(s=>`<option value="${E(s)}" ${s===current?'selected':''}>${E(s)}</option>`).join('');
 return `<div class="auth">
   <div class="auth-art"><div class="logo"><span class="logo-mark">♛</span>BAC <b>DOMINION</b></div>
   <h1>Ton savoir.<br><span>Ton royaume.</span><br>Ta victoire.</h1>
   <p>Construis une civilisation, affronte tes amis et révise les matières du bac avec des défis rapides. Chaque bonne réponse te rend plus fort.</p>
   <div class="floating-kingdom"><div class="castle-art">🏰</div><div class="art-bubble one">⚔️ Arènes en direct</div><div class="art-bubble two">🧠 Spé = points ×2</div></div></div>
   <div class="auth-form"><div class="caps">Le royaume des savoirs</div><h2>${create?'Créer ton compte':'Bon retour, stratège'}</h2>
   <p>${create?'Tes progrès seront sauvegardés et ajoutés au classement.':'Reconnecte-toi pour retrouver ton royaume et tes ressources.'}</p>
   <form data-form="auth"><div class="field"><label for="username">Pseudo public</label><input id="username" name="username" autocomplete="username" minlength="3" maxlength="18" required placeholder="Ton pseudo"/></div>
   <div class="field"><label for="password">Mot de passe</label><input id="password" name="password" type="password" autocomplete="${create?'new-password':'current-password'}" minlength="8" maxlength="128" required placeholder="8 caractères minimum"/></div>
   ${create?`<div class="form-grid"><div class="field"><label for="spec1">Spécialité 1</label><select id="spec1" name="spec1">${opts('SVT')}</select></div>
   <div class="field"><label for="spec2">Spécialité 2</label><select id="spec2" name="spec2">${opts('HGGSP')}</select></div></div>
   <p class="hint">Les bonnes réponses dans tes deux spécialités rapportent <b style="color:var(--teal)">20 points</b> au lieu de 10.</p>`:''}
   <button class="btn btn-primary btn-block" style="margin-top:18px" ${state.busy?'disabled':''}>${create?'👑 Fonder mon royaume':'🔓 Se connecter'}</button></form>
   <div class="auth-toggle">${create?'Tu as déjà un compte ?':'Pas encore de compte ?'} <button class="text-button" data-action="auth-toggle">${create?'Se connecter':'Créer un compte'}</button></div></div></div>`;
}
function shell(){
 const p=state.profile||{};
 const navHTML=(mobile=false)=>nav.map(([id,emoji,label])=>`<button class="${mobile?'':'nav-btn '}${state.tab===id?'active':''}" data-nav="${id}"><span>${emoji}</span>${label}</button>`).join('');
 return `<div class="shell"><aside class="sidebar"><div class="logo"><span class="logo-mark">♛</span>BAC <b>DOMINION</b></div><div><div class="sidebar-section">Navigation</div><div class="nav">${navHTML()}</div></div>
 <div class="sidebar-foot"><strong>🧠 Astuce révision</strong><p>Les spécialités ${E(p.specialties?.join(' et '))} rapportent deux fois plus de points. Après une erreur, lis toujours l’explication.</p></div>
 <button class="btn btn-secondary" data-action="logout">↪ Déconnexion</button></aside>
 <main class="main"><div class="topbar"><div><div class="welcome">Bienvenue dans ton royaume, <strong>${E(p.username)}</strong></div><div class="caps" style="margin-top:5px">Niveau ${fmt(p.level)} · ${fmt(p.score)} points · 🔥 ${fmt(p.streak)} enchaînées (record : ${fmt(p.best_streak)})</div></div>
 <div class="top-right"><span class="chip purple">✦ ${fmt(p.xp)} XP</span><span class="avatar" title="${E(p.username)}">${E((p.username||'?').slice(0,1).toUpperCase())}</span></div></div>
 <div style="margin-bottom:22px" class="resource-bar"><span class="chip gold">👑 ${fmt(p.prestige)} prestige</span>${resourceHtml(p)}<span class="chip teal">📚 ${E(p.specialties?.join(' + '))}</span><button class="btn btn-secondary btn-tiny" data-action="focus-toggle">🎯 ${E(p.focus?.subject||'Changer de thème')} ▾</button></div>
 ${state.focusOpen&&state.curriculum?focusView():''}
 ${state.siegeInvite?`<div class="panel invite-banner"><div><strong>⚔️ ${E(state.siegeInvite.attacker)} attaque ton royaume !</strong><p class="hint">Accepte pour une bataille de QCM en direct. Si tu refuses, tu ne perds rien.</p></div><button class="btn btn-primary" data-action="siege-accept">Accepter</button><button class="btn btn-secondary" data-action="siege-decline">Refuser</button></div>`:''}
 ${state.siegeWaiting?`<div class="panel invite-banner">⏳ Défi envoyé à <b>${E(state.siegeWaiting.target)}</b> · <button class="btn btn-secondary btn-tiny" data-action="siege-cancel">Annuler</button></div>`:''}
 <div id="page">${page()}</div></main><nav class="mobile-nav" aria-label="Navigation">${navHTML(true)}</nav></div>`;
}
function page(){
 if(state.tab==='strategy')return strategyView();
 if(state.tab==='quests')return questsView();
 if(state.tab==='bosses')return bossesView();
 if(state.tab==='leaderboard')return leaderboardView();
 if(state.tab==='kingdoms')return state.room?.mode==='siege'?roomView(state.room):kingdomsView();
 if(state.tab==='party'||state.tab==='arena')return multiplayerView();
 return '';
}
function strategyView(){
 if(!state.strategy)return '<div class="panel">Chargement du royaume…</div>';
 const s=state.strategy,p=state.profile,allUnits=Object.values(p.army).reduce((a,b)=>a+b,0);
 const buildings=s.buildings.map(b=>`<article class="panel"><div class="building-head"><div class="building-emoji">${buildingIcons[b.id]}</div><div style="flex:1"><div class="card-title">${E(b.name)}</div><div class="small muted">Niveau ${b.level} / ${b.max_level}</div></div><span class="pill">Nv. ${b.level}</span></div>
 <p class="card-description">${E(b.effect)}</p><div class="separator"></div><div class="between"><div class="cost">${b.level<10?costHtml(b.next_cost):'Niveau maximal'}</div>
 <button class="btn btn-secondary btn-tiny" data-action="upgrade" data-id="${b.id}" ${b.level>=10||!afford(b.next_cost)?'disabled':''}>⬆ Améliorer</button></div></article>`).join('');
 const territories=s.territories.map(t=>`<article class="panel territory ${t.owned?'owned':''}"><span class="pill ${t.owned?'':'warn'}">${t.owned?'✓ CONQUIS':'À CONQUÉRIR'}</span><div class="territory-art">${t.icon}</div><div class="card-title">${E(t.name)}</div><div class="hint" style="margin:8px 0">Défense ennemie : ${t.defense} · Route tactique à découvrir</div><div class="cost">${costHtml({gold:t.reward[0],wood:t.reward[1],stone:t.reward[2]})}</div></article>`).join('');
 const units=s.units.map(u=>`<div class="panel"><div class="unit-head"><div class="building-emoji">${unitIcons[u.id]}</div><div><div class="card-title">${E(u.name)}</div><div class="small muted">${fmt(u.owned)} unités · puissance ${u.power}</div></div></div><div class="cost">${costHtml(u.cost)}</div><div class="separator"></div>
 <div class="between"><input style="max-width:85px;padding:8px" type="number" id="amount-${u.id}" value="1" min="1" max="25" aria-label="Quantité de ${E(u.name)}"/><button class="btn btn-primary btn-tiny" data-action="recruit" data-id="${u.id}">+ Recruter</button></div></div>`).join('');
 return `<div class="page-header"><div><div class="eyebrow">Mode principal · stratégie persistante</div><h1>Ton royaume</h1><p>Révise, accumule des ressources, entraîne des troupes et étends ton territoire. Visite aussi les citadelles des autres joueurs.</p></div><button class="btn btn-secondary btn-tiny" data-action="refresh">↻ Actualiser</button></div>
 <div class="between" style="margin:0 0 16px;flex-wrap:wrap"><span class="chip purple">👑 Prestige PvP : ${fmt(p.prestige)}</span><button class="btn btn-primary btn-tiny" data-nav="kingdoms">🌍 Visiter et attaquer des royaumes</button></div>
 <section class="hero"><div class="hero-copy"><div class="eyebrow">Capitale du savoir</div><h2>La Citadelle des Savoirs</h2><p>Chaque partie de quiz renforce ton armée. Tes bâtiments produisent des ressources au fil du temps, même lorsque tu es déconnecté (8 h maximum).</p><div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap"><button class="btn btn-primary btn-tiny" data-nav="party">🎲 Farmer en groupe</button><button class="btn btn-secondary btn-tiny" data-nav="quests">🧭 Missions solo</button></div></div><div class="hero-emoji">🏰</div></section>
 ${dailyView()}<div class="stat-grid"><div class="stat"><div class="caps">Territoires</div><div class="value">${p.territories.length} / 3</div><div class="small">Zones conquises</div></div>
 <div class="stat"><div class="caps">Armée</div><div class="value">${allUnits} / ${s.capacity}</div><div class="small">Unités stationnées</div></div>
 <div class="stat"><div class="caps">Production / h</div><div class="value" style="font-size:18px">🪙${s.rates.gold} · 🪵${s.rates.wood}</div><div class="small">Pierre : ${s.rates.stone} / h</div></div>
 <div class="stat"><div class="caps">Progression</div><div class="value">Niv. ${p.level}</div><div class="small">${fmt(p.xp)} XP accumulés</div><div class="xp-track"><div class="xp-fill" style="width:${Math.min(100,((p.xp%90)/90)*100)}%"></div></div></div></div>
 <div class="section-title"><h2>🏗️ Construire et améliorer</h2><span>6 bâtiments · 10 niveaux</span></div><div class="grid three">${buildings}</div>
 <div class="section-title"><h2>🪖 Former ton armée</h2><span>Les mages exigent Académie niv. 2</span></div><div class="grid three">${units}</div>
 <div class="section-title"><h2>🗺️ Carte des conquêtes</h2><span>3 provinces à libérer</span></div><div class="grid three">${territories}</div>
 <div class="section-title"><h2>⚔️ Expédition tactique</h2><span>Choisis les forces et la tactique</span></div>
 <div class="panel"><form data-form="attack"><div class="grid two"><div class="field"><label>Territoire cible</label><select name="territory">${s.territories.filter(t=>!t.owned).map(t=>`<option value="${t.id}">${E(t.name)} · Défense ${t.defense}</option>`).join('')||'<option value="">Tous conquis</option>'}</select></div>
 <div class="field"><label>Formation</label><select name="formation"><option value="charge">⚔️ Charge frontale</option><option value="flank">🏹 Encerclement</option><option value="defend">🛡️ Défense organisée</option></select></div>
 <div class="field"><label>Itinéraire</label><select name="route"><option value="woods">🌲 Traversée des bois</option><option value="hills">⛰️ Passage des hauteurs</option><option value="bridge">🌉 Pont fortifié</option></select></div><div class="field"><label>Unités envoyées</label><div class="battle-grid"><input name="soldiers" type="number" value="${p.army.soldiers}" min="0" max="${p.army.soldiers}" title="Gardiens" aria-label="Gardiens envoyés"/><input name="archers" type="number" value="${p.army.archers}" min="0" max="${p.army.archers}" title="Archers" aria-label="Archers envoyés"/><input name="mages" type="number" value="${p.army.mages}" min="0" max="${p.army.mages}" title="Mages" aria-label="Mages envoyés"/></div><div class="tiny muted">Dans l’ordre : 🛡️ gardiens · 🏹 archers · 🧙 mages</div></div></div>
 <p class="hint" style="margin:10px 0 16px">Les unités ont des forces différentes. Une formation et un itinéraire adaptés confèrent un avantage tactique ; une défaite entraîne des pertes.</p><button class="btn btn-gold" ${s.territories.every(t=>t.owned)?'disabled':''}>Lancer l’expédition ⚔️</button></form></div>`;
}
function afford(c){if(!state.profile||!c)return false;return ['gold','wood','stone'].every(k=>state.profile[k]>=c[k])}
function focusView(){
 const rows=state.curriculum||[], f=state.focusDraft||state.profile?.focus||{subject:'',theme:'',axis:'',subaxis:''};
 const defs=[['subject','Matière','Toutes les matières'],['theme','Thème','Tous les thèmes'],['axis','Axe','Tous les axes'],['subaxis','Sous-axe','Tous les sous-axes']];
 const names=['subject','theme','axis','subaxis'];
 const selectors=defs.map(([key,label,empty],index)=>{
   const previous=names.slice(0,index);
   const valid=rows.filter(r=>previous.every(k=>!f[k]||r[k]===f[k]));
   const choices=[...new Set(valid.map(r=>r[key]))].sort((a,b)=>a.localeCompare(b,'fr'));
   return `<div class="field"><label for="focus-${key}">${label}</label><select id="focus-${key}" data-focus="${key}" ${index>0&&!f[names[index-1]]?'disabled':''}>
   <option value="">${empty}</option>${choices.map(v=>`<option value="${E(v)}" ${f[key]===v?'selected':''}>${E(v)}</option>`).join('')}</select></div>`;
 }).join('');
 const count=rows.filter(r=>names.every(k=>!f[k]||r[k]===f[k])).reduce((n,r)=>n+r.count,0);
 const selected=state.profile?.focus||{};
 return `<div class="panel focus-panel"><div class="between"><div><h3>🎯 Choisir ce que tu révises</h3><p class="hint" style="margin:5px 0 12px">Sélectionne une matière, puis un thème, un axe et un sous-axe. Le filtre sera sauvegardé dans ton compte et utilisé pour tes entraînements et les salons que tu crées.</p></div><span class="pill">${count} question(s)</span></div>
 <div class="focus-grid">${selectors}</div><div class="between" style="flex-wrap:wrap;margin-top:13px;gap:10px"><span class="hint">${Object.values(selected).filter(Boolean).map(E).join(' › ')||'Thème actuel : toutes matières'}</span>
 <button class="btn btn-secondary" data-action="focus-save" ${!rows.length||!count?'disabled':''}>✓ Enregistrer le thème</button></div></div>`;
}

function dailyView(){
 const d=state.dailyDraw;if(!d)return '';
 const odds=d.odds.map(x=>`${x.rarity} ${x.probability}% (+${x.score} pts)`).join(' · ');
 return `<section class="panel" style="margin-bottom:15px"><div class="between" style="gap:12px;flex-wrap:wrap"><div><h3>🎁 Coffre gratuit du jour</h3><p class="hint">Un seul bonus quotidien, sans mise, sans achat ni objet à collectionner.</p><p class="hint">Probabilités : ${E(odds)}</p></div><button class="btn btn-gold" data-action="daily-draw" ${d.available?'':'disabled'}>${d.available?'✨ Ouvrir le coffre':'✓ Déjà ouvert aujourd’hui'}</button></div></section>`;
}
function storyView(){
 const story=state.story?.chapters;if(!story)return '';
 return `<div class="section-title"><h2>📖 Le récit de Luméria</h2><span>Une aventure fantastique à découvrir</span></div><div class="grid two">${story.map(ch=>`<article class="panel"><div class="building-head"><div class="building-emoji">${ch.icon}</div><div><h3>${E(ch.title)}</h3><div class="small muted">${E(ch.character)}</div></div></div><p style="line-height:1.65;font-size:13px;margin:10px 0">${E(ch.intro)}</p><p class="hint" style="margin:10px 0">🎯 ${E(ch.objective)}</p>${ch.claimed?'<span class="pill">✅ Chapitre terminé</span>':`<button class="btn btn-primary btn-tiny" data-action="story-claim" data-id="${ch.id}" ${!ch.unlocked?'disabled':''}>${ch.unlocked?'Découvrir la suite et obtenir le butin':'🔒 Objectif non atteint'}</button>`}</article>`).join('')}</div>`;
}

function questsView(){
 const q=state.quest;
 if(q&&q.active)return activeQuestView();
 if(!state.quests)return '<div class="panel">Chargement des missions…</div>';
 return `<div class="page-header"><div><div class="eyebrow">Aventure RPG · solo</div><h1>Chroniques du savoir</h1><p>Explore des histoires interactives. 4 questions par mission, corrections pédagogiques et butin.</p></div></div>
 ${state.focusOpen?'':focusView()}<div class="panel" style="margin-bottom:18px"><div class="between" style="flex-wrap:wrap;gap:8px"><div><strong>📚 Entraînement ciblé</strong><p class="hint">4 questions maximum selon ton thème enregistré.</p></div><button class="btn btn-primary" data-action="practice-start">Commencer les révisions →</button></div></div>
 <section class="hero" style="background:linear-gradient(115deg,#283252,#1b2841,#243f4a)"><div class="hero-copy"><div class="eyebrow">Défis narratifs</div><h2>Chaque réponse change ton destin.</h2><p>Traverse les archives, les montagnes et les palais. Réponds aux énigmes pour gagner de l’XP et des ressources pour ton royaume.</p></div><div class="hero-emoji">📜</div></section>
 ${storyView()}<div class="section-title"><h2>🧭 Missions disponibles</h2><span>Prime maximale une fois par jour</span></div><div class="grid two">${state.quests.missions.map(m=>`<article class="panel mission-card"><div class="mission-head"><div class="mission-icon">${questIcons[m.id]||'📚'}</div><div><div class="caps">${E(m.subtitle)}</div><h3>${E(m.name)}</h3></div></div><p>${E(m.story)}</p><div class="cost">Butin : ${costHtml(m.reward)}</div>
 ${state.quests.completed_today.includes(m.id)?'<div class="daily-done">✓ Prime du jour déjà gagnée (rejouable avec butin réduit)</div>':''}
 <button class="btn btn-primary btn-block" data-action="quest-start" data-id="${m.id}">▶ Commencer la mission</button></article>`).join('')}</div>`;
}
function activeQuestView(){
 const q=state.quest;const answer=state.questResult;const item=q.question;
 return `<div class="page-header"><div><div class="eyebrow">Mission RPG · chapitre ${q.step+1} / ${q.total}</div><h1>${E(q.mission==='training'?'Entraînement ciblé':(state.quests?.missions||[]).find(x=>x.id===q.mission)?.name||'Expédition')}</h1><p>Observe les indices, utilise ton cours et prends une décision.</p></div><button class="btn btn-secondary btn-tiny" data-action="quest-abandon">Abandonner</button></div>
 <div class="panel" style="margin-bottom:15px;background:linear-gradient(130deg,#1b3450,#112637)"><span class="eyebrow">📖 Extrait du journal de bord</span><p style="line-height:1.75;color:#d0dfeb;margin-top:12px">${E((state.quests?.missions||[]).find(x=>x.id===q.mission)?.story||'Le chemin est rempli d’énigmes historiques et scientifiques.')}</p></div>
 <div class="quiz-card"><div class="question-heading"><span class="pill purple">${E(item.category)}</span><span class="caps">ÉTAPE ${q.step+1} / ${q.total}</span></div><div class="quiz-question">${E(item.q)}</div><div class="answers">${item.options.map((opt,i)=>`<button class="answer ${answer?(i===answer.correct_index?'correct':(i===answer.choice?'wrong':'')):''}" ${answer||state.busy?'disabled':''} data-action="quest-answer" data-choice="${i}"><b>${'ABCD'[i]}</b> ${E(opt)}</button>`).join('')}</div>
 ${answer?`<div class="answer-note"><div class="correctness">${answer.correct?'✓ Bonne réponse !':'✕ Réponse à retravailler'}</div><p style="margin-top:7px">${E(answer.explanation)}</p><p style="margin-top:8px;color:#f4d297">+ ${answer.earned.score} points · + ${answer.earned.xp} XP · 🔥 série ${answer.earned.streak} (×${answer.earned.multiplier}) ${answer.earned.specialty_bonus?'· BONUS SPÉ ×2':''}</p></div>
 ${answer.finished?`<div class="reward-banner">🏁 Mission terminée · ${answer.correct_count} / ${answer.total} réponses justes<br/>Butin : ${costHtml(answer.reward)}</div>`:''}
 <button style="margin-top:17px" class="btn btn-primary" data-action="quest-next">${answer.finished?'Retour aux missions':'Poursuivre l’aventure →'}</button>`:''}</div>`;
}
function multiplayerView(){
 const mode=state.tab,party=mode==='party',room=state.room;
 const banner=`<div class="page-header"><div><div class="eyebrow">${party?'Mini-jeu coopétitif':'Combat de connaissances'} · 2 à 60 joueurs</div><h1>${party?'La Fête des Érudits':'L’Arène des Esprits'}</h1><p>${party?'Farme des ressources pour ton royaume en répondant avec tes amis.':'Attaque, protège-toi et remporte un duel de savoir en temps réel.'}</p></div></div>
 <div class="mode-banner ${party?'party':''}"><div><div class="eyebrow">${party?'Mode party game':'Mode arène PvP'}</div><h2>${party?'Révise ensemble. Récolte plus.':'Transforme tes réponses en pouvoirs.'}</h2><p>${party?'6 manches de QCM simultanées. Les bonnes réponses te font gagner des ressources à la fin de la partie. Les spécialités offrent davantage de points.':'Choisis ta cible et décide d’attaquer ou de lever un bouclier. Une bonne réponse inflige des dégâts ou te soigne. Les spécialités frappent plus fort.'}</p></div><div class="mode-emoji">${party?'🎲':'⚔️'}</div></div>`;
 if(room&&room.mode===mode)return banner+roomView(room);
 if(room&&room.mode!==mode)return banner+`<div class="panel"><p style="line-height:1.7">Tu es déjà dans un salon <b>${room.mode==='party'?'Party game':'Arène'}</b>. Tu peux revenir sur cet onglet ou quitter le salon.</p><button class="btn btn-secondary" style="margin-top:16px" data-action="leave-room">Quitter le salon ${E(room.code)}</button></div>`;
 return banner+focusView()+`<div class="grid two"><div class="panel"><div class="building-head"><div class="building-emoji">🎟️</div><div><h3>Créer une partie</h3><div class="hint">Tu deviens l’hôte de ton salon</div></div></div><p class="hint" style="margin:15px 0">Un code à 6 caractères sera créé. Envoie-le à tes amis pour qu’ils te rejoignent depuis leur compte.</p><button class="btn btn-primary btn-block" data-action="create-room" ${!state.wsReady?'disabled':''}>+ Créer un salon ${party?'party':'arène'}</button></div>
 <div class="panel"><div class="building-head"><div class="building-emoji">🔑</div><div><h3>Rejoindre un ami</h3><div class="hint">Un code de salon suffit</div></div></div><form data-form="join-room"><div class="field" style="margin:15px 0"><label>Code du salon</label><input name="code" maxlength="6" minlength="6" required style="text-transform:uppercase;letter-spacing:3px;font-weight:800" placeholder="ABC123" /></div><button class="btn btn-secondary btn-block" ${!state.wsReady?'disabled':''}>Rejoindre la partie →</button></form></div></div>
 <div class="section-title"><h2>💡 Comment marquer des points ?</h2></div><div class="grid three"><div class="panel"><div class="card-title">📘 Question générale</div><p class="hint" style="margin-top:9px">Bonne réponse = <b>10 points</b> de classement.</p></div><div class="panel"><div class="card-title">📗 Ta spécialité</div><p class="hint" style="margin-top:9px">Bonne réponse = <b>20 points</b> de classement et XP supplémentaire.</p></div><div class="panel"><div class="card-title">🏆 Fin de partie</div><p class="hint" style="margin-top:9px">Butin de ressources selon le nombre de bonnes réponses.</p></div></div>
 ${!state.wsReady?'<p class="hint" style="margin-top:15px">⚠️ Reconnexion au serveur multijoueur…</p>':''}`;
}
function roomView(room){
 const me=room.players.find(p=>p.id===state.profile.id);const host=room.host===state.profile.id;
 const players=[...room.players].sort((a,b)=>['arena','siege'].includes(room.mode)?b.damage-a.damage||b.hp-a.hp:b.score-a.score);
 const list=players.map((p,i)=>`<div class="score-line"><div class="score-rank">#${i+1}</div><span class="mini-avatar">${E(p.name.slice(0,1).toUpperCase())}</span><div class="score-name">${E(p.name)} ${p.id===room.host?'👑':''} ${p.id===state.profile.id?'(toi)':''}</div><div class="score-meter"><span style="width:${Math.max(4,['arena','siege'].includes(room.mode)?p.hp/140*100:Math.min(100,p.score/(room.total_rounds*20)*100))}%"></span></div><div class="score-score">${['arena','siege'].includes(room.mode)?`${p.hp} PV · ${p.damage} ⚔️`:p.score+' pts'}</div></div>`).join('');
 const mode=room.mode;const result=room.status==='finished';
 const reward=room.rewards?.[String(state.profile.id)];
 return `<div class="grid two" style="align-items:start"><section><div class="panel"><div class="between" style="flex-wrap:wrap"><div><div class="caps">Code de salon</div><div class="room-code">${E(room.code)}</div></div><button class="btn btn-secondary btn-tiny" data-action="copy-code">⧉ Copier</button></div>
 <div class="separator"></div><div class="between"><span class="hint"><span class="online-dot"></span>${room.players.filter(p=>p.online).length} en ligne / ${room.mode==='siege'?2:60} · ${E(room.mode)}</span><span class="pill ${room.status==='playing'?'warn':''}">${room.status==='waiting'?'SALLE D’ATTENTE':room.status==='playing'?'EN JEU':'TERMINÉ'}</span></div>
 <div class="player-list" style="margin-top:15px">${room.players.map(p=>`<span class="player-pill ${p.online?'':'offline'}">${p.id===room.host?'👑 ':''}${E(p.name)}</span>`).join('')}</div>
 <p class="hint" style="margin:12px 0">🎯 Thème du salon : ${E(Object.values(room.focus||{}).filter(Boolean).join(' › ')||'Toutes matières')}</p>
 ${room.status==='waiting'?`<p class="hint" style="margin:17px 0">${host?'Lance la partie dès que 2 joueurs au moins sont présents.':'L’hôte lancera la partie quand tout le monde sera prêt.'}</p>${host?`<button class="btn btn-primary btn-block" data-action="start-room" ${room.players.length<2?'disabled':''}>▶ Démarrer · ${room.players.length} joueur(s)</button>`:''}`:''}
 ${result?`<div class="reward-banner">🏆 Fin de partie !<br/>${room.siege_outcome?`Prestige attaquant : ${room.siege_outcome.attacker_delta>0?'+':''}${room.siege_outcome.attacker_delta} · défenseur : ${room.siege_outcome.defender_delta>0?'+':''}${room.siege_outcome.defender_delta}. Aucun bâtiment ni troupe perdu.`:reward?`Butin gagné : ${costHtml(reward)}`:'Consulte le classement et tes gains.'}</div>`:''}
 <button class="btn btn-secondary btn-block" style="margin-top:13px" data-action="leave-room">← Quitter le salon</button></div>
 <div class="section-title"><h2>🏆 Classement de la partie</h2></div><div class="scoreboard">${list}</div></section>
 <section>${room.status==='waiting'?`<div class="panel" style="text-align:center;padding:50px 20px"><div style="font-size:70px">⌛</div><h3 style="margin:15px 0">La salle se remplit…</h3><p class="hint">Partage le code ${E(room.code)}. Maximum : 60 participants.</p></div>`:''}
 ${room.status==='playing'&&room.question?roomQuestionView(room,me):''}
 ${result?`<div class="panel" style="text-align:center;padding:46px 20px"><div style="font-size:76px">🏆</div><h2>Partie terminée</h2><p class="hint" style="margin:14px 0">Les récompenses et les points sont sauvegardés dans ton compte.</p><button class="btn btn-primary" data-action="leave-room">Retour au jeu</button></div>`:''}</section></div>`;
}
function roomQuestionView(room,me){
 const q=room.question;const reveal=room.reveal;const answered=me?.answered;const opts=q.options;
 const targets=room.players.filter(x=>x.id!==state.profile.id);
 if(!targets.some(x=>x.id===state.target))state.target=targets[0]?.id??null;
 const remaining=room.deadline?Math.max(0,Math.ceil(room.deadline-Date.now()/1000)):0;
 return `<div class="quiz-card"><div class="question-heading"><span class="pill purple">${E(q.category)}${state.profile.specialties.includes(q.category)?' · BONUS ×2':''}</span><span class="caps">MANCHE ${room.round} / ${room.total_rounds}</span></div>
 <div class="between" style="margin-top:13px"><span class="caps">${reveal?'CORRECTION':'TEMPS RESTANT'}</span><strong style="color:var(--gold)" class="timer">${reveal?'Terminé':remaining+' s'}</strong></div><div class="time-track"><div class="time-fill" id="timerFill" style="width:${Math.min(100,remaining/18*100)}%"></div></div>
 ${['arena','siege'].includes(room.mode)?`<div class="grid two" style="margin-top:17px;gap:8px"><div class="field"><label>Cible de l’attaque</label><select id="arena-target" ${answered?'disabled':''}>${targets.map(p=>`<option value="${p.id}" ${p.id===state.target?'selected':''}>${E(p.name)} · ${p.hp} PV</option>`).join('')}</select></div>
 <div class="field"><label>Pouvoir choisi</label><select id="arena-power" ${answered?'disabled':''}><option value="attack" ${state.power==='attack'?'selected':''}>⚔️ Attaque</option><option value="guard" ${state.power==='guard'?'selected':''}>🛡️ Bouclier (+22 PV)</option></select></div></div>`:''}
 <div class="quiz-question">${E(q.q)}</div><p class="hint">${E([q.theme,q.axis,q.subaxis].filter(Boolean).join(' › '))} · 🔥 Série ${me?.streak||0}</p><div class="answers">${opts.map((o,i)=>`<button class="answer ${reveal&&i===reveal.correct_index?'correct':''}" data-action="room-answer" data-choice="${i}" ${answered||reveal?'disabled':''}><b>${'ABCD'[i]}</b>${E(o)}</button>`).join('')}</div>
 ${answered&&!reveal?'<p class="hint" style="margin-top:15px">✓ Réponse envoyée. Correction à la fin du chronomètre.</p>':''}
 ${reveal?`<div class="answer-note"><strong>✅ Bonne réponse : ${'ABCD'[reveal.correct_index]}</strong><p style="margin-top:8px">${E(reveal.explanation)}</p></div>`:''}</div>`;
}
function bossesView(){
 const current=state.boss;
 if(current&&current.active)return bossFightView();
 const data=state.bosses;
 if(!data)return '<div class="panel">Chargement des boss…</div>';
 return `<div class="page-header"><div><div class="eyebrow">Combats solo · méthodologie du bac</div><h1>🐉 Boss de la méthode</h1><p>Défends tes 100 PV face aux attaques du boss. Tes réponses de méthode lui infligent des dégâts ; chaque erreur te coûte 28 PV.</p></div></div>
 <div class="grid three">${data.bosses.map(b=>`<article class="panel mission-card"><div class="mission-icon">${b.icon}</div><h3>${E(b.name)}</h3><div class="pill purple">${E(b.category)}</div><p>${E(b.description)}</p><p class="hint">145 PV · 6 défis · butin ${costHtml(b.reward)}</p>${data.defeated_today.includes(b.id)?'<div class="daily-done">✓ Prime du jour déjà reçue (rejouable)</div>':''}<button class="btn btn-primary btn-block" data-action="boss-start" data-id="${b.id}">⚔️ Affronter</button></article>`).join('')}</div>`;
}
function bossFightView(){
 const b=state.boss, r=state.bossResult, item=b.question, name=state.bosses?.bosses?.find(x=>x.id===b.boss)?.name||'Boss de méthode';
 return `<div class="page-header"><div><div class="eyebrow">Épreuve de méthode · question ${b.step+1} / ${b.total}</div><h1>🐉 ${E(name)}</h1></div><button class="btn btn-secondary btn-tiny" data-action="boss-abandon">Abandonner</button></div>
 <div class="panel" style="margin-bottom:18px"><div class="between"><strong>🐲 Boss</strong><strong>${r?r.boss_hp:b.boss_hp} / 145 PV</strong></div><div class="hp-track"><div style="width:${(r?r.boss_hp:b.boss_hp)/145*100}%" class="hp-fill boss-hp"></div></div>
 <div class="between" style="margin-top:16px"><strong>🛡️ Toi</strong><strong>${r?r.player_hp:b.player_hp} / 100 PV</strong></div><div class="hp-track"><div class="hp-fill" style="width:${r?r.player_hp:b.player_hp}%"></div></div><p class="hint" style="margin-top:12px">🔥 Enchaînement du combat : ${r?r.streak:b.streak} · attaques renforcées à chaque bonne réponse</p></div>
 <div class="quiz-card"><div class="question-heading"><span class="pill purple">${E(item.category)} · Méthodologie</span><span class="caps">${b.step+1} / ${b.total}</span></div><div class="quiz-question">${E(item.q)}</div><div class="answers">${item.options.map((opt,i)=>`<button class="answer ${r?(i===r.correct_index?'correct':(i===r.choice?'wrong':'')):''}" data-action="boss-answer" data-choice="${i}" ${r||state.busy?'disabled':''}><b>${'ABCD'[i]}</b> ${E(opt)}</button>`).join('')}</div>
 ${r?`<div class="answer-note"><div class="correctness">${r.correct?'⚔️ Attaque réussie : '+r.damage+' dégâts !':'🛡️ Le boss contre-attaque : -28 PV'}</div><p>${E(r.explanation)}</p><p class="hint">+ ${r.earned.score} points · ${r.earned.xp} XP · bonus ×${r.earned.multiplier}</p>${r.finished?`<div class="reward-banner">${r.won?'🏆 Boss vaincu ! Butin : '+costHtml(r.reward):'💀 Défaite. Revois la méthode et retente le combat.'}</div>`:''}<button class="btn btn-primary" data-action="boss-next" style="margin-top:14px">${r.finished?'Retour aux boss':'Question suivante →'}</button></div>`:''}</div>`;
}

function fantasyKingdom(k){
 const emoji=['','🏕️','🏘️','🏰','🏯','🏰'][k.tier]||'🏰';
 const dmg=k.damage_percent||0;
 const label=k.shield_seconds?`🛡️ Bouclier : ${Math.ceil(k.shield_seconds/60)} min`:'⚔️ Attaquable';
 return `<div class="kingdom-scene tier-${k.tier}" role="img" aria-label="Royaume de ${E(k.username)}, niveau visuel ${k.tier}">
 <div class="kingdom-cloud">☁️ ✨ ☁️</div><div class="kingdom-hills">🌳 🌲 🌼 🌳</div><div class="kingdom-castle">${emoji}</div>
 <div class="kingdom-walls">${'🧱'.repeat(Math.min(5,k.buildings.wall))}</div>
 ${dmg?`<div class="kingdom-damage">💨 ${dmg}% de dégâts visuels · régénération automatique</div>`:''}
 </div><div class="between" style="flex-wrap:wrap"><span class="pill">${E(k.title)}</span><span class="pill ${k.shield_seconds?'purple':''}">${label}</span></div>`;
}
function raidFightView(){
 const r=state.raid,z=state.raidResult,q=r?.question;
 if(!r?.active||!q)return '';
 return `<div class="page-header"><div><div class="eyebrow">Raid différé contre ${E(r.defender)}</div><h1>⚔️ Siège du château</h1><p>QCM ${r.step+1} / ${r.total} · dégâts ${fmt(z?.damage??r.damage)} / ${fmt(r.defense)} · ${fmt(r.units.soldiers+r.units.archers+r.units.mages)} unités</p></div><button class="btn btn-secondary btn-tiny" data-action="raid-abandon">🏳️ Battre en retraite</button></div>
 <div class="hp-track"><div class="hp-fill boss-hp" style="width:${Math.min(100,(z?.damage??r.damage)/r.defense*100)}%"></div></div>
 <div class="quiz-card" style="margin-top:15px"><div class="question-heading"><span class="pill purple">${E(q.category)} · ${E(q.theme||'')}</span><strong>🔥 Série ${z?.streak??r.streak}</strong></div><div class="quiz-question">${E(q.q)}</div><div class="answers">${q.options.map((x,i)=>`<button class="answer ${z&&i===z.correct_index?'correct':''}" data-action="raid-answer" data-choice="${i}" ${z||state.busy?'disabled':''}><b>${'ABCD'[i]}</b> ${E(x)}</button>`).join('')}</div>
 ${z?`<div class="answer-note">${z.correct?'✅ Bonne réponse : '+z.damage_dealt+' dégâts':'❌ Aucun dégât. Continue de réviser.'}<p>${E(z.explanation)}</p>${z.finished?`<div class="reward-banner">${z.won?'🏆 Château conquis !':'🛡️ Défense résistante !'} Prestige : ${z.prestige_change.attacker_delta>0?'+':''}${z.prestige_change.attacker_delta} · ton armée revient intacte.</div>`:''}<button class="btn btn-primary" data-action="raid-next">${z.finished?'Retour aux royaumes':'Question suivante →'}</button></div>`:''}</div>`;
}
function kingdomsView(){
 if(state.raid?.active)return raidFightView();
 const k=state.visiting||(state.kingdoms||[]).find(x=>x.username===state.profile.username)||state.profile.kingdom;
 const available=state.kingdoms||[];
 return `<div class="page-header"><div><div class="eyebrow">Royaumes persistants · reconstruction automatique</div><h1>🌍 Les royaumes des érudits</h1><p>Choisis un château. S’il est en ligne, lance un duel simultané ; sinon attaque ses défenses automatiques.</p></div><button class="btn btn-secondary btn-tiny" data-action="refresh-kingdoms">↻ Actualiser</button></div>
 ${state.curriculum&&!state.focusOpen?focusView():''}
 <div class="grid two"><section class="panel"><div class="between"><h2>🏰 ${E(k.username)}</h2><span class="chip gold">👑 ${fmt(k.prestige)} prestige</span></div>${fantasyKingdom(k)}<p class="hint" style="margin:12px 0">${fmt(k.knowledge)} notions maîtrisées · puissance ${fmt(k.power)} · ${fmt(k.building_levels)} niveaux de bâtiments.</p>
 ${k.username===state.profile.username?'<div class="notif">Ton royaume grandit en apprenant. Les invasions ne retirent aucune ressource ni progression.</div>':`<div class="grid two" style="margin-top:12px"><button class="btn btn-primary" data-action="siege-challenge" data-id="${E(k.username)}" ${!k.online||k.shield_seconds?'disabled':''}>⚔️ Duel en direct ${k.online?'':'(hors ligne)'}</button><button class="btn btn-gold" data-action="raid-choose" data-id="${E(k.username)}" ${k.shield_seconds?'disabled':''}>🏹 Attaquer en différé</button></div>`}
 ${state.raidTarget===k.username?`<form data-form="raid-start" style="margin-top:15px"><p class="hint">Sélectionne des troupes pour le raid. Elles reviendront TOUTES, victoire ou défaite.</p><div class="battle-grid" style="margin:12px 0"><div class="field"><label>Gardiens</label><input name="soldiers" type="number" min="0" max="${state.profile.army.soldiers}" value="${state.profile.army.soldiers}"/></div><div class="field"><label>Archers</label><input name="archers" type="number" min="0" max="${state.profile.army.archers}" value="${state.profile.army.archers}"/></div><div class="field"><label>Mages</label><input name="mages" type="number" min="0" max="${state.profile.army.mages}" value="${state.profile.army.mages}"/></div></div><input type="hidden" name="defender" value="${E(k.username)}"/><button class="btn btn-primary btn-block">Lancer le raid ⚔️</button></form>`:''}
 </section><section class="panel"><h2>🗺️ Royaumes visitables</h2><p class="hint" style="margin:10px 0">Les joueurs en ligne peuvent accepter un duel ; les autres sont attaquables en différé hors protection.</p><div class="kingdom-list">${available.map(v=>`<button class="kingdom-pick ${k.username===v.username?'chosen':''}" data-action="visit-kingdom" data-id="${E(v.username)}"><span>${['','🏕️','🏘️','🏰','🏯','🏰'][v.tier]}</span><span><strong>${E(v.username)}</strong><small>${v.online?'🟢 En ligne':'⚪ Hors ligne'} · ${E(v.title)}</small></span><b>${fmt(v.prestige)} 👑</b></button>`).join('')||'<p class="hint">Aucun autre royaume disponible.</p>'}</div></section></div>
 <div class="section-title"><h2>📜 Dernières attaques</h2></div><div class="panel">${(state.raidLog||[]).map(r=>`<div class="between history-line"><span>⚔️ ${E(r.attacker)} → ${E(r.defender)}</span><span>${r.won?'🏆 Victoire':'🛡️ Résistance'}</span></div>`).join('')||'<p class="hint">Aucune attaque terminée.</p>'}</div>
 <p class="hint" style="margin-top:15px">Une défaite peut coûter du prestige, mais jamais des points de révision, des troupes ou des bâtiments. Les dégâts visuels s’effacent en dix minutes. Après une attaque, le défenseur reçoit un bouclier de 30 minutes.</p>`;
}

function leaderboardView(){
 const rows=state.leaderboard;
 if(!rows)return '<div class="panel">Chargement du classement…</div>';
 return `<div class="page-header"><div><div class="eyebrow">Compétition interjoueurs</div><h1>Panthéon des érudits</h1><p>Classement global persistant : réponses, stratégie et conquêtes. Les spécialités choisies rapportent deux fois plus de points.</p></div><button class="btn btn-secondary btn-tiny" data-action="refresh-leader">↻ Actualiser</button></div>
 <div class="hero" style="background:linear-gradient(110deg,#4b3e37,#332f42,#172a39)"><div class="hero-copy"><div class="eyebrow" style="color:#ffe2a3">LE TOP DES STRATÈGES</div><h2>Ton ascension commence ici.</h2><p>Révise chaque jour, complète des missions et bats tes adversaires pour monter au classement.</p></div><div class="hero-emoji">🏆</div></div>
 <div class="section-title"><h2>🏅 Meilleurs joueurs</h2><span>${rows.length} joueur(s) affichés</span></div>
 <div class="panel"><div class="leaderboard-head"><div>Rang</div><div>Joueur</div><div>Points</div><div class="hide-mobile">Territoires</div></div>
 ${rows.map(r=>`<div class="leader-row ${r.username===state.profile.username?'mine':''}"><div class="badge-rank">${r.rank<=3?['🥇','🥈','🥉'][r.rank-1]:r.rank}</div><div><div style="font-weight:900">${E(r.username)} ${r.username===state.profile.username?'· toi':''}</div><div class="small muted">Niv. ${r.level} · ${E(r.specialties.join(' + '))}</div></div><div class="leader-score">${fmt(r.score)}</div><div class="hide-mobile muted">${r.territories} / 3</div></div>`).join('')||'<div class="empty">Aucun joueur inscrit pour le moment.</div>'}</div>`;
}
function render(){const root=$('#app');if(!root)return;root.innerHTML=state.profile?shell():authView();updateTimer()}
function updateTimer(){const r=state.room;if(!r||!r.deadline||r.reveal)return;const rem=Math.max(0,r.deadline-Date.now()/1000);const el=$('.timer');if(el)el.textContent=Math.ceil(rem)+' s';const bar=$('#timerFill');if(bar)bar.style.width=Math.min(100,rem/18*100)+'%'}
setInterval(updateTimer,300);
async function loadMe(shouldRender=true){state.profile=await api('me');if(shouldRender)render()}
async function loadStrategy(){const s=await api('strategy');state.strategy=s;state.profile=s.profile;state.dailyDraw=await api('daily-draw');render()}
async function loadQuests(){state.quests=await api('quests');state.quest=await api('quest/current');state.story=await api('story');state.questResult=null;render()}
async function loadBosses(){state.bosses=await api('bosses');state.boss=await api('boss/current');state.bossResult=null;render()}
async function loadCurriculum(){state.curriculum=await api('curriculum');state.focusDraft={...state.profile.focus};render()}
async function loadLeaderboard(){state.leaderboard=await api('leaderboard');render()}
async function loadKingdoms(){
 state.kingdoms=await api('kingdoms');state.raid=await api('raid/current');state.raidResult=null;state.raidLog=await api('raid/log');
 if(state.visiting)state.visiting=state.kingdoms.find(k=>k.username===state.visiting.username)||state.visiting;
 state.visiting ||= state.kingdoms.find(k=>k.username===state.profile.username)||state.profile.kingdom;
 if(!state.curriculum)await loadCurriculum();render();
}
async function setTab(tab){state.tab=tab;state.busy=false;render();try{
 if(tab==='strategy')await loadStrategy();if(tab==='quests'){await loadQuests();if(!state.curriculum)await loadCurriculum();}if(tab==='bosses')await loadBosses();
 if(tab==='party'||tab==='arena'){if(!state.curriculum)await loadCurriculum();}
 if(tab==='leaderboard')await loadLeaderboard();
 if(tab==='kingdoms')await loadKingdoms();
 }catch(e){toast(e.message,true)}}
function wsSend(obj){if(!state.ws||state.ws.readyState!==WebSocket.OPEN){toast('Connexion multijoueur indisponible.',true);return false}state.ws.send(JSON.stringify(obj));return true}
function ensureSocket(){if(!state.profile||state.ws&&(state.ws.readyState===WebSocket.OPEN||state.ws.readyState===WebSocket.CONNECTING))return;
 const proto=location.protocol==='https:'?'wss':'ws';const socket=new WebSocket(`${proto}://${location.host}/ws`);state.ws=socket;
 socket.onopen=()=>{state.wsReady=true;render();try{const saved=sessionStorage.getItem('bac-room');if(saved)wsSend({type:'join',code:saved})}catch(e){}};
 socket.onmessage=e=>{let msg;try{msg=JSON.parse(e.data)}catch{return}if(msg.type==='room'){
    state.room=msg;
    if(['party','arena'].includes(msg.mode))state.tab=msg.mode;
    if(msg.mode==='siege'){state.tab='kingdoms';state.siegeInvite=null;state.siegeWaiting=null;}
    try{sessionStorage.setItem('bac-room',msg.code)}catch(e){}
    if(msg.status==='finished'&&state.lastFinishCode!==msg.code){state.lastFinishCode=msg.code;loadMe(false).then(render).catch(()=>{});toast('Partie terminée ! Récompenses sauvegardées.');}
    render();
   }else if(msg.type==='siege_invite'){state.siegeInvite=msg;render();toast('⚔️ Défi reçu !')}
   else if(msg.type==='siege_waiting'){state.siegeWaiting=msg;render()}
   else if(msg.type==='siege_declined'){state.siegeWaiting=null;render()}
   else if(msg.type==='left'){state.room=null;state.target=null;state.siegeWaiting=null;state.lastFinishCode=null;try{sessionStorage.removeItem('bac-room')}catch(e){}loadMe(false).then(render).catch(render)}
   else if(msg.type==='error')toast(msg.message,true);
 };
 socket.onclose=()=>{if(state.ws!==socket)return;state.wsReady=false;state.ws=null;if(state.profile&&state.allowReconnect){clearTimeout(state.reconnectTimer);state.reconnectTimer=setTimeout(ensureSocket,2500)}render()};
 socket.onerror=()=>{};
}
function runBusy(callback){if(state.busy)return;state.busy=true;return Promise.resolve().then(callback).catch(e=>toast(e.message,true)).finally(()=>{state.busy=false;render()})}
document.addEventListener('click',e=>{
 const navButton=e.target.closest('[data-nav]');if(navButton){setTab(navButton.dataset.nav);return}
 const button=e.target.closest('[data-action]');if(!button)return;
 const a=button.dataset.action, id=button.dataset.id;
 if(a==='auth-toggle'){state.authMode=state.authMode==='register'?'login':'register';render();return}
 if(a==='logout'){runBusy(async()=>{state.allowReconnect=false;clearTimeout(state.reconnectTimer);state.ws?.close();state.ws=null;state.wsReady=false;await api('logout',{});state.profile=null;state.room=null;state.strategy=null;state.quest=null;state.leaderboard=null;state.curriculum=null;state.focusDraft=null;state.boss=null;state.bosses=null;state.kingdoms=null;state.visiting=null;state.raid=null;state.siegeInvite=null;try{sessionStorage.removeItem('bac-room')}catch(e){}render()});return}
 if(a==='refresh'){loadStrategy().catch(e=>toast(e.message,true));return}
 if(a==='refresh-leader'){loadLeaderboard().catch(e=>toast(e.message,true));return}
 if(a==='focus-toggle'){state.focusOpen=!state.focusOpen;render();return}
 if(a==='daily-draw'){runBusy(async()=>{const r=await api('daily-draw',{});state.profile=r.profile;state.dailyDraw=await api('daily-draw');toast(`Coffre ${r.rarity} : +${r.score} points !`);render()});return}
 if(a==='story-claim'){runBusy(async()=>{const r=await api('story/'+id+'/claim',{});state.profile=r.profile;state.story=await api('story');toast(r.resolution);render()});return}
 if(a==='refresh-kingdoms'){loadKingdoms().catch(e=>toast(e.message,true));return}
 if(a==='visit-kingdom'){state.visiting=state.kingdoms?.find(k=>k.username===id)||null;state.raidTarget=null;render();return}
 if(a==='siege-challenge'){wsSend({type:'siege_challenge',username:id});return}
 if(a==='siege-accept'){wsSend({type:'siege_accept',code:state.siegeInvite?.code});state.siegeInvite=null;render();return}
 if(a==='siege-decline'){wsSend({type:'siege_decline',code:state.siegeInvite?.code});state.siegeInvite=null;render();return}
 if(a==='siege-cancel'){wsSend({type:'leave'});state.siegeWaiting=null;render();return}
 if(a==='raid-choose'){state.raidTarget=id;render();return}
 if(a==='raid-answer'){runBusy(async()=>{const choice=Number(button.dataset.choice);state.raidResult=await api('raid/answer',{choice});state.raidResult.choice=choice;state.profile=state.raidResult.profile;render()});return}
 if(a==='raid-next'){
    const z=state.raidResult;if(!z)return;
    if(z.finished){state.raid=null;state.raidResult=null;state.raidTarget=null;loadKingdoms().catch(e=>toast(e.message,true));return}
    state.raid={...state.raid,step:z.step,damage:z.damage,streak:z.streak,question:z.next_question};state.raidResult=null;render();return;
 }
 if(a==='raid-abandon'){runBusy(async()=>{const r=await api('raid/abandon',{});state.profile=r.profile;state.raid=null;state.raidResult=null;toast(r.message);await loadKingdoms()});return}
 if(a==='upgrade'){runBusy(async()=>{const res=await api('upgrade',{building:id});toast(res.message);await loadStrategy()});return}
 if(a==='recruit'){const val=Number($('#amount-'+id)?.value);runBusy(async()=>{const res=await api('recruit',{unit:id,amount:val});toast(res.message);await loadStrategy()});return}
 if(a==='focus-save'){runBusy(async()=>{const f=state.focusDraft||state.profile.focus;const out=await api('focus',f);state.profile=out.profile;state.focusOpen=false;toast('Thème sauvegardé · '+out.question_count+' question(s) disponibles.');render()});return}
 if(a==='practice-start'){runBusy(async()=>{state.quest=await api('practice/start',{});state.questResult=null;render()});return}
 if(a==='boss-start'){runBusy(async()=>{state.boss=await api('boss/start',{boss:id});state.bossResult=null;render()});return}
 if(a==='boss-abandon'){runBusy(async()=>{await api('boss/abandon',{});state.boss=null;state.bossResult=null;await loadBosses()});return}
 if(a==='boss-answer'){runBusy(async()=>{const choice=Number(button.dataset.choice);state.bossResult=await api('boss/answer',{choice});state.bossResult.choice=choice;state.profile=state.bossResult.profile;render()});return}
 if(a==='boss-next'){if(!state.bossResult)return;if(state.bossResult.finished){state.boss=null;state.bossResult=null;loadBosses().catch(e=>toast(e.message,true));return}state.boss={...state.boss,question:state.bossResult.next_question,step:state.bossResult.step,boss_hp:state.bossResult.boss_hp,player_hp:state.bossResult.player_hp,streak:state.bossResult.streak};state.bossResult=null;render();return}
 if(a==='quest-start'){runBusy(async()=>{state.quest=await api('quest/start',{mission:id});state.questResult=null;render()});return}
 if(a==='quest-abandon'){runBusy(async()=>{await api('quest/abandon',{});state.quest=null;state.questResult=null;await loadQuests()});return}
 if(a==='quest-answer'){runBusy(async()=>{const choice=Number(button.dataset.choice);state.questResult=await api('quest/answer',{choice});state.questResult.choice=choice;state.profile=state.questResult.profile;render()});return}
 if(a==='quest-next'){
   const r=state.questResult;if(!r)return;
   if(r.finished){state.quest=null;state.questResult=null;loadQuests().catch(e=>toast(e.message,true));return}
   state.quest={...state.quest,question:r.next_question,step:r.step};state.questResult=null;render();return;
 }
 if(a==='create-room'){wsSend({type:'create',mode:state.tab});return}
 if(a==='start-room'){wsSend({type:'start'});return}
 if(a==='leave-room'){wsSend({type:'leave'});return}
 if(a==='copy-code'){const code=state.room?.code;if(!code)return;navigator.clipboard?.writeText(code).then(()=>toast('Code '+code+' copié !')).catch(()=>toast('Code : '+code));return}
 if(a==='room-answer'){const r=state.room;if(!r)return;const tgt=Number($('#arena-target')?.value)||state.target;const power=$('#arena-power')?.value||state.power;state.target=tgt;state.power=power;wsSend({type:'answer',choice:Number(button.dataset.choice),round:r.round,target:tgt,power});return}
});
document.addEventListener('change',e=>{if(e.target.dataset.focus){const names=['subject','theme','axis','subaxis'];const key=e.target.dataset.focus;const ix=names.indexOf(key);const f={...(state.focusDraft||state.profile?.focus||{})};f[key]=e.target.value;names.slice(ix+1).forEach(k=>f[k]='');state.focusDraft=f;render();return;}if(e.target.id==='arena-target')state.target=Number(e.target.value);if(e.target.id==='arena-power')state.power=e.target.value});
document.addEventListener('submit',e=>{
 const form=e.target.closest('[data-form]');if(!form)return;e.preventDefault();
 const kind=form.dataset.form,fd=new FormData(form);const data=Object.fromEntries(fd.entries());
 if(kind==='auth'){runBusy(async()=>{
  let p;if(state.authMode==='register')p=await api('register',{username:data.username,password:data.password,specialties:[data.spec1,data.spec2]});
  else p=await api('login',{username:data.username,password:data.password});
  state.profile=p;state.allowReconnect=true;state.tab='strategy';ensureSocket();await loadStrategy();await loadCurriculum();toast('Bienvenue dans ton royaume !');
 });return}
 if(kind==='attack'){runBusy(async()=>{const res=await api('attack',{territory:data.territory,formation:data.formation,route:data.route,soldiers:Number(data.soldiers),archers:Number(data.archers),mages:Number(data.mages)});
   toast(`${res.won?'🏆':'⚠️'} ${res.message} Puissance ${res.strength} / ${res.enemy_strength}. Pertes : ${Object.values(res.losses).reduce((a,b)=>a+b,0)}.` ,!res.won);await loadStrategy();});return}
 if(kind==='raid-start'){runBusy(async()=>{
   const out=await api('raid/start',{defender:data.defender,soldiers:Number(data.soldiers),archers:Number(data.archers),mages:Number(data.mages)});
   state.raid=out.raid;state.raidResult=null;state.profile=out.profile;render();
 });return}
 if(kind==='join-room'){wsSend({type:'join',code:data.code.trim().toUpperCase()});return}
});
(async()=>{try{state.profile=await api('me');state.allowReconnect=true;ensureSocket();await loadStrategy();await loadCurriculum()}catch(e){state.profile=null;render()}
 if('serviceWorker' in navigator&&location.protocol==='https:')navigator.serviceWorker.register('/sw.js').catch(()=>{});
})();
