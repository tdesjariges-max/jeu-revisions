"""BAC DOMINION: single-process FastAPI multiplayer prototype.

Run with: uvicorn app:app --host 0.0.0.0 --port 8000
Database persists; active multiplayer rooms live in memory (one worker only).
"""
from __future__ import annotations

import asyncio
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import hmac
import json
import math
import os
from pathlib import Path
import random
import re
import secrets
import sqlite3
import time
from urllib.parse import urlparse

from fastapi import FastAPI, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from questions import QUESTIONS, QUESTS, SPECIALTIES
from story import CHAPTERS
from curriculum import TAGS, BOSSES, METHOD_QUESTIONS

assert len(TAGS) == len(QUESTIONS)
for q, (theme, axis, subaxis) in zip(QUESTIONS, TAGS):
    q.update(theme=theme, axis=axis, subaxis=subaxis)

# Exponential, but capped so a streak never explodes the economy.
STREAK_BASE = 1.35
STREAK_CAP = 6.0

ROOT = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('BAC_DB_PATH', str(ROOT / 'bac_dominion.db')))
COOKIE = 'bac_session'
SESSION_SECONDS = 30 * 86400
ROUND_SECONDS = int(os.environ.get('BAC_ROUND_SECONDS', '18'))
REVEAL_SECONDS = float(os.environ.get('BAC_REVEAL_SECONDS', '4'))
ROOM_ROUNDS = int(os.environ.get('BAC_ROOM_ROUNDS', '6'))
MAX_ROOM = 60

BUILDINGS = {
    'mine': {'name':'Mine d’or', 'base':(60,40,20),'effect':'Produit de l’or à chaque heure', 'rates':'gold'},
    'sawmill': {'name':'Scierie', 'base':(55,35,25),'effect':'Produit du bois à chaque heure','rates':'wood'},
    'quarry': {'name':'Carrière', 'base':(55,45,20),'effect':'Produit de la pierre à chaque heure','rates':'stone'},
    'academy': {'name':'Académie', 'base':(85,65,55),'effect':'Améliore l’XP et débloque les mages'},
    'barracks': {'name':'Caserne', 'base':(75,55,40),'effect':'Augmente la capacité maximale de l’armée'},
    'wall': {'name':'Remparts', 'base':(65,70,70),'effect':'Renforce la garnison et le prestige'},
}
UNITS = {
    'soldiers':{'name':'Gardiens','cost':(26,12,4), 'power':12},
    'archers':{'name':'Archers','cost':(46,18,6), 'power':21},
    'mages':{'name':'Mages','cost':(75,12,28), 'power':37},
}
TERRITORIES = {
    'forest':{'name':'Forêt des mémoires','defense':55,'preferred_formation':'flank','preferred_route':'woods','reward':(100,70,40), 'icon':'🌲'},
    'pass':{'name':'Col des arguments','defense':115,'preferred_formation':'defend','preferred_route':'hills','reward':(175,110,85), 'icon':'⛰️'},
    'citadel':{'name':'Citadelle des oubliés','defense':245,'preferred_formation':'charge','preferred_route':'bridge','reward':(290,180,155), 'icon':'🏰'},
}

@contextmanager
def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def init_db():
    with connect() as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
            salt TEXT NOT NULL, password_hash TEXT NOT NULL,
            spec1 TEXT NOT NULL, spec2 TEXT NOT NULL,
            xp INTEGER NOT NULL DEFAULT 0, score INTEGER NOT NULL DEFAULT 0,
            gold INTEGER NOT NULL DEFAULT 220, wood INTEGER NOT NULL DEFAULT 160,
            stone INTEGER NOT NULL DEFAULT 110,
            mine INTEGER NOT NULL DEFAULT 1, sawmill INTEGER NOT NULL DEFAULT 1,
            quarry INTEGER NOT NULL DEFAULT 1, academy INTEGER NOT NULL DEFAULT 1,
            barracks INTEGER NOT NULL DEFAULT 1, wall INTEGER NOT NULL DEFAULT 1,
            soldiers INTEGER NOT NULL DEFAULT 0, archers INTEGER NOT NULL DEFAULT 0,
            mages INTEGER NOT NULL DEFAULT 0, territories TEXT NOT NULL DEFAULT '[]',
            carry_gold REAL NOT NULL DEFAULT 0, carry_wood REAL NOT NULL DEFAULT 0,
            carry_stone REAL NOT NULL DEFAULT 0, last_collect REAL NOT NULL,
            last_attack REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS sessions (
            token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL,
            expires REAL NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS quest_runs (
            user_id INTEGER PRIMARY KEY, mission TEXT NOT NULL, questions TEXT NOT NULL,
            step INTEGER NOT NULL DEFAULT 0, correct INTEGER NOT NULL DEFAULT 0,
            started_at REAL NOT NULL
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS quest_daily (
            user_id INTEGER NOT NULL, mission TEXT NOT NULL, date TEXT NOT NULL,
            PRIMARY KEY (user_id, mission, date)
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS boss_runs (
            user_id INTEGER PRIMARY KEY, boss TEXT NOT NULL, questions TEXT NOT NULL,
            step INTEGER NOT NULL DEFAULT 0, boss_hp INTEGER NOT NULL DEFAULT 145,
            player_hp INTEGER NOT NULL DEFAULT 100, streak INTEGER NOT NULL DEFAULT 0,
            started_at REAL NOT NULL
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS boss_daily (
            user_id INTEGER NOT NULL, boss TEXT NOT NULL, date TEXT NOT NULL,
            PRIMARY KEY(user_id,boss,date)
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS learned_questions (
            user_id INTEGER NOT NULL, question_hash TEXT NOT NULL,
            first_correct_at TEXT NOT NULL,
            PRIMARY KEY (user_id, question_hash),
            FOREIGN KEY(user_id) REFERENCES users(id)
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS daily_draws (
            user_id INTEGER NOT NULL, date TEXT NOT NULL, reward INTEGER NOT NULL,
            rarity TEXT NOT NULL, PRIMARY KEY (user_id,date)
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS story_claims (
            user_id INTEGER NOT NULL, chapter TEXT NOT NULL,
            claimed_at TEXT NOT NULL,
            PRIMARY KEY (user_id,chapter)
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS raid_runs (
            attacker_id INTEGER PRIMARY KEY, defender_id INTEGER NOT NULL,
            question_indices TEXT NOT NULL, step INTEGER NOT NULL DEFAULT 0,
            damage INTEGER NOT NULL DEFAULT 0, streak INTEGER NOT NULL DEFAULT 0,
            defense INTEGER NOT NULL, units_json TEXT NOT NULL,
            started_at REAL NOT NULL
        )''')
        db.execute('''CREATE TABLE IF NOT EXISTS raid_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            attacker_id INTEGER NOT NULL, defender_id INTEGER NOT NULL,
            created_at REAL NOT NULL, utc_day TEXT NOT NULL,
            won INTEGER, damage INTEGER NOT NULL DEFAULT 0
        )''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_raids_day ON raid_attempts(attacker_id,utc_day)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_raids_defender ON raid_attempts(defender_id,created_at)')
        columns = {r[1] for r in db.execute('PRAGMA table_info(users)').fetchall()}
        for name, definition in {
            'prestige':'INTEGER NOT NULL DEFAULT 1000',
            'damage_until':'REAL NOT NULL DEFAULT 0',
            'damage_percent':'INTEGER NOT NULL DEFAULT 0',
            'shield_until':'REAL NOT NULL DEFAULT 0',
            'knowledge_count':'INTEGER NOT NULL DEFAULT 0',
            'streak':'INTEGER NOT NULL DEFAULT 0',
            'best_streak':'INTEGER NOT NULL DEFAULT 0',
            'focus_subject':"TEXT NOT NULL DEFAULT ''",
            'focus_theme':"TEXT NOT NULL DEFAULT ''",
            'focus_axis':"TEXT NOT NULL DEFAULT ''",
            'focus_subaxis':"TEXT NOT NULL DEFAULT ''",
        }.items():
            if name not in columns:
                db.execute(f'ALTER TABLE users ADD COLUMN {name} {definition}')
        db.execute('''CREATE TABLE IF NOT EXISTS pvp_battles (
            id INTEGER PRIMARY KEY AUTOINCREMENT, attacker_id INTEGER NOT NULL,
            defender_id INTEGER NOT NULL, mode TEXT NOT NULL, won INTEGER NOT NULL,
            attacker_delta INTEGER NOT NULL, defender_delta INTEGER NOT NULL,
            created_at REAL NOT NULL
        )''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_pvp_defender ON pvp_battles(defender_id,created_at)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_leaderboard ON users(score DESC)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires)')

init_db()
app = FastAPI(title='BAC DOMINION', version='0.3.1')
app.mount('/static', StaticFiles(directory=str(ROOT / 'static')), name='static')

@app.get('/')
def home():
    return FileResponse(ROOT / 'static' / 'index.html')

@app.get('/manifest.webmanifest')
def manifest():
    return FileResponse(ROOT / 'static' / 'manifest.webmanifest', media_type='application/manifest+json')

@app.get('/sw.js')
def sw():
    return FileResponse(ROOT / 'static' / 'sw.js', media_type='text/javascript')

class Credentials(BaseModel):
    username: str
    password: str

class Register(Credentials):
    specialties: list[str]

class Upgrade(BaseModel):
    building: str

class Recruit(BaseModel):
    unit: str
    amount: int = Field(ge=1, le=25)

class Attack(BaseModel):
    territory: str
    formation: str
    route: str
    soldiers: int = Field(ge=0, le=999)
    archers: int = Field(ge=0, le=999)
    mages: int = Field(ge=0, le=999)

class QuestStart(BaseModel):
    mission: str

class QuestAnswer(BaseModel):
    choice: int = Field(ge=0, le=3)

class FocusData(BaseModel):
    subject: str = ''
    theme: str = ''
    axis: str = ''
    subaxis: str = ''

class BossStart(BaseModel):
    boss: str

class RaidStart(BaseModel):
    defender: str
    soldiers: int = Field(ge=0, le=200)
    archers: int = Field(ge=0, le=200)
    mages: int = Field(ge=0, le=200)



# Simple per-IP throttling for auth. A production deployment should use a shared rate-limit store.
auth_attempts: dict[str,list[float]] = {}

def throttle(ip: str):
    now = time.monotonic()
    attempts = [ts for ts in auth_attempts.get(ip,[]) if now-ts < 60]
    if len(attempts) >= 12:
        raise HTTPException(429, 'Trop de tentatives. Réessaie dans une minute.')
    attempts.append(now)
    auth_attempts[ip] = attempts


def hash_password(password: str, salt_hex: str) -> str:
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), bytes.fromhex(salt_hex), 260_000).hex()


def session_user(token: str | None):
    if not token: return None
    digest = hashlib.sha256(token.encode('utf-8')).hexdigest()
    with connect() as db:
        return db.execute('''SELECT u.* FROM users u JOIN sessions s ON u.id=s.user_id
                             WHERE s.token_hash=? AND s.expires > ?''', (digest,time.time())).fetchone()


def require_user(request: Request):
    user = session_user(request.cookies.get(COOKIE))
    if user is None: raise HTTPException(401, 'Connecte-toi pour jouer.')
    return user


def create_session(response: Response, request: Request, uid: int):
    token = secrets.token_urlsafe(36)
    with connect() as db:
        db.execute('INSERT INTO sessions(token_hash,user_id,expires) VALUES(?,?,?)',
                   (hashlib.sha256(token.encode()).hexdigest(),uid,time.time()+SESSION_SECONDS))
    response.set_cookie(COOKIE,token,max_age=SESSION_SECONDS,path='/',secure=request.url.scheme=='https' or os.environ.get('BAC_FORCE_SECURE_COOKIES')=='1',httponly=True,samesite='lax')


AESTHETIC_TIERS = [
    {'id':1, 'name':'Hameau des curieux', 'min_knowledge':0, 'min_building_levels':6},
    {'id':2, 'name':'Village des découvertes', 'min_knowledge':3, 'min_building_levels':8},
    {'id':3, 'name':'Forteresse enchantée', 'min_knowledge':8, 'min_building_levels':12},
    {'id':4, 'name':'Cité des érudits', 'min_knowledge':16, 'min_building_levels':18},
    {'id':5, 'name':'Royaume céleste', 'min_knowledge':28, 'min_building_levels':24},
]


def cosmetic_state(u):
    remaining = max(0, u['damage_until']-time.time())
    # Damage fades naturally over 10 minutes. Visual only: no building stats change.
    percent = round(u['damage_percent'] * min(1.0, remaining / 600.0))
    return {'damage_percent':percent,'regenerating_seconds':round(remaining),
            'shield_seconds':round(max(0,u['shield_until']-time.time()))}


def pvp_result(db, attacker_id: int, defender_id: int, won:bool, mode:str):
    # Only prestige is transferable. Neither realm nor army, score, XP or resources
    # on the defender's side is changed. Protect the target from being farmed.
    a, d = fresh_user(db,attacker_id),fresh_user(db,defender_id)
    if won:
        attacker_delta=18
        defender_delta=-min(12,d['prestige'])
    else:
        attacker_delta=-min(6,a['prestige'])
        defender_delta=6
    db.execute('UPDATE users SET prestige=MAX(0,prestige+?) WHERE id=?',
               (attacker_delta,attacker_id))
    damage=max(10,min(85,55 if won else 15))
    db.execute('''UPDATE users SET prestige=MAX(0,prestige+?),
                damage_percent=?,damage_until=?,shield_until=MAX(shield_until,?) WHERE id=?''',
               (defender_delta,damage,time.time()+600,time.time()+1800,defender_id))
    db.execute('''INSERT INTO pvp_battles(attacker_id,defender_id,mode,won,attacker_delta,defender_delta,created_at)
                VALUES(?,?,?,?,?,?,?)''',
               (attacker_id,defender_id,mode,int(won),attacker_delta,defender_delta,time.time()))
    return {'attacker_delta':attacker_delta,'defender_delta':defender_delta,
            'regen_seconds':600,'shield_seconds':1800}


def kingdom_snapshot(user):
    knowledge = user['knowledge_count']
    levels = sum(user[b] for b in BUILDINGS)
    tier = max(t['id'] for t in AESTHETIC_TIERS
               if knowledge >= t['min_knowledge'] and levels >= t['min_building_levels'])
    army_power = sum(user[k] * v['power'] for k,v in UNITS.items())
    territory_count = len(json.loads(user['territories']))
    return {
        'username': user['username'], 'title': AESTHETIC_TIERS[tier-1]['name'],
        'prestige':user['prestige'], **cosmetic_state(user),
        'tier': tier, 'knowledge': knowledge, 'building_levels': levels,
        'power': knowledge*25 + levels*9 + army_power + territory_count*95,
        'buildings': {key:user[key] for key in BUILDINGS},
        'territories': json.loads(user['territories']),
        'next_tier': AESTHETIC_TIERS[tier] if tier<5 else None,
    }


def public_user(user):
    return {'id':user['id'],'username':user['username'], 'specialties':[user['spec1'],user['spec2']],
            'xp':user['xp'],'score':user['score'],'prestige':user['prestige'],'level':1+int(math.sqrt(user['xp']/90)),
            'gold':user['gold'],'wood':user['wood'],'stone':user['stone'],
            'buildings':{name:user[name] for name in BUILDINGS},
            'army':{name:user[name] for name in UNITS},
            'territories':json.loads(user['territories']),
            'streak':user['streak'],'best_streak':user['best_streak'],
            'kingdom':kingdom_snapshot(user),
            'focus':{k:user['focus_'+k] for k in ('subject','theme','axis','subaxis')}}


def shuffled_question(q, seed=None):
    # Stable for resumed solo runs, unpredictable within each new run.
    options_order=list(range(len(q['options'])))
    (random.Random(str(seed)) if seed is not None else random).shuffle(options_order)
    return {**q, 'options':[q['options'][i] for i in options_order],
            'correct':options_order.index(q['correct'])}


def question_public(q):
    return {k:q[k] for k in ('category','q','options') if k in q} | {k:q[k] for k in ('theme','axis','subaxis') if k in q}


def points_for(row, category: str):
    # Every correct specialty answer in the student's selected specialties is worth double.
    is_specialty = category in (row['spec1'],row['spec2'])
    score = 20 if is_specialty else 10
    xp = (24 if is_specialty else 12) + 2*(row['academy']-1)
    return score,xp,is_specialty


def streak_multiplier(streak: int) -> float:
    return min(STREAK_CAP, STREAK_BASE ** max(0, streak-1))


def award_answer(db, uid: int, category: str, correct: bool = True, question_key: str | None = None):
    # Award or reset a streak atomically. Only the server validates correctness.
    row = db.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    if not correct:
        db.execute('UPDATE users SET streak=0 WHERE id=?',(uid,))
        return {'score':0,'xp':0,'specialty_bonus':False,'streak':0,'multiplier':1.0}
    new_streak = row['streak'] + 1
    multiplier = streak_multiplier(new_streak)
    score,xp,bonus = points_for(row,category)
    earned_score,earned_xp = round(score*multiplier),round(xp*multiplier)
    # Only a newly answered distinct question adds to public knowledge mastery.
    if question_key:
        digest = hashlib.sha256(question_key.encode('utf-8')).hexdigest()
        added = db.execute('''INSERT OR IGNORE INTO learned_questions(user_id,question_hash,first_correct_at)
                          VALUES(?,?,?)''',(uid,digest,datetime.now(timezone.utc).isoformat())).rowcount
        if added:
            db.execute('UPDATE users SET knowledge_count=knowledge_count+1 WHERE id=?',(uid,))
    db.execute('''UPDATE users SET score=score+?, xp=xp+?, streak=?,
                 best_streak=MAX(best_streak,?) WHERE id=?''',
              (earned_score,earned_xp,new_streak,new_streak,uid))
    return {'score':earned_score,'xp':earned_xp,'specialty_bonus':bonus,
            'streak':new_streak,'multiplier':round(multiplier,2)}


def pool_for_focus(focus):
    names = ('subject','theme','axis','subaxis')
    keys = ('category','theme','axis','subaxis')
    return [i for i,q in enumerate(QUESTIONS)
            if all(not focus.get(n) or q[k]==focus[n] for n,k in zip(names,keys))]


def user_focus(u):
    return {k:u['focus_'+k] for k in ('subject','theme','axis','subaxis')}


@app.get('/api/curriculum')
def curriculum(request: Request):
    require_user(request)
    groups = {}
    for q in QUESTIONS:
        key=(q['category'],q['theme'],q['axis'],q['subaxis'])
        groups[key]=groups.get(key,0)+1
    return [{'subject':key[0],'theme':key[1],'axis':key[2],'subaxis':key[3],'count':n}
            for key,n in sorted(groups.items())]


@app.post('/api/focus')
def save_focus(data: FocusData, request: Request):
    u = require_user(request)
    f = data.model_dump()
    # Reject partial hierarchies (axis without theme, subaxis without axis).
    for left,right in (('subject','theme'),('theme','axis'),('axis','subaxis')):
        if f[right] and not f[left]: raise HTTPException(400,'Choisis les niveaux précédents.')
    if any(f.values()) and not pool_for_focus(f):
        raise HTTPException(400,'Aucune question disponible pour cette sélection.')
    with connect() as db:
        db.execute('''UPDATE users SET focus_subject=?,focus_theme=?,focus_axis=?,focus_subaxis=? WHERE id=?''',
                   (f['subject'],f['theme'],f['axis'],f['subaxis'],u['id']))
        return {'focus':f,'question_count':len(pool_for_focus(f)),
                'profile':public_user(fresh_user(db,u['id']))}

def production_rates(u):
    owned = json.loads(u['territories'])
    return {'gold': 12 + 19*u['mine'] + (10 if 'citadel' in owned else 0),
            'wood': 9 + 17*u['sawmill'] + (8 if 'forest' in owned else 0),
            'stone': 7 + 14*u['quarry'] + (8 if 'pass' in owned else 0)}


def collect(db, user_id: int):
    u = db.execute('SELECT * FROM users WHERE id=?',(user_id,)).fetchone()
    now = time.time()
    elapsed = max(0,min(8*3600,now-u['last_collect']))
    rates = production_rates(u)
    gains,carry = {},{}
    for res in ('gold','wood','stone'):
        value = u['carry_'+res] + elapsed*rates[res]/3600
        gains[res] = int(value)
        carry[res] = value-gains[res]
    db.execute('''UPDATE users SET gold=gold+?,wood=wood+?,stone=stone+?,
                  carry_gold=?,carry_wood=?,carry_stone=?,last_collect=? WHERE id=?''',
               (gains['gold'],gains['wood'],gains['stone'],carry['gold'],carry['wood'],carry['stone'],now,user_id))
    return gains


def fresh_user(db,uid):
    return db.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()

@app.post('/api/register')
def register(data: Register, response: Response, request: Request):
    throttle(request.client.host if request.client else 'unknown')
    username = data.username.strip()
    if not re.fullmatch(r'[\w-]{3,18}',username,flags=re.UNICODE):
        raise HTTPException(400,'Pseudo : 3 à 18 caractères, lettres, chiffres, _ ou -.')
    if len(data.password)<8 or len(data.password)>128:
        raise HTTPException(400,'Mot de passe : 8 à 128 caractères.')
    if len(data.specialties)!=2 or len(set(data.specialties))!=2 or any(s not in SPECIALTIES for s in data.specialties):
        raise HTTPException(400,'Choisis deux spécialités différentes.')
    salt = secrets.token_hex(16)
    with connect() as db:
        try:
            cur = db.execute('''INSERT INTO users(username,salt,password_hash,spec1,spec2,last_collect,created_at)
                     VALUES(?,?,?,?,?,?,?)''', (username,salt,hash_password(data.password,salt),
                        *data.specialties,time.time(),datetime.now(timezone.utc).isoformat()))
            uid = cur.lastrowid
        except sqlite3.IntegrityError:
            raise HTTPException(409,'Ce pseudo est déjà utilisé.')
    create_session(response,request,uid)
    with connect() as db: return public_user(fresh_user(db,uid))

@app.post('/api/login')
def login(data: Credentials, response: Response, request: Request):
    throttle(request.client.host if request.client else 'unknown')
    with connect() as db:
        user = db.execute('SELECT * FROM users WHERE username=?',(data.username.strip(),)).fetchone()
        # fixed fallback salt/hmac to reduce timing differences for unknown accounts
        salt = user['salt'] if user else '00'*16
        expected = user['password_hash'] if user else '00'*32
        valid = hmac.compare_digest(hash_password(data.password,salt),expected)
        if not (user and valid): raise HTTPException(401,'Pseudo ou mot de passe incorrect.')
    create_session(response,request,user['id'])
    return public_user(user)

@app.post('/api/logout')
def logout(request: Request,response: Response):
    token = request.cookies.get(COOKIE)
    if token:
        with connect() as db: db.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
    response.delete_cookie(COOKIE,path='/')
    return {'ok':True}

@app.get('/api/me')
def me(request: Request):
    user = require_user(request)
    with connect() as db:
        collect(db,user['id'])
        u = fresh_user(db,user['id'])
        profile = public_user(u)
        profile['rates']=production_rates(u)
        return profile


def upgrade_cost(name, level):
    base = BUILDINGS[name]['base']
    factor = 1.57**(level-1)
    return {'gold':int(base[0]*factor),'wood':int(base[1]*factor),'stone':int(base[2]*factor)}

@app.get('/api/strategy')
def strategy(request: Request):
    user=require_user(request)
    with connect() as db:
        collect(db,user['id'])
        u=fresh_user(db,user['id'])
        return {'profile':public_user(u),'rates':production_rates(u),
                'buildings':[{'id':name,**{k:v for k,v in conf.items() if k!='base'},'level':u[name],
                              'next_cost':upgrade_cost(name,u[name]),'max_level':10} for name,conf in BUILDINGS.items()],
                'units':[{'id':name,**config,'cost':dict(zip(('gold','wood','stone'),config['cost'])),'owned':u[name]} for name,config in UNITS.items()],
                'capacity':40+u['barracks']*20,
                'territories':[{'id':name,**conf,'owned':name in json.loads(u['territories'])} for name,conf in TERRITORIES.items()]}

@app.post('/api/upgrade')
def upgrade(data: Upgrade,request: Request):
    require_user(request)
    if data.building not in BUILDINGS: raise HTTPException(400,'Bâtiment inconnu.')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        uid=require_user(request)['id']
        collect(db,uid)
        u=fresh_user(db,uid)
        level=u[data.building]
        if level>=10: raise HTTPException(400,'Niveau maximal atteint.')
        cost=upgrade_cost(data.building,level)
        if any(u[res]<num for res,num in cost.items()): raise HTTPException(400,'Ressources insuffisantes.')
        db.execute(f'''UPDATE users SET {data.building}={data.building}+1,
                    gold=gold-?,wood=wood-?,stone=stone-?,score=score+15 WHERE id=?''',
                   (cost['gold'],cost['wood'],cost['stone'],uid))
        return {'message':f'{BUILDINGS[data.building]["name"]} amélioré au niveau {level+1}.','profile':public_user(fresh_user(db,uid))}

@app.post('/api/recruit')
def recruit(data: Recruit,request: Request):
    require_user(request)
    if data.unit not in UNITS: raise HTTPException(400,'Unité inconnue.')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        uid=require_user(request)['id']
        collect(db,uid)
        u=fresh_user(db,uid)
        if data.unit=='mages' and u['academy']<2:
            raise HTTPException(400,'Académie niveau 2 nécessaire pour recruter des mages.')
        cap=40+u['barracks']*20
        if sum(u[unit] for unit in UNITS)+data.amount>cap: raise HTTPException(400,'Caserne pleine. Améliore-la.')
        cost=[x*data.amount for x in UNITS[data.unit]['cost']]
        if any(u[res]<val for res,val in zip(('gold','wood','stone'),cost)):
            raise HTTPException(400,'Ressources insuffisantes.')
        db.execute(f'''UPDATE users SET {data.unit}={data.unit}+?,
                    gold=gold-?,wood=wood-?,stone=stone-? WHERE id=?''',
                   (data.amount,*cost,uid))
        return {'message':f'{data.amount} {UNITS[data.unit]["name"].lower()} recrutés.', 'profile':public_user(fresh_user(db,uid))}

@app.post('/api/attack')
def attack(data: Attack,request: Request):
    require_user(request)
    if data.territory not in TERRITORIES: raise HTTPException(400,'Territoire inconnu.')
    if data.formation not in ('charge','flank','defend') or data.route not in ('woods','hills','bridge'):
        raise HTTPException(400,'Formation ou itinéraire invalide.')
    counts={'soldiers':data.soldiers,'archers':data.archers,'mages':data.mages}
    if not sum(counts.values()): raise HTTPException(400,'Choisis au moins une unité.')
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        uid=require_user(request)['id']
        u=fresh_user(db,uid)
        if time.time()-u['last_attack'] < 15: raise HTTPException(429,'Tes troupes se réorganisent encore (15 s).')
        for kind,count in counts.items():
            if count>u[kind]: raise HTTPException(400,f'Tu ne possèdes pas assez de {kind}.')
        owned=json.loads(u['territories'])
        if data.territory in owned: raise HTTPException(400,'Ce territoire t’appartient déjà.')
        region=TERRITORIES[data.territory]
        base=sum(counts[k]*UNITS[k]['power'] for k in counts)
        tactical=(1.20 if data.formation==region['preferred_formation'] else 0.92)
        route=(1.13 if data.route==region['preferred_route'] else 0.95)
        outcome=base*tactical*route*random.uniform(0.94,1.06)
        won=outcome>=region['defense']
        losses={k:min(v,math.ceil(v*(0.15 if won else 0.44)*random.uniform(0.8,1.2))) for k,v in counts.items()}
        remaining={k:u[k]-losses[k] for k in counts}
        reward=dict(zip(('gold','wood','stone'),region['reward'])) if won else {'gold':0,'wood':0,'stone':0}
        if won: owned.append(data.territory)
        db.execute('''UPDATE users SET soldiers=?,archers=?,mages=?,territories=?,
                      gold=gold+?,wood=wood+?,stone=stone+?,score=score+?,last_attack=? WHERE id=?''',
                   (remaining['soldiers'],remaining['archers'],remaining['mages'],json.dumps(owned),
                    reward['gold'],reward['wood'],reward['stone'],100 if won else 0,time.time(),uid))
        return {'won':won,'strength':round(outcome),'enemy_strength':region['defense'],'losses':losses,
                'reward':reward,'message':('Territoire conquis !' if won else 'Retraite : améliore ton armée ou adapte ta tactique.'),
                'profile':public_user(fresh_user(db,uid))}

@app.get('/api/quests')
def quests(request: Request):
    uid=require_user(request)['id']
    today=datetime.now(timezone.utc).date().isoformat()
    with connect() as db:
        completed=db.execute('SELECT mission FROM quest_daily WHERE user_id=? AND date=?',(uid,today)).fetchall()
        return {'missions':[{'id':k,**v} for k,v in QUESTS.items()],
                'completed_today':[x['mission'] for x in completed]}

@app.get('/api/quest/current')
def quest_current(request: Request):
    uid=require_user(request)['id']
    with connect() as db:
        row=db.execute('SELECT * FROM quest_runs WHERE user_id=?',(uid,)).fetchone()
        if not row: return {'active':False}
        indices=json.loads(row['questions'])
        if row['step']>=len(indices):return {'active':False}
        return {'active':True,'mission':row['mission'],'step':row['step'],'total':len(indices),
                'question':question_public(shuffled_question(QUESTIONS[indices[row['step']]],(uid,row['started_at'],row['step'])))}

@app.post('/api/quest/start')
def start_quest(data: QuestStart,request: Request):
    uid=require_user(request)['id']
    if data.mission not in QUESTS: raise HTTPException(400,'Mission inconnue.')
    category=QUESTS[data.mission]['category']
    pool=[i for i,q in enumerate(QUESTIONS) if q['category']==category]
    indices=random.sample(pool,min(4,len(pool)))
    started=time.time()
    with connect() as db:
        db.execute('INSERT OR REPLACE INTO quest_runs(user_id,mission,questions,step,correct,started_at) VALUES(?,?,?,?,?,?)',
                   (uid,data.mission,json.dumps(indices),0,0,started))
    return {'active':True,'mission':data.mission,'step':0,'total':4,'question':question_public(shuffled_question(QUESTIONS[indices[0]],(uid,started,0)))}

@app.post('/api/practice/start')
def start_practice(request: Request):
    u = require_user(request)
    focus = user_focus(u)
    pool = pool_for_focus(focus)
    if not pool: raise HTTPException(400,'Aucune question sur ce thème.')
    indices = random.sample(pool,min(4,len(pool)))
    started=time.time()
    with connect() as db:
        db.execute('INSERT OR REPLACE INTO quest_runs(user_id,mission,questions,step,correct,started_at) VALUES(?,?,?,?,?,?)',
                   (u['id'],'training',json.dumps(indices),0,0,started))
    return {'active':True,'mission':'training','step':0,'total':len(indices),
            'question':question_public(shuffled_question(QUESTIONS[indices[0]],(u['id'],started,0)))}

@app.post('/api/quest/abandon')
def abandon_quest(request: Request):
    uid=require_user(request)['id']
    with connect() as db:
        db.execute('DELETE FROM quest_runs WHERE user_id=?',(uid,))
    return {'ok':True}

@app.post('/api/quest/answer')
def answer_quest(data: QuestAnswer,request: Request):
    uid=require_user(request)['id']
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT * FROM quest_runs WHERE user_id=?',(uid,)).fetchone()
        if row is None: raise HTTPException(400,'Aucune mission en cours.')
        indices=json.loads(row['questions'])
        if row['step']>=len(indices):raise HTTPException(400,'Mission déjà terminée.')
        q=shuffled_question(QUESTIONS[indices[row['step']]],(uid,row['started_at'],row['step']))
        good=data.choice==q['correct']
        award=award_answer(db,uid,q['category'],good,q['q'])
        next_step=row['step']+1
        result={'correct':good,'correct_index':q['correct'],'explanation':q['explanation'],
                'earned':award,'step':next_step,'total':len(indices)}
        if next_step>=len(indices):
            db.execute('DELETE FROM quest_runs WHERE user_id=?',(uid,))
            today=datetime.now(timezone.utc).date().isoformat()
            prev=db.execute('SELECT 1 FROM quest_daily WHERE user_id=? AND mission=? AND date=?',(uid,row['mission'],today)).fetchone()
            first=prev is None
            base_reward=QUESTS[row['mission']]['reward'] if row['mission'] in QUESTS else {'gold':35,'wood':25,'stone':20}
            reward=base_reward if first else {k:int(v*.15) for k,v in base_reward.items()}
            db.execute('INSERT OR IGNORE INTO quest_daily(user_id,mission,date) VALUES(?,?,?)',(uid,row['mission'],today))
            db.execute('UPDATE users SET gold=gold+?,wood=wood+?,stone=stone+?,score=score+? WHERE id=?',
                       (reward['gold'],reward['wood'],reward['stone'],15 if first else 0,uid))
            result.update({'finished':True,'mission':row['mission'],'correct_count':row['correct']+int(good),'reward':reward,'first_today':first})
        else:
            db.execute('UPDATE quest_runs SET step=?,correct=correct+? WHERE user_id=?',(next_step,int(good),uid))
            result.update({'finished':False,'next_question':question_public(shuffled_question(QUESTIONS[indices[next_step]],(uid,row['started_at'],next_step)))})
        result['profile']=public_user(fresh_user(db,uid))
        return result

def current_boss(db,uid):
    row=db.execute('SELECT * FROM boss_runs WHERE user_id=?',(uid,)).fetchone()
    if not row: return {'active':False}
    indices=json.loads(row['questions'])
    if row['step']>=len(indices):return {'active':False}
    return {'active':True,'boss':row['boss'],'step':row['step'],'total':len(indices),
            'boss_hp':row['boss_hp'],'player_hp':row['player_hp'],'streak':row['streak'],
            'question':question_public(shuffled_question(METHOD_QUESTIONS[indices[row['step']]],(uid,row['started_at'],row['step'])))}

@app.get('/api/bosses')
def bosses_list(request: Request):
    uid=require_user(request)['id']
    today=datetime.now(timezone.utc).date().isoformat()
    with connect() as db:
        done=db.execute('SELECT boss FROM boss_daily WHERE user_id=? AND date=?',(uid,today)).fetchall()
        return {'bosses':[{'id':k,**v} for k,v in BOSSES.items()],
                'defeated_today':[x['boss'] for x in done]}

@app.get('/api/boss/current')
def boss_current(request: Request):
    uid=require_user(request)['id']
    with connect() as db:return current_boss(db,uid)

@app.post('/api/boss/start')
def start_boss(data: BossStart,request: Request):
    uid=require_user(request)['id']
    if data.boss not in BOSSES:raise HTTPException(400,'Boss inconnu.')
    pool=[i for i,q in enumerate(METHOD_QUESTIONS) if q['boss']==data.boss]
    indices=random.sample(pool,len(pool))
    with connect() as db:
        db.execute('''INSERT OR REPLACE INTO boss_runs
                   (user_id,boss,questions,step,boss_hp,player_hp,streak,started_at)
                   VALUES (?,?,?,?,?,?,?,?)''',(uid,data.boss,json.dumps(indices),0,145,100,0,time.time()))
        return current_boss(db,uid)

@app.post('/api/boss/abandon')
def abandon_boss(request: Request):
    uid=require_user(request)['id']
    with connect() as db:db.execute('DELETE FROM boss_runs WHERE user_id=?',(uid,))
    return {'ok':True}

@app.post('/api/boss/answer')
def answer_boss(data: QuestAnswer,request: Request):
    uid=require_user(request)['id']
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        run=db.execute('SELECT * FROM boss_runs WHERE user_id=?',(uid,)).fetchone()
        if not run:raise HTTPException(400,'Aucun combat de boss en cours.')
        indices=json.loads(run['questions'])
        if run['step']>=len(indices):raise HTTPException(400,'Combat terminé.')
        q=shuffled_question(METHOD_QUESTIONS[indices[run['step']]],(uid,run['started_at'],run['step']))
        good=data.choice==q['correct']
        earned=award_answer(db,uid,q['category'],good,q['q'])
        streak=run['streak']+1 if good else 0
        damage=round(26*min(3.5,1.32**(streak-1))) if good else 0
        boss_hp=max(0,run['boss_hp']-damage)
        player_hp=max(0,run['player_hp']-(0 if good else 28))
        step=run['step']+1
        won=boss_hp==0
        finished=won or player_hp==0 or step==len(indices)
        response={'correct':good,'correct_index':q['correct'],'explanation':q['explanation'],
                  'earned':earned,'damage':damage,'boss_hp':boss_hp,'player_hp':player_hp,
                  'streak':streak,'step':step,'total':len(indices),'finished':finished,'won':won}
        if finished:
            db.execute('DELETE FROM boss_runs WHERE user_id=?',(uid,))
            reward={'gold':0,'wood':0,'stone':0}
            if won:
                today=datetime.now(timezone.utc).date().isoformat()
                first=db.execute('SELECT 1 FROM boss_daily WHERE user_id=? AND boss=? AND date=?',
                                 (uid,run['boss'],today)).fetchone() is None
                base=BOSSES[run['boss']]['reward']
                reward=base if first else {k:int(v*.15) for k,v in base.items()}
                db.execute('INSERT OR IGNORE INTO boss_daily(user_id,boss,date) VALUES(?,?,?)',(uid,run['boss'],today))
                db.execute('UPDATE users SET gold=gold+?,wood=wood+?,stone=stone+? WHERE id=?',
                           (reward['gold'],reward['wood'],reward['stone'],uid))
            response['reward']=reward
        else:
            db.execute('UPDATE boss_runs SET step=?,boss_hp=?,player_hp=?,streak=? WHERE user_id=?',
                       (step,boss_hp,player_hp,streak,uid))
            response['next_question']=question_public(shuffled_question(METHOD_QUESTIONS[indices[step]],(uid,run['started_at'],step)))
        response['profile']=public_user(fresh_user(db,uid))
        return response

@app.get('/api/kingdoms')
def visitable_kingdoms(request: Request):
    require_user(request)
    with connect() as db:
        users = db.execute('''SELECT * FROM users ORDER BY knowledge_count DESC, score DESC
                            LIMIT 100''').fetchall()
        return [{**kingdom_snapshot(u),'online':u['id'] in online_users} for u in users]


@app.get('/api/kingdoms/{username}')
def visit_kingdom(username: str, request: Request):
    require_user(request)
    with connect() as db:
        u = db.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
        if u is None: raise HTTPException(404,'Ce royaume est introuvable.')
        return {**kingdom_snapshot(u),'online':u['id'] in online_users}


# Raids are asynchronous PvP challenges: only the attacking player's own army
# is committed. The defender loses NOTHING; damage is an in-game battle meter.
RAID_QUESTIONS = 5
RAID_LIMIT_PER_DAY = 5
RAID_COOLDOWN = 5 * 60  # seconds, server-side
RAID_DURATION = 24 * 3600  # expired runs are settled as retreats


def raid_defense(user):
    stationed = sum(user[k] * config['power'] for k,config in UNITS.items())
    return round(42 + user['wall']*15 + sum(user[b] for b in BUILDINGS)*2
                 + user['knowledge_count']*2.5 + stationed*0.55)


def raid_public_run(db, uid):
    r=db.execute('SELECT * FROM raid_runs WHERE attacker_id=?',(uid,)).fetchone()
    if not r:return {'active':False}
    defender=fresh_user(db,r['defender_id'])
    indices=json.loads(r['question_indices'])
    q=shuffled_question(QUESTIONS[indices[r['step']]],(uid,r['started_at'],r['step']))
    return {'active':True,'defender':defender['username'], 'defense':r['defense'],
            'damage':r['damage'], 'streak':r['streak'], 'step':r['step'],
            'total':len(indices),'units':json.loads(r['units_json']),
            'question':question_public(q)}


def close_raid(db, run, won):
    # Keep transaction ownership in the calling handler. Never permanently
    # destroy troops: all deployed units are returned even after defeat.
    uid=run['attacker_id']
    units=json.loads(run['units_json'])
    losses={kind:0 for kind in units}
    ret=units.copy()
    reward={'gold':100,'wood':60,'stone':45} if won else {'gold':0,'wood':0,'stone':0}
    score=35 if won else 0
    db.execute('''UPDATE users SET soldiers=soldiers+?,archers=archers+?,mages=mages+?,
                  gold=gold+?,wood=wood+?,stone=stone+?,score=score+? WHERE id=?''',
               (ret['soldiers'],ret['archers'],ret['mages'],reward['gold'],
                reward['wood'],reward['stone'],score,uid))
    prestige=pvp_result(db,uid,run['defender_id'],won,'async')
    db.execute('''UPDATE raid_attempts SET won=?,damage=?
                  WHERE attacker_id=? AND created_at=?''',
               (int(won),run['damage'],uid,run['started_at']))
    db.execute('DELETE FROM raid_runs WHERE attacker_id=?',(uid,))
    return {'won':won,'losses':losses,'returned':ret,'reward':reward,'victory_score':score,
            'prestige_change':prestige}


def expire_raid(db, uid):
    run=db.execute('SELECT * FROM raid_runs WHERE attacker_id=?',(uid,)).fetchone()
    if run and time.time()-run['started_at']>RAID_DURATION:
        close_raid(db,run,False)


@app.get('/api/raid/current')
def raid_current(request:Request):
    uid=require_user(request)['id']
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        expire_raid(db,uid)
        return raid_public_run(db,uid)


@app.get('/api/raid/log')
def raid_log(request:Request):
    uid=require_user(request)['id']
    with connect() as db:
        rows=db.execute('''SELECT a.created_at,a.won,a.damage,
                         u.username AS attacker,v.username AS defender
                         FROM raid_attempts a JOIN users u ON a.attacker_id=u.id
                         JOIN users v ON a.defender_id=v.id
                         WHERE (a.attacker_id=? OR a.defender_id=?) AND a.won IS NOT NULL
                         ORDER BY a.id DESC LIMIT 15''',(uid,uid)).fetchall()
        live=db.execute('''SELECT a.created_at,a.won,
                          u.username AS attacker,v.username AS defender
                          FROM pvp_battles a JOIN users u ON a.attacker_id=u.id
                          JOIN users v ON a.defender_id=v.id
                          WHERE a.mode='live' AND (a.attacker_id=? OR a.defender_id=?)
                          ORDER BY a.id DESC LIMIT 15''',(uid,uid)).fetchall()
        items=[{'created_at':r['created_at'],'won':bool(r['won']),
                'damage':r['damage'],'attacker':r['attacker'],
                'defender':r['defender'],'mode':'async'} for r in rows]
        items.extend({'created_at':r['created_at'],'won':bool(r['won']),
                      'damage':None,'attacker':r['attacker'],'defender':r['defender'],
                      'mode':'live'} for r in live)
        return sorted(items,key=lambda x:x['created_at'],reverse=True)[:15]


@app.post('/api/raid/start')
def raid_start(data:RaidStart, request:Request):
    uid=require_user(request)['id']
    counts={k:getattr(data,k) for k in UNITS}
    if not sum(counts.values()):raise HTTPException(400,'Envoie au moins une troupe.')
    today=datetime.now(timezone.utc).date().isoformat()
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        expire_raid(db,uid)
        if db.execute('SELECT 1 FROM raid_runs WHERE attacker_id=?',(uid,)).fetchone():
            raise HTTPException(409,'Un raid est déjà en cours : termine-le ou abandonne-le.')
        target=db.execute('SELECT * FROM users WHERE username=?',(data.defender.strip(),)).fetchone()
        if not target:raise HTTPException(404,'Ce royaume est introuvable.')
        if target['id']==uid:raise HTTPException(400,'Impossible d’attaquer ton propre royaume.')
        if target['shield_until']>time.time():
            raise HTTPException(409,'Ce royaume est protégé après une bataille. Réessaie plus tard.')
        used=db.execute('SELECT COUNT(*) FROM raid_attempts WHERE attacker_id=? AND utc_day=?',
                        (uid,today)).fetchone()[0]
        if used>=RAID_LIMIT_PER_DAY:raise HTTPException(429,'Tu as atteint la limite des 5 raids du jour.')
        recent=db.execute('SELECT MAX(created_at) FROM raid_attempts WHERE attacker_id=?',(uid,)).fetchone()[0]
        if recent and time.time()-recent<RAID_COOLDOWN:
            raise HTTPException(429,'Tes troupes se préparent pour leur prochaine expédition (5 minutes).')
        already=db.execute('SELECT 1 FROM raid_attempts WHERE attacker_id=? AND defender_id=? AND utc_day=?',
                           (uid,target['id'],today)).fetchone()
        if already:raise HTTPException(409,'Tu as déjà défié ce royaume aujourd’hui.')
        attacker=fresh_user(db,uid)
        for kind,count in counts.items():
            if count>attacker[kind]:raise HTTPException(400,'Tu ne possèdes pas assez de troupes.')
        focus=user_focus(attacker)
        pool=pool_for_focus(focus)
        if len(pool)<RAID_QUESTIONS:
            pool=pool_for_focus({'subject':focus['subject']})
        if len(pool)<RAID_QUESTIONS:pool=list(range(len(QUESTIONS)))
        indices=secrets.SystemRandom().sample(pool,min(RAID_QUESTIONS,len(pool)))
        started=time.time()
        db.execute('UPDATE users SET soldiers=soldiers-?,archers=archers-?,mages=mages-? WHERE id=?',
                   (counts['soldiers'],counts['archers'],counts['mages'],uid))
        db.execute('''INSERT INTO raid_runs(attacker_id,defender_id,question_indices,defense,units_json,started_at)
                      VALUES(?,?,?,?,?,?)''',
                   (uid,target['id'],json.dumps(indices),raid_defense(target),json.dumps(counts),started))
        db.execute('''INSERT INTO raid_attempts(attacker_id,defender_id,created_at,utc_day)
                      VALUES(?,?,?,?)''',(uid,target['id'],started,today))
        return {'raid':raid_public_run(db,uid),'profile':public_user(fresh_user(db,uid))}


@app.post('/api/raid/answer')
def raid_answer(data:QuestAnswer,request:Request):
    uid=require_user(request)['id']
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        expire_raid(db,uid)
        r=db.execute('SELECT * FROM raid_runs WHERE attacker_id=?',(uid,)).fetchone()
        if not r:raise HTTPException(404,'Aucun raid actif.')
        indices=json.loads(r['question_indices'])
        q=shuffled_question(QUESTIONS[indices[r['step']]],(uid,r['started_at'],r['step']))
        correct=data.choice==q['correct']
        awarded=award_answer(db,uid,q['category'],correct,question_key=q['q'])
        streak=r['streak']+1 if correct else 0
        strength=sum(json.loads(r['units_json'])[k]*v['power'] for k,v in UNITS.items())
        damage=round(strength*0.32*(1+0.12*min(streak-1,4))) if correct else 0
        damage=max(1,damage) if correct else 0
        total_damage=r['damage']+damage
        step=r['step']+1
        won=total_damage>=r['defense']
        finished=won or step>=len(indices)
        db.execute('UPDATE raid_runs SET damage=?,step=?,streak=? WHERE attacker_id=?',
                   (total_damage,step,streak,uid))
        result={'correct':correct,'correct_index':q['correct'],'explanation':q['explanation'],
                'earned':awarded,'damage_dealt':damage,'damage':total_damage,
                'defense':r['defense'],'streak':streak,'step':step,'finished':finished}
        if finished:
            r=db.execute('SELECT * FROM raid_runs WHERE attacker_id=?',(uid,)).fetchone()
            result.update(close_raid(db,r,won))
        else:
            result['next_question']=question_public(shuffled_question(QUESTIONS[indices[step]],
                                                    (uid,r['started_at'],step)))
        result['profile']=public_user(fresh_user(db,uid))
        return result


@app.post('/api/raid/abandon')
def raid_abandon(request:Request):
    uid=require_user(request)['id']
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        run=db.execute('SELECT * FROM raid_runs WHERE attacker_id=?',(uid,)).fetchone()
        if not run:raise HTTPException(404,'Aucun raid actif.')
        result=close_raid(db,run,False)
        return {'message':'Retraite ordonnée. Toutes tes troupes reviennent.',
                **result,'profile':public_user(fresh_user(db,uid))}


DRAW_PRIZES = (
    (600, 15, 'Commun'),    # 60 %
    (900, 30, 'Peu commun'),# 30 %
    (990, 70, 'Rare'),      # 9 %
    (1000, 140, 'Légendaire'),# 1 %
)

@app.get('/api/daily-draw')
def daily_draw_state(request: Request):
    uid=require_user(request)['id']
    today=datetime.now(timezone.utc).date().isoformat()
    with connect() as db:
        previous=db.execute('SELECT reward,rarity FROM daily_draws WHERE user_id=? AND date=?',
                            (uid,today)).fetchone()
        return {'available':previous is None, 'date_utc':today,
                'previous':dict(previous) if previous else None,
                'odds':[{'probability':pct, 'score':score, 'rarity':name}
                        for pct,score,name in [(60,15,'Commun'),(30,30,'Peu commun'),
                                               (9,70,'Rare'),(1,140,'Légendaire')]]}


@app.post('/api/daily-draw')
def daily_draw(request: Request):
    uid=require_user(request)['id']
    today=datetime.now(timezone.utc).date().isoformat()
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute('SELECT 1 FROM daily_draws WHERE user_id=? AND date=?',(uid,today)).fetchone():
            raise HTTPException(409,'Tu as déjà reçu ton bonus gratuit aujourd’hui (UTC).')
        roll=secrets.randbelow(1000)
        _,points,rarity=next(prize for prize in DRAW_PRIZES if roll<prize[0])
        db.execute('INSERT INTO daily_draws(user_id,date,reward,rarity) VALUES(?,?,?,?)',
                   (uid,today,points,rarity))
        db.execute('UPDATE users SET score=score+? WHERE id=?',(points,uid))
        return {'score':points,'rarity':rarity,'profile':public_user(fresh_user(db,uid))}


def chapter_unlocked(db,uid,user,chapter):
    req=chapter['requires']
    territories=json.loads(user['territories'])
    if req=='start':return True
    if req=='quest':return db.execute('SELECT 1 FROM quest_daily WHERE user_id=? LIMIT 1',(uid,)).fetchone() is not None
    if req=='forest':return 'forest' in territories
    if req=='boss':return db.execute('SELECT 1 FROM boss_daily WHERE user_id=? LIMIT 1',(uid,)).fetchone() is not None
    if req=='citadel':return 'citadel' in territories
    return False


@app.get('/api/story')
def story_state(request: Request):
    uid=require_user(request)['id']
    with connect() as db:
        user=fresh_user(db,uid)
        claimed={r['chapter'] for r in db.execute('SELECT chapter FROM story_claims WHERE user_id=?',(uid,))}
        output=[]
        for i,ch in enumerate(CHAPTERS):
            c=dict(ch)
            c['claimed']=ch['id'] in claimed
            c['unlocked']=chapter_unlocked(db,uid,user,ch) and (i==0 or CHAPTERS[i-1]['id'] in claimed)
            output.append(c)
        return {'chapters':output}


@app.post('/api/story/{chapter_id}/claim')
def story_claim(chapter_id: str,request: Request):
    uid=require_user(request)['id']
    with connect() as db:
        db.execute('BEGIN IMMEDIATE')
        chapter=next((c for c in CHAPTERS if c['id']==chapter_id),None)
        if not chapter:raise HTTPException(404,'Chapitre inconnu.')
        index=CHAPTERS.index(chapter)
        user=fresh_user(db,uid)
        if not chapter_unlocked(db,uid,user,chapter):
            raise HTTPException(403,'Objectif du chapitre non accompli.')
        if index and not db.execute('SELECT 1 FROM story_claims WHERE user_id=? AND chapter=?',
                                     (uid,CHAPTERS[index-1]['id'])).fetchone():
            raise HTTPException(403,'Termine le chapitre précédent.')
        inserted=db.execute('''INSERT OR IGNORE INTO story_claims(user_id,chapter,claimed_at)
                               VALUES(?,?,?)''',
                            (uid,chapter_id,datetime.now(timezone.utc).isoformat())).rowcount
        if not inserted:raise HTTPException(409,'Récompense déjà obtenue.')
        reward=chapter['reward']
        db.execute('UPDATE users SET gold=gold+?,wood=wood+?,stone=stone+? WHERE id=?',
                   (reward['gold'],reward['wood'],reward['stone'],uid))
        return {'chapter':chapter_id,'resolution':chapter['resolution'],
                'reward':reward,'profile':public_user(fresh_user(db,uid))}


@app.get('/api/leaderboard')
def leaderboard(request: Request):
    require_user(request)
    with connect() as db:
        rows=db.execute('''SELECT username,score,xp,spec1,spec2,territories FROM users
                           ORDER BY score DESC, xp DESC LIMIT 100''').fetchall()
        return [{'rank':i+1,'username':r['username'],'score':r['score'], 'level':1+int(math.sqrt(r['xp']/90)),
                 'territories':len(json.loads(r['territories'])),'specialties':[r['spec1'],r['spec2']]}
                for i,r in enumerate(rows)]

@dataclass
class Room:
    code: str
    mode: str
    host: int
    members: dict[int,dict] = field(default_factory=dict)
    status: str = 'waiting'
    round_index: int = -1
    question: dict | None = None
    deadline: float = 0
    reveal: dict | None = None
    task: asyncio.Task | None = None
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    focus: dict = field(default_factory=dict)
    total_rounds: int = ROOM_ROUNDS
    created_at: float = field(default_factory=time.time)
    defender_id: int | None = None

rooms:dict[str,Room]={}
rooms_lock=asyncio.Lock()
online_users:dict[int,WebSocket]={}

def room_snapshot(room:Room):
    return {'type':'room','code':room.code,'mode':room.mode,'host':room.host,
            'status':room.status,'defender_id':room.defender_id,'round':room.round_index+1 if room.round_index>=0 else 0,
            'total_rounds':room.total_rounds,'deadline':room.deadline,'focus':room.focus,
            'question':question_public(room.question) if room.question and room.status=='playing' else None,
            'reveal':room.reveal,
            'players':[{'id':u,'name':p['name'],'score':p['score'],'hp':p['hp'],'damage':p['damage'],
                        'correct':p['correct'],'streak':p.get('streak',0),'answered':p.get('round_answer') is not None,'online':p['ws'] is not None}
                       for u,p in room.members.items()]}

async def broadcast(room: Room):
    payload=room_snapshot(room)
    for p in list(room.members.values()):
        if p['ws'] is not None:
            try: await p['ws'].send_json(payload)
            except Exception: p['ws']=None

async def send_error(ws:WebSocket,msg:str):
    await ws.send_json({'type':'error','message':msg})

async def play_room(room:Room):
    try:
        cats = []
        with connect() as db:
            for uid in room.members:
                u=fresh_user(db,uid)
                if u: cats.extend([u['spec1'],u['spec2']])
        pool=pool_for_focus(room.focus) if any(room.focus.values()) else list(range(len(QUESTIONS)))
        if room.mode=='siege' and len(pool)<3:
            pool=list(range(len(QUESTIONS)))
        # The host's focus is shared by everyone; never silently leave the topic.
        room.total_rounds=min(ROOM_ROUNDS,len(pool))
        chosen=random.sample(pool,room.total_rounds)
        for idx in chosen:
            q=shuffled_question(QUESTIONS[idx])
            room.round_index+=1
            room.question=q
            room.reveal=None
            room.deadline=time.time()+ROUND_SECONDS
            for p in room.members.values():p['round_answer']=None
            await broadcast(room)
            await asyncio.sleep(ROUND_SECONDS)
            room.deadline=0
            # An unanswered round breaks a consecutive-answer streak.
            with connect() as db:
                for pid, member in room.members.items():
                    if member.get('round_answer') is None:
                        member['streak']=0
                        award_answer(db,pid,q['category'],False)
            room.reveal={'correct_index':q['correct'],'explanation':q['explanation'],'category':q['category']}
            await broadcast(room)
            await asyncio.sleep(REVEAL_SECONDS)
        room.status='finished'
        room.question=None
        room.reveal=None
        room.deadline=0
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if room.mode=='siege':
                attacker,defender=room.host,room.defender_id
                if attacker in room.members and defender in room.members:
                    a,d=room.members[attacker],room.members[defender]
                    won=(a['hp']>d['hp'] or (a['hp']==d['hp'] and a['damage']>d['damage']))
                    room.siege_outcome={'won':won,'attacker':a['name'],'defender':d['name'],
                                        **pvp_result(db,attacker,defender,won,'live')}
            for uid,p in room.members.items():
                if room.mode=='party':
                    reward={'gold':p['correct']*18+15,'wood':p['correct']*12+10,
                            'stone':p['correct']*9+6}
                else:
                    reward={'gold':p['correct']*11+10,'wood':p['correct']*5+5,
                            'stone':p['correct']*5+5}
                db.execute('UPDATE users SET gold=gold+?,wood=wood+?,stone=stone+? WHERE id=?',
                           (*reward.values(),uid))
                p['reward']=reward
        payload=room_snapshot(room)
        payload['rewards']={str(uid):p['reward'] for uid,p in room.members.items()}
        if room.mode=='siege' and hasattr(room,'siege_outcome'):
            payload['siege_outcome']=room.siege_outcome
        for p in room.members.values():
            if p['ws']:
                try: await p['ws'].send_json(payload)
                except Exception:pass
    except asyncio.CancelledError:
        raise
    except Exception as exc:
        room.status='finished'
        for p in room.members.values():
            if p['ws']:
                try: await p['ws'].send_json({'type':'error','message':'La partie a été interrompue.'})
                except Exception: pass
        print('Game room error:',repr(exc))

async def detach(uid:int, room:Room|None, ws:WebSocket):
    if room is None: return
    async with rooms_lock:
        member=room.members.get(uid)
        if not member or member['ws'] is not ws:return
        if room.status=='waiting' or room.status=='finished':
            del room.members[uid]
            if uid==room.host and room.members:room.host=next(iter(room.members))
        else:
            member['ws']=None
        if not room.members or all(p['ws'] is None for p in room.members.values()):
            if room.task and not room.task.done(): room.task.cancel()
            rooms.pop(room.code,None)
        else: await broadcast(room)

@app.websocket('/ws')
async def websocket_game(ws:WebSocket):
    origin=ws.headers.get('origin')
    # Browser Origin check: prevents unrelated sites from riding cookie auth.
    if origin and urlparse(origin).netloc != ws.headers.get('host'):
        await ws.close(code=1008)
        return
    user=session_user(ws.cookies.get(COOKIE))
    if user is None:
        await ws.close(code=1008)
        return
    await ws.accept()
    uid=user['id']
    online_users[uid]=ws
    room:Room|None=None
    await ws.send_json({'type':'hello','id':uid})
    try:
        while True:
            msg=await ws.receive_json()
            op=msg.get('type') if isinstance(msg,dict) else None
            # An invitation can be rejected or expire while the attacker waits.
            if room and room.mode=='siege' and (room.code not in rooms or
                  (room.status=='invited' and time.time()-room.created_at>90)):
                if room.code in rooms:
                    await detach(uid,room,ws)
                room=None
            if op=='siege_challenge':
                if room:await send_error(ws,'Quitte d’abord ton salon.');continue
                target_name=str(msg.get('username','')).strip()
                with connect() as db:
                    target=db.execute('SELECT * FROM users WHERE username=?',(target_name,)).fetchone()
                    source=fresh_user(db,uid)
                    if not target or target['id']==uid:
                        await send_error(ws,'Choisis un autre royaume.');continue
                    if target['shield_until']>time.time():
                        await send_error(ws,'Ce royaume bénéficie d’un bouclier.');continue
                    today=datetime.now(timezone.utc).date().isoformat()
                    used=db.execute('SELECT COUNT(*) FROM pvp_battles WHERE attacker_id=? AND created_at>=?',
                                   (uid,time.time()-86400)).fetchone()[0]
                    if used>=RAID_LIMIT_PER_DAY:
                        await send_error(ws,'Limite de 5 batailles en direct sur 24 heures.');continue
                defender_socket=online_users.get(target['id'])
                if not defender_socket:
                    await send_error(ws,'Joueur hors ligne : utilise le raid en différé.');continue
                async with rooms_lock:
                    if any(r.mode=='siege' and r.status!='finished' and target['id'] in r.members for r in rooms.values()):
                        await send_error(ws,'Ce joueur est déjà en combat.');continue
                    code=''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(6))
                    while code in rooms:code=''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(6))
                    room=Room(code=code,mode='siege',host=uid,defender_id=target['id'],
                              status='invited',focus=user_focus(source))
                    room.members[uid]={'name':user['username'],'ws':ws,'score':0,'hp':140,'damage':0,'correct':0,'streak':0,'round_answer':None}
                    rooms[code]=room
                await ws.send_json({'type':'siege_waiting','code':code,'target':target_name})
                await defender_socket.send_json({'type':'siege_invite','code':code,'attacker':user['username']})
            elif op=='siege_accept':
                code=str(msg.get('code','')).strip().upper()
                async with rooms_lock:
                    candidate=rooms.get(code)
                    if not candidate or candidate.mode!='siege' or candidate.defender_id!=uid or candidate.status!='invited' or time.time()-candidate.created_at>90:
                        await send_error(ws,'Invitation expirée ou introuvable.');continue
                    if room:
                        await send_error(ws,'Quitte ton salon avant d’accepter.');continue
                    if not candidate.members.get(candidate.host,{}).get('ws'):
                        await send_error(ws,'L’attaquant n’est plus en ligne.');continue
                    room=candidate
                    room.members[uid]={'name':user['username'],'ws':ws,'score':0,'hp':140,'damage':0,'correct':0,'streak':0,'round_answer':None}
                    room.status='playing'
                    room.task=asyncio.create_task(play_room(room))
            elif op=='siege_decline':
                code=str(msg.get('code','')).strip().upper()
                candidate=rooms.get(code)
                if candidate and candidate.mode=='siege' and candidate.defender_id==uid and candidate.status=='invited':
                    await send_error(candidate.members[candidate.host]['ws'],'Le défenseur a refusé le duel.')
                    if candidate.members[candidate.host]['ws']:
                        await candidate.members[candidate.host]['ws'].send_json({'type':'siege_declined'})
                    rooms.pop(code,None)
            elif op=='create':
                if room: await send_error(ws,'Quitte d’abord ton salon.');continue
                mode=msg.get('mode')
                if mode not in ('party','arena'):await send_error(ws,'Mode invalide.');continue
                async with rooms_lock:
                    code=''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(6))
                    while code in rooms:code=''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(6))
                    room=Room(code=code,mode=mode,host=uid,focus=user_focus(user))
                    room.members[uid]={'name':user['username'],'ws':ws,'score':0,'hp':100,'damage':0,'correct':0,'streak':0,'round_answer':None}
                    rooms[code]=room
                await broadcast(room)
            elif op=='join':
                if room:await send_error(ws,'Quitte d’abord ton salon.');continue
                code=str(msg.get('code','')).upper().strip()
                async with rooms_lock:
                    candidate=rooms.get(code)
                    if not candidate:await send_error(ws,'Salon introuvable.');continue
                    if candidate.mode=='siege':
                        if uid not in candidate.members or candidate.status!='playing':
                            await send_error(ws,'Ce duel est sur invitation.');continue
                        candidate.members[uid]['ws']=ws
                        room=candidate
                        await broadcast(room)
                        continue
                    if candidate.status!='waiting' and uid not in candidate.members:
                        await send_error(ws,'Cette partie a déjà commencé.');continue
                    if uid not in candidate.members and len(candidate.members)>=MAX_ROOM:
                        await send_error(ws,'Salon plein (60 joueurs).');continue
                    if uid in candidate.members:
                        old=candidate.members[uid]['ws']
                        if old and old is not ws:
                            try:await old.close(code=4000)
                            except Exception:pass
                        candidate.members[uid]['ws']=ws
                    else:
                        candidate.members[uid]={'name':user['username'],'ws':ws,'score':0,'hp':100,'damage':0,'correct':0,'streak':0,'round_answer':None}
                    room=candidate
                await broadcast(room)
            elif op=='leave':
                await detach(uid,room,ws)
                room=None
                await ws.send_json({'type':'left'})
            elif op=='start':
                if not room:await send_error(ws,'Rejoins un salon.');continue
                if room.host!=uid:await send_error(ws,'Seul l’hôte peut lancer la partie.');continue
                if room.status!='waiting':await send_error(ws,'Partie déjà lancée.');continue
                if len(room.members)<2:await send_error(ws,'Il faut au moins 2 joueurs.');continue
                room.status='playing'
                room.task=asyncio.create_task(play_room(room))
            elif op=='answer':
                if not room or room.status!='playing' or not room.question or room.reveal is not None:
                    await send_error(ws,'Pas de question en cours.');continue
                if time.time()>room.deadline:
                    await send_error(ws,'Temps écoulé.');continue
                choice=msg.get('choice')
                if type(choice) is not int or not 0<=choice<=3:
                    await send_error(ws,'Réponse invalide.');continue
                if msg.get('round')!=room.round_index+1:
                    await send_error(ws,'Cette question n’est plus active.');continue
                async with room.lock:
                    player=room.members.get(uid)
                    if not player or player['round_answer'] is not None:
                        await send_error(ws,'Tu as déjà répondu.');continue
                    player['round_answer']=choice
                    if choice==room.question['correct']:
                        with connect() as db:
                            u=fresh_user(db,uid)
                            _,_,spec=points_for(u,room.question['category'])
                            award=award_answer(db,uid,room.question['category'],True,room.question['q'])
                        player['score']+=award['score']
                        player['streak']+=1
                        player['correct']+=1
                        if room.mode in ('arena','siege'):
                            power=msg.get('power','attack')
                            if power=='guard':player['hp']=min(140,player['hp']+22)
                            else:
                                targets=[id_ for id_ in room.members if id_!=uid]
                                target=msg.get('target')
                                if type(target) is not int or target not in targets:target=random.choice(targets)
                                damage=30 if spec else 19
                                if room.mode=='siege':
                                    with connect() as db:
                                        attacker=fresh_user(db,uid)
                                        stationed=sum(attacker[k]*v['power'] for k,v in UNITS.items())
                                        damage=min(48,damage+min(12,stationed//90)+min(8,player['streak']*2))
                                room.members[target]['hp']=max(0,room.members[target]['hp']-damage)
                                player['damage']+=damage
                    else:
                        with connect() as db:award_answer(db,uid,room.question['category'],False)
                        player['streak']=0
                    await broadcast(room)
            else:
                await send_error(ws,'Commande inconnue.')
    except (WebSocketDisconnect,RuntimeError,ValueError):
        pass
    finally:
        if online_users.get(uid) is ws: online_users.pop(uid,None)
        await detach(uid,room,ws)
