"""Editable taxonomy for the demonstration question bank.
Each entry follows QUESTIONS index: (theme, axis, subaxis).
The taxonomy reflects *this demo bank*, not a claim of complete official curricula.
"""
TAGS = [
 # SVT 0-9
 ('À la recherche du passé géologique de notre planète','Dynamique lithosphérique','Rifting et marges passives'),
 ('À la recherche du passé géologique de notre planète','Dynamique lithosphérique','Fusion par décompression'),
 ('De la plante sauvage à la plante domestiquée','Organisation des plantes','Xylème et transport'),
 ('De la plante sauvage à la plante domestiquée','Échanges et nutrition','Stomates et cellules de garde'),
 ('De la plante sauvage à la plante domestiquée','Échanges et nutrition','Osmose'),
 ('À la recherche du passé géologique de notre planète','Datation des événements','Datation absolue'),
 ('À la recherche du passé géologique de notre planète','Dynamique lithosphérique','Indices de subduction'),
 ('De la plante sauvage à la plante domestiquée','Organisation des plantes','Adaptation des feuilles'),
 ('De la plante sauvage à la plante domestiquée','Échanges et nutrition','Turgescence'),
 ('À la recherche du passé géologique de notre planète','Dynamique lithosphérique','Collision continentale'),
 # HGGSP 10-19
 ('Faire la guerre, faire la paix','Axe 1 · Dimension politique de la guerre','Clausewitz : guerre absolue'),
 ('Faire la guerre, faire la paix','Axe 1 · Dimension politique de la guerre','Clausewitz : guerre et politique'),
 ('Faire la guerre, faire la paix','Axe 1 · Dimension politique de la guerre','Guerres révolutionnaires'),
 ('Faire la guerre, faire la paix','Axe 1 · Dimension politique de la guerre','Guerres mondiales'),
 ('Faire la guerre, faire la paix','Axe 1 · Dimension politique de la guerre','Terrorisme et conflits asymétriques'),
 ('Méthode du bac','Étude critique de documents','Confrontation des sources'),
 ('Faire la guerre, faire la paix','Axe 2 · Construire la paix','ONU'),
 ('Faire la guerre, faire la paix','Axe 2 · Construire la paix','Paix négative et positive'),
 ('Faire la guerre, faire la paix','Axe 1 · Dimension politique de la guerre','Terrorisme et conflits asymétriques'),
 ('Faire la guerre, faire la paix','Axe 2 · Construire la paix','Traités de Westphalie'),
 # Philosophie 20-25
 ('La conscience','Le sujet et la pensée','Cogito de Descartes'),
 ('La conscience','Conscience et inconscient','Freud'),
 ('La conscience','Le sujet et la pensée','Introspection'),
 ('La conscience','Le sujet et la pensée','Conscience immédiate et réfléchie'),
 ('Méthode du bac','Dissertation','Thèse et argumentation'),
 ('La conscience','Conscience et liberté','Mauvaise foi chez Sartre'),
 # histoire 26-30
 ('Crises économiques et politiques','La crise de 1929','Krach boursier'),
 ('Crises économiques et politiques','La crise de 1929','New Deal'),
 ('Les guerres mondiales','Première Guerre mondiale','Armistice de 1918'),
 ('Géographie','Dynamiques spatiales','Exode rural'),
 ('Géographie','Dynamiques spatiales','Métropolisation'),
 # enseignement scientifique 31-35
 ('Énergie et électricité','Électricité','Puissance électrique'),
 ('Énergie et électricité','Électricité','Calcul de puissance'),
 ('Climat','Effet de serre','CO₂'),
 ('Énergie et électricité','Transition énergétique','Énergies renouvelables'),
 ('Ondes','Notions fondamentales','Fréquence'),
 # anglais 36-40
 ('Territory and Memory','Culture and heritage','Cultural heritage'),
 ('Territory and Memory','Grammar','Present perfect'),
 ('Territory and Memory','Culture and heritage','Commemoration'),
 ('Territory and Memory','Writing','Connectors'),
 ('Territory and Memory','Identity','Belonging'),
 # Espagnol 41-45
 ('Territorio y memoria','Vocabulario','Memoria colectiva'),
 ('Territorio y memoria','Vocabulario','Territorio'),
 ('Territorio y memoria','Vocabulario','Recordar'),
 ('Territorio y memoria','Gramática','Ser'),
 ('Territorio y memoria','Vocabulario','El pasado'),
 # Maths 46-48
 ('Analyse','Dérivation','Fonction puissance'),
 ('Suites','Suites géométriques','Terme général'),
 ('Analyse','Logarithme','ln(1)'),
 # Physique 49-51
 ('Mouvement','Dynamique','Deuxième loi de Newton'),
 ('Chimie','Acide-base','Brønsted'),
 ('Ondes','Lumière','Vitesse de la lumière'),
 # SES 52-54
 ('Économie','Croissance','PIB'),
 ('Économie','Défaillances du marché','Externalités'),
 ('Économie','Politique économique','BCE'),
 # HLP 55-57
 ('Argumentation','Construire une thèse','Justification'),
 ('Littérature','Figures de style','Métaphore'),
 ('Humanisme','Renaissance','Éducation'),
 # NSI 58-60
 ('Structures de données','Structures linéaires','Pile LIFO'),
 ('Bases de données','Modèle relationnel','Clé primaire'),
 ('Algorithmique','Complexité','Recherche binaire'),
]

BOSSES = {
 'archiviste': {'name':'L’Archiviste des Sources','icon':'📜','category':'HGGSP',
    'description':'Vaincs un gardien des archives grâce à la méthode de l’étude critique de documents.',
    'reward':{'gold':160,'wood':95,'stone':90}},
 'sphinx': {'name':'Le Sphinx de la Dissertation','icon':'🧠','category':'Philosophie',
    'description':'Construis une dissertation solide : problème, plan, arguments et exemples.',
    'reward':{'gold':155,'wood':105,'stone':85}},
 'titan': {'name':'Le Titan de la Synthèse','icon':'🧬','category':'SVT',
    'description':'Maîtrise la démarche scientifique, la restitution organisée et l’analyse des résultats.',
    'reward':{'gold':175,'wood':90,'stone':100}},
}

def mq(boss, q, options, correct, explanation):
    return dict(boss=boss,category=BOSSES[boss]['category'],q=q,options=options,correct=correct,explanation=explanation)

METHOD_QUESTIONS = [
 mq('archiviste','Quel est le premier réflexe face à un document historique ?',
    ['Identifier nature, auteur, date et contexte','Recopier la première phrase','Ignorer sa provenance','Rédiger directement la conclusion'],0,'L’identification critique du document aide à situer son point de vue et sa fiabilité.'),
 mq('archiviste','Que doit contenir une problématique pertinente ?',
    ['Une vraie question liée au sujet et aux documents','Une simple liste de dates','Le titre exactement recopié','Une opinion sans justification'],0,'La problématique guide une démonstration liée à la consigne.'),
 mq('archiviste','À quoi sert une connaissance extérieure au document ?',
    ['Contextualiser, expliquer ou nuancer une affirmation','Remplacer complètement le document','Multiplier les citations','Éviter toute analyse'],0,'Dans une étude critique, les connaissances éclairent les informations et limites des sources.'),
 mq('archiviste','Un document de propagande peut-il être exploité ?',
    ['Oui, en analysant son objectif et ses biais','Non, il est toujours inutile','Oui, sans évoquer l’auteur','Seulement si sa date est absente'],0,'Les biais sont aussi des informations sur les objectifs et représentations de l’auteur.'),
 mq('archiviste','Comment citer efficacement un extrait ?',
    ['Une courte citation suivie d’une explication','Une page entière recopiée','Sans lien avec l’argument','Sans contextualisation'],0,'La citation soutient une interprétation et ne remplace pas l’analyse.'),
 mq('archiviste','Quelle conclusion est la plus adaptée ?',
    ['Répondre à la problématique et indiquer les limites','Introduire un argument nouveau sans transition','Réécrire mot à mot les sources','Ignorer les limites documentaires'],0,'La conclusion formule une réponse synthétique et mesure la portée du corpus.'),
 mq('sphinx','Dans l’introduction de dissertation, la problématisation consiste à…',
    ['Faire apparaître la difficulté philosophique du sujet','Lister toutes les définitions du dictionnaire','Donner immédiatement une réponse sans nuance','Parler de sa vie personnelle'],0,'Il faut faire apparaître une tension ou une difficulté qui justifie l’enquête.'),
 mq('sphinx','Quel est le rôle d’un exemple ?',
    ['Illustrer et tester un argument','Remplacer tout raisonnement','Donner seulement une anecdote décorative','Raccourcir artificiellement la copie'],0,'Un exemple pertinent éclaire une justification et gagne à être analysé.'),
 mq('sphinx','Une objection utile sert à…',
    ['Éprouver une thèse et faire progresser le raisonnement','Supprimer le sujet','Prouver que toutes les positions sont égales','Éviter les transitions'],0,'Mettre une thèse à l’épreuve permet de dépasser une réponse simpliste.'),
 mq('sphinx','Une bonne transition entre deux parties…',
    ['Montre la limite de l’étape précédente et le besoin de la suivante','Annonce seulement un nouveau numéro','Répète mot pour mot le titre','Se réduit à une citation'],0,'La progression du plan doit suivre une nécessité argumentative.'),
 mq('sphinx','Quel rapport établir entre auteur et argument ?',
    ['Expliquer comment sa thèse sert le raisonnement','Citer des noms sans les comprendre','Ajouter des citations au hasard','Toujours rejeter toutes les références'],0,'L’auteur est une ressource conceptuelle, pas un argument d’autorité automatique.'),
 mq('sphinx','Comment conclure une dissertation ?',
    ['Répondre explicitement à la question après le parcours argumenté','Ajouter une nouvelle partie','Ne rien décider','Changer de sujet'],0,'La conclusion reprend les acquis du développement pour formuler une réponse nuancée.'),
 mq('titan','Pour une synthèse de SVT, quelle structure est la plus claire ?',
    ['Introduction, raisonnement organisé, conclusion','Inventaire de mots-clés','Une succession de schémas non légendés','Un seul paragraphe sans liens'],0,'Un raisonnement structuré répond directement au problème scientifique posé.'),
 mq('titan','Face à deux résultats expérimentaux contradictoires, il faut…',
    ['Comparer les conditions, limites et contrôles','Ignorer le résultat gênant','Modifier les valeurs','Faire une conclusion avant l’analyse'],0,'Les paramètres, témoins et incertitudes permettent d’interpréter les écarts.'),
 mq('titan','Une hypothèse scientifique doit être…',
    ['Testable et cohérente avec le problème','Impossible à confronter aux faits','Toujours vraie','Une opinion morale'],0,'Une hypothèse doit pouvoir être mise à l’épreuve par des observations ou expériences.'),
 mq('titan','Pourquoi utiliser un témoin en expérience ?',
    ['Distinguer l’effet du facteur étudié des autres effets','Faire joli dans le protocole','Augmenter les résultats au hasard','Remplacer la répétition'],0,'Le témoin sert de référence pour interpréter une variation.'),
 mq('titan','Quel rôle a un schéma scientifique ?',
    ['Représenter clairement un mécanisme avec légende et titre','Décorer la copie','Éviter toute explication','Introduire des éléments imaginaires'],0,'Un schéma fonctionnel doit être exact, titré, légendé et utile à la démonstration.'),
 mq('titan','Pour interpréter un graphique, il faut d’abord…',
    ['Lire axes, unités et conditions','Décrire uniquement les couleurs','Ignorer l’échelle','Conclure sans chiffres'],0,'L’analyse mobilise les variables et les valeurs, avant une explication biologique ou géologique.'),
]
