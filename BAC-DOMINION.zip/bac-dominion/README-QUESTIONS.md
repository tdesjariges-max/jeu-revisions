# Questions par chapitre et choix des thèmes

## Ce que contient cette version

**4 927 questions** jouables, sur **96 chapitres/axes affichés**, avec un minimum vérifié de **50 questions dans chacun**. Les 127 questions déjà présentes conservent leur position et leur identifiant. Les 18 anciennes questions spécifiques aux boss restent séparées de ce total.

| Matière | Questions |
|---|---:|
| HGGSP | 969 |
| SVT | 770 |
| Philosophie | 923 |
| Histoire-géographie | 461 |
| Enseignement scientifique | 161 |
| Anglais | 411 |
| Espagnol | 411 |
| EMC | 56 |
| Mathématiques | 153 |
| Physique-chimie | 153 |
| SES | 153 |
| HLP | 153 |
| NSI | 153 |

Le détail des 96 chapitres et de leurs quantités est dans `data/coverage.csv` et dans le catalogue du jeu. Le minimum s’applique à **Matière → Thème → Chapitre / axe**, avant les filtres plus fins. Une notion précise ou une difficulté peut proposer moins de 50 questions. Les parties restent courtes : la banque de 50 questions n’impose pas une session de 50 manches.

Les 4 800 ajouts comprennent :

- 88 chapitres avec 25 repères/notions/entrées de lexique, chacun travaillé par une identification et une mise en situation rédigée ; cela donne 50 QCM, pas 50 concepts différents.
- 8 chapitres de calculs et de manipulation de structures de données avec cinq familles d’exercices, dix cas chacune.

Toutes les questions ont quatre choix distincts, une réponse, une explication, une difficulté, des métadonnées et une référence de cadre pédagogique. Les choix et l’ordre de jeu sont mélangés côté serveur. Aucun service de génération externe n’est appelé pendant le jeu.

## Choix en solo

Le livre « Je révise en ce moment » permet de choisir une matière, un thème, puis éventuellement un chapitre et une notion. Le compteur et les listes indiquent les nombres réellement disponibles. **Les révisions, l’arène solo et la course restent dans cette sélection** ; une sélection vide ne provoque jamais un élargissement silencieux.

Changer de sélection supprime uniquement la courte révision classique en attente, pour commencer sur le nouveau thème. Les points déjà obtenus, comptes, royaumes et ressources sont conservés. Une arène ou une course déjà en cours garde sa sélection de départ, affichée dans ses indications ; abandonne ce défi ou termine-le pour utiliser le nouveau choix.

Une mission narrative doit aussi trouver des questions correspondant à la sélection et à sa matière ; sinon elle explique le conflit au lieu de poser des questions d’une autre matière. Les boss de méthode restent explicitement des exercices de méthode, avec leurs propres questions. Les raids en différé, où seul l’attaquant répond, gardent la sélection de l’attaquant.

## Choix en multijoueur en direct

1. Chaque joueur enregistre **sa matière et son thème** avant de créer ou de rejoindre un salon.
2. Le salon affiche le choix de chacun. Il est possible de le changer dans la salle d’attente.
3. Au lancement, les sélections sont figées pour cette partie.
4. Avec deux sélections distinctes suffisamment fournies : **3 questions de chaque pour 6 manches**, dans un ordre mélangé. Les deux joueurs voient exactement les mêmes questions et choix.
5. Avec une sélection identique : les six questions restent dans ce choix. Aucun doublon de question dans une partie.

Cela s’applique aux salons **party**, **arène** et aux **sièges en direct**. Un rechargement retrouve la sélection de la partie même si le profil a changé pour la prochaine. Une modification reçue pendant le combat ne remplace pas les questions en cours.

Pour plus de deux sélections, l’échantillonnage répartit les tours entre les sélections distinctes, en commençant dans un ordre aléatoire. Avec plus de sélections que de manches, elles ne peuvent pas toutes apparaître dans une seule partie. Si une sous-notion est exceptionnellement très peu fournie, les questions restent uniques et dans les choix disponibles ; la parité exacte 3/3 suppose au moins trois questions disponibles de chaque côté.

## Qualité et références

Les nouvelles rédactions portent le statut **draft / à relire**. Les contrôles automatiques vérifient structure, identifiants, doublons, quantités et règles de sélection ; ils ne remplacent pas une relecture enseignante ni la validation de chaque réponse. Le lexique des langues comporte des activités d’entraînement et ne prétend pas évaluer à lui seul un niveau de bac.

Les titres regroupent les contenus actuellement proposés et ne constituent pas une certification d’exhaustivité de tous les chapitres officiels. L’applicabilité exacte des programmes 2027, notamment les thèmes de l’épreuve écrite HGGSP, reste à vérifier. Les liens Éduscol sont des références de programme ; ils ne signifient pas que chaque QCM a été approuvé par cette institution. Les tentatives de consultation du 30 octobre 2026 ont reçu un HTTP 403 dans cet environnement. Détail dans `data/authoring/SOURCES.md`.

## Maintenance et tests

- `data/authoring/*.tsv` : repère ou entrée, définition, mise en situation ; 25 lignes par chapitre.
- `tools/numerical_questions.py` : familles numériques avec calculs et explications.
- `tools/build_question_bank.py` : compilation explicite en `data/questions/010-chapitres.json`, sans génération lors des parties.
- `study_outline.py` : chemins d’affichage et compatibilité des anciennes sélections.
- `study_selection.py` : mélange équilibré et sans élargissement des thèmes.

```sh
python tools/build_question_bank.py
python -m pytest -q
```

Le compilateur conserve l’ordre des identifiants déjà publiés pour ne pas casser les anciennes parties stockant des indices. Ne pas modifier ou supprimer les fichiers `001-lumeria.json`, les anciennes positions ou les questions publiées sans migration adaptée. Ajouter les prochaines banques après les fichiers existants.

Les tests couvrent les 96 minima, la conservation des 127 positions précédentes, le filtrage solo, le changement de thème, les trois modes multijoueurs, la reconnexion et les questions identiques côté joueurs. `tests/topics-browser.cjs` vérifie également les vrais sélecteurs et un salon ordinateur/mobile dans Chromium.
