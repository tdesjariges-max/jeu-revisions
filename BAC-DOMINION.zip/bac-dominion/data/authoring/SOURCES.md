# Origine et statut pédagogique

Les TSV sont des rédactions originales de Luméria. Ils ne sont pas des extraits copiés de banques d’examens. Les programmes et les repères usuels de cours servent de cadre ; les liens Éduscol indiqués dans les QCM ne sont pas des attestations de validation individuelle.

Le 30 octobre 2026, les huit URL de ressources Éduscol listées dans `tools/build_question_bank.py` ont été essayées depuis cet environnement. Toutes ont renvoyé HTTP 403. Leur contenu et l’applicabilité précise pour 2027 n’ont donc pas pu être vérifiés ici. Aucune nouvelle question n’est marquée `reviewed`.

Les 25 lignes d’un chapitre comportent des objets distincts à travailler, avec une définition et un exemple contextualisé. Deux questions sont construites sur chaque ligne. Les distracteurs sont tirés des autres objets du même chapitre ; leur pertinence et d’éventuelles ambiguïtés sont à contrôler lors de la relecture. Les questions de calcul ont des explications numériques et des hypothèses explicites.

Les axes HGGSP sont distingués par thème, y compris les objets conclusifs ; les chapitres des autres matières regroupent les contenus effectivement proposés. Cette taxonomie d’entraînement ne remplace pas un inventaire exhaustif des programmes officiels.
