> **Banque et multijoueur mis à jour** : 4 927 questions, 96 chapitres/axes à au moins 50 questions chacun. Voir [README-QUESTIONS.md](README-QUESTIONS.md).

# Luméria — BAC DOMINION · refonte cartoon

Le guide actuel, le lancement Windows et la refonte sont décrits dans [README-REFONTE.md](README-REFONTE.md). Les notes du premier socle sont conservées dans [README-v04.md](README-v04.md). L’accueil ouvre Luméria ; `/classic` conserve les modes de la v0.3.1. La v0.4 complète reste en développement.

---

# BAC DOMINION — v0.3.1 · Le Royaume des Savoirs

**Prototype mobile et ordinateur** : stratégie persistante, RPG solo, mini-jeux et arènes multijoueurs de 2 à 60 joueurs (limite de salon non testée à pleine charge), royaumes visitables et guerres PvP. Interface en français et utilisable dans le navigateur. Environnement fantastique original de Luméria, avec Pim le griffon, Maë la cartographe et Nox le dragon.

## Démarrage local

Prérequis : Python 3.10+, Internet pour installer les dépendances.

```bash
cd bac-dominion
python -m venv .venv
# Windows : .venv\Scripts\activate
# macOS/Linux : source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000 --workers 1
```

Ouvre `http://localhost:8000`. Sur un mobile du **même réseau Wi-Fi**, ouvre `http://IP_LOCALE_DU_PC:8000` (pare-feu du PC à autoriser si nécessaire).

## Jouer en ligne avec ses amis sur Internet

**Le projet livré n'est pas encore hébergé** : le ZIP seul ne fournit pas d'adresse publique. Une fois le backend installé sur un VPS avec un nom de domaine et Docker Compose, le jeu peut être accessible en HTTPS/WSS depuis plusieurs foyers.

1. Oriente le DNS `A`/`AAAA` d'un domaine vers l'adresse publique de ton VPS. Ouvre les ports TCP 80, 443 (et si possible UDP 443) sur le pare-feu.
2. Dépose le dossier sur le VPS. Copie `.env.example` en `.env` et définis `BAC_DOMAIN=ton-vrai-domaine.fr`.
3. Lance `docker compose -f compose.production.yaml up -d --build`.
4. Quand DNS et certificats sont opérationnels, ouvre `https://ton-vrai-domaine.fr` sur téléphone ou PC.

La configuration incluse utilise Caddy pour HTTPS, WebSocket via reverse proxy, un volume persistant SQLite et les cookies de session sécurisés côté navigateur. **Conserve un seul worker Uvicorn**, car les salons et invitations restent en mémoire. Avant d'ouvrir à un grand public, ajouter une protection anti-spam et anti-triche renforcée, une récupération de compte, surveillance, sauvegardes hors machine, modération et politique RGPD pour les élèves mineurs. Ceci reste une bêta, pas un service de production certifié.

## Nouveautés v0.3.1 — Royaumes et PvP

- **Royaumes à visiter** depuis l'onglet 🌍 Royaumes. La cité reçoit des paliers visuels (hameau, village, forteresse, cité et royaume céleste) d'après le **nombre de notions différentes maîtrisées** et les bâtiments développés. Un visuel 2D/emoji illustratif remplace pour l'instant les modèles 3D finaux.
- **Deux modes d'attaque** du château d'un ami :
  - **Duel en direct**, proposé quand le joueur est connecté. Il reçoit une invitation à accepter/refuser. Les deux joueurs répondent à des questions dans une arène synchronisée (WebSocket), en choisissant attaque ou bouclier. Les réponses correctes donnent des dégâts influencés par les spécialités et l'armée.
  - **Raid en différé**, même si le défenseur est absent. Ses fortifications et troupes génèrent une défense automatique ; l'attaquant mobilise son armée pour 5 QCM et attaque avec chaque bonne réponse.
- **Zéro perte permanente de troupes, bâtiments, points scolaires, ressources ou XP** pour le défenseur. Les troupes engagées dans un raid reviennent à l'attaquant, y compris si l'attaque échoue. Seul le **prestige PvP** change en fonction de l'issue.
- Résultat en prestige : victoire de l'attaquant **+18**, défenseur **−12** (plancher zéro) ; échec/abandon **−6** pour l'attaquant, **+6** pour le défenseur. Les bonus de ressources des attaquants ne sont **pas prélevés** sur le défenseur.
- Après une attaque, une **marque visuelle** d'impact régénère en **10 minutes** ; son intensité est calculée à partir de l'horodatage, même hors ligne. Le défenseur reçoit un **bouclier de 30 minutes** contre les nouveaux défis. Les données du royaume restent inchangées.
- **Historique** des combats en direct et différé, protections contre plusieurs attaques quotidiennes identiques, limitation des raids différés (5/jour UTC, pause entre attaques) et limitation des duels en direct (5 batailles terminées/24h).
- **Changement de programme** accessible depuis la barre du haut, sans sortir du jeu. Choisis matière → thème → axe → sous-axe et enregistre. Le thème choisi sert aux prochaines sessions ; une partie déjà lancée conserve ses questions pour éviter de perturber les autres.
- **Coffre gratuit du jour** avec une seule participation côté serveur. C'est un bonus aléatoire sans mise ni achat, avec probabilités affichées : 60% (+15), 30% (+30), 9% (+70), 1% (+140 points). Aucune dépense ni seconde chance payante.
- **Histoire de Luméria** : cinq chapitres scénarisés, personnages originaux et récompenses à débloquer par des réalisations pédagogiques (pas par un nombre d'heures de connexion).

## Fonctionnalités précédentes préservées

- Authentification avec pseudonyme, mot de passe haché (PBKDF2+sel), cookie HttpOnly ; stockage SQLite des ressources, armées, scores, progression, spécialités et thème choisi.
- Six bâtiments à améliorer, trois types de troupes, production passive d'or/bois/pierre ; conquête de trois territoires PvE.
- Deux modes multijoueurs par code de salon (2–60) : Party Game pour ressources et arène de QCM. Chaque partie comporte 1–6 manches selon le filtre.
- **Bonus des spécialités ×2** en points de base et XP ; bonnes réponses consécutives selon `min(6, 1.35 ** (n-1))` ; erreur remet la série à zéro.
- Entraînements et missions solo, trois boss de méthodologie avec PV et correction des réponses, classement scolaire cumulé distinct du prestige PvP.
- **61 QCM de cours** et **18 de méthodologie**, créés pour illustrer le gameplay. Banque encore trop limitée pour garantir une préparation exhaustive au bac. Les réponses rédigées ne sont pas encore corrigées automatiquement.

## Tests

```bash
pip install pytest httpx websockets
pytest -q
```

Neuf tests automatisés couvrent notamment filtrage de thèmes, séries de réponses, boss, salon QCM et la nouvelle attaque PvP (résultat, retour des troupes, perte exclusive de prestige, régénération et invitation WebSocket à deux joueurs). Aucun test de charge réel à 60 joueurs n'a encore été réalisé.

## Architecture

- Backend Python / FastAPI / WebSockets, scores et vérification des QCM **calculés côté serveur**.
- Frontend HTML/CSS/JS sans framework, responsive mobile, PWA avec manifeste.
- SQLite (par défaut `bac_dominion.db`) pour les états persistants. Les salons en direct vivent en mémoire et peuvent être interrompus par un redémarrage.
- Fichiers-clés : `app.py` backend, `questions.py` questions de cours, `curriculum.py` hiérarchie et boss, `story.py` scénario, `static/` interface.

**Limites visuelles :** le royaume est pour le moment une maquette 2D illustrée en CSS/emoji, non pas une représentation complète et animée en 3D semblable au rendu de Clash of Clans. L'objectif artistique est un univers cartoon fantastique original et familial, sans recopier les éléments protégés d'un autre jeu.
