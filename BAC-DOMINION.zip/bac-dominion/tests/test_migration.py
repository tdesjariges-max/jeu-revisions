"""Migrate an actual account produced by the archived v0.3.1 app."""
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

from fastapi.testclient import TestClient
import app


def test_real_v031_account_and_progression_survive(tmp_path,monkeypatch):
    archive=Path(__file__).resolve().parents[2]/'BAC_DOMINION_v0.3.1.zip'
    if not archive.exists():
        # A distributed source ZIP omits the original archive; fixture is optional there.
        import pytest
        pytest.skip('Original v0.3.1 archive not shipped with this source distribution')
    with zipfile.ZipFile(archive) as z:
        z.extractall(tmp_path/'original')
    database=tmp_path/'old-save.db'
    source="""
import json
from fastapi.testclient import TestClient
import app
with TestClient(app.app) as c:
    assert c.post('/api/register',json={'username':'LegacySave','password':'migration-test-password','specialties':['SVT','HGGSP']}).status_code==200
    assert c.post('/api/upgrade',json={'building':'mine'}).status_code==200
    assert c.post('/api/recruit',json={'unit':'soldiers','amount':1}).status_code==200
    print(json.dumps(c.get('/api/me').json()))
"""
    old=json.loads(subprocess.check_output([sys.executable,'-c',source],cwd=tmp_path/'original/bac-dominion',env={**os.environ,'BAC_DB_PATH':str(database)},text=True))
    monkeypatch.setattr(app,'DB_PATH',database)
    app.init_db()
    app.init_db()
    app.auth_attempts.clear()
    with TestClient(app.app) as c:
        assert c.post('/api/login',json={'username':'LegacySave','password':'migration-test-password'}).status_code==200
        new=c.get('/api/me').json()
        for key in ('id','username','score','xp','gold','wood','stone','buildings','army','prestige','focus','specialties','territories'):
            assert new[key]==old[key],key
        assert len(c.get('/api/play').json()['layout'])==6
        assert c.get('/api/me').json()['buildings']==old['buildings']
