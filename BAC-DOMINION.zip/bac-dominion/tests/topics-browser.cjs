/* Two real browsers, desktop + touch mobile: choose different topics, join, play. */
'use strict';
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const base=process.env.BAC_BASE_URL||'http://127.0.0.1:8001';
const plant='De la plante sauvage à la plante domestiquée';
const war='Faire la guerre, faire la paix';
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
 const a=await browser.newContext({viewport:{width:1280,height:900}});
 const b=await browser.newContext({viewport:{width:390,height:844},hasTouch:true,isMobile:true});
 const pages=[await a.newPage(),await b.newPage()];
 const records=[[],[]],errors=[];
 for(let i=0;i<2;i++){
   const page=pages[i];page.on('pageerror',e=>errors.push(e.message));
   page.on('websocket',socket=>socket.on('framereceived',frame=>{
     const m=JSON.parse(String(frame.payload));
     if(m.type==='room'&&m.status==='playing'&&m.question&&!m.reveal&&!records[i].some(r=>r.round===m.round))records[i].push(m);
   }));
   const res=await page.request.post(base+'/api/register',{data:{username:'TopicUI'+Date.now().toString(36)+i,password:'topic-browser-password',specialties:['SVT','HGGSP']}});
   assert(res.ok(),await res.text());
 }
 const [pa,pb]=pages;
 await pa.goto(base+'/play');
 await pa.getByRole('button',{name:'Changer de révision',exact:true}).click();
 await pa.locator('#focus-form [name=subject]').selectOption('SVT');
 await pa.locator('#focus-form [name=theme]').selectOption(plant);
 await pa.locator('#focus-form [name=axis]').selectOption('Échanges et nutrition');
 assert((await pa.locator('#focus-form').innerText()).includes('50'));
 await pa.locator('#focus-form button[type=submit],#focus-form .dialog-actions button').last().click();
 await pa.waitForFunction(()=>!document.querySelector('#modal-dialog').open);
 assert.equal(await pa.locator('.study-button strong').innerText(),plant);
 await pa.goto(base+'/classic?tab=party');
 await pa.waitForFunction(()=>state.wsReady&&state.curriculum);
 await pb.goto(base+'/classic?tab=party');
 await pb.waitForFunction(()=>state.wsReady&&state.curriculum);
 assert(await pb.locator('[data-action=create-room]').isDisabled(),'A topic is required before creating');
 await pb.locator('#focus-subject').selectOption('HGGSP');
 await pb.locator('#focus-theme').selectOption(war);
 await pb.locator('#focus-axis').selectOption('Axe 1 · Dimension politique de la guerre');
 await pb.locator('[data-action=focus-save]').click();
 await pb.waitForFunction(w=>state.profile.focus.theme===w,war);
 await pa.locator('[data-action=create-room]').click();
 await pa.waitForFunction(()=>state.room?.status==='waiting');
 const code=await pa.evaluate(()=>state.room.code);
 await pb.locator('input[name=code]').fill(code);
 await pb.locator('[data-form=join-room] button').click();
 await pb.waitForFunction(()=>state.room?.players.length===2);
 await pa.waitForFunction(()=>state.room?.players.length===2);
 for(const p of pages){
   await p.waitForFunction(([plant,war])=>{const text=document.querySelector('.room-topics')?.innerText||'';return text.includes(plant)&&text.includes(war);},[plant,war]);
   const texts=await p.locator('.room-topics').innerText();assert(texts.includes(plant)&&texts.includes(war));
   assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Lobby has no horizontal overflow');
 }
 fs.mkdirSync('/tmp/lumeria-topics-ui',{recursive:true});
 await pa.screenshot({path:'/tmp/lumeria-topics-ui/lobby-desktop.png',fullPage:true});
 await pb.screenshot({path:'/tmp/lumeria-topics-ui/lobby-mobile.png',fullPage:true});
 await pa.locator('[data-action=start-room]').click();
 await Promise.all(pages.map(p=>p.waitForFunction(()=>state.room?.status==='finished',{},{timeout:25000})));
 assert.equal(records[0].length,6);assert.equal(records[1].length,6);
 assert.deepEqual(records[0].map(x=>x.question),records[1].map(x=>x.question));
 assert.equal(records[0].filter(x=>x.question.theme===plant).length,3);
 assert.equal(records[0].filter(x=>x.question.theme===war).length,3);
 assert.deepEqual(errors,[]);
 for(const p of pages)assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Game has no horizontal overflow');
 console.log('Desktop + touch mobile: topic selectors, mandatory selection, lobby topics, six identical questions, exact 3+3 mix, no JS errors or overflow passed.');
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exit(1);});
