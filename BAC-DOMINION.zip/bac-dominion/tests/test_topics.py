"""Minimum coverage, strict solo topics and fair, identical multiplayer questions."""
from collections import Counter
import random

import pytest
from fastapi.testclient import TestClient
import app
from study_catalog import catalog
from study_outline import CHAPTERS
from study_selection import matches, mixed_indices

PLANTS={'subject':'SVT','theme':'De la plante sauvage à la plante domestiquée','axis':'Échanges et nutrition','subaxis':''}
WAR={'subject':'HGGSP','theme':'Faire la guerre, faire la paix','axis':'Axe 1 · Dimension politique de la guerre','subaxis':''}


def correct(q):
    src=next(x for x in app.QUESTIONS if x['id']==q['id'])
    return q['options'].index(src['options'][src['correct']])


@pytest.fixture
def players(tmp_path,monkeypatch):
    monkeypatch.setattr(app,'DB_PATH',tmp_path/'topics.db')
    monkeypatch.setattr(app,'ROUND_SECONDS',.07)
    monkeypatch.setattr(app,'REVEAL_SECONDS',.002)
    monkeypatch.setattr(app,'ROOM_ROUNDS',6)
    app.init_db()
    app.auth_attempts.clear()
    app.rooms.clear()
    app.online_users.clear()
    with TestClient(app.app) as a, TestClient(app.app) as b:
        for c,name in ((a,'TopicAlpha'),(b,'TopicBeta')):
            r=c.post('/api/register',json={'username':name,'password':'topic-password-123','specialties':['HGGSP','SVT']})
            assert r.status_code==200,r.text
        yield a,b


def choose(c,focus):
    r=c.post('/api/focus',json=focus)
    assert r.status_code==200,r.text
    return r.json()


def test_every_announced_chapter_has_fifty_and_valid_unique_questions():
    counts=Counter((q['category'],q['theme'],q['axis']) for q in app.QUESTIONS)
    assert set(counts)==set(CHAPTERS)
    assert min(counts.values())>=50
    assert len({q['id'] for q in app.QUESTIONS})==len(app.QUESTIONS)
    assert len({q['q'].strip().casefold() for q in app.QUESTIONS})==len(app.QUESTIONS)
    assert sum(counts.values())==4927
    for q in app.QUESTIONS[127:]:
        assert app.question_public(q)['subaxis'] != q['options'][q['correct']]
        assert 'concept' not in app.question_public(q)
    result=catalog(app.QUESTIONS)
    assert len(result['chapters'])==96
    assert all(c['count']>=50 for c in result['chapters'])


def test_old_127_questions_keep_their_indices_and_answers():
    import questions
    from study_bank import load_file,ROOT
    old=questions.QUESTIONS
    draft=load_file(ROOT/'data/questions/001-lumeria.json')
    assert [q['q'] for q in app.QUESTIONS[:61]]==[q['q'] for q in old]
    assert [q['id'] for q in app.QUESTIONS[61:127]]==[q.id for q in draft]
    assert [q['correct'] for q in app.QUESTIONS[:61]]==[q['correct'] for q in old]


def test_practice_change_drops_old_training_but_preserves_progress(players):
    a,_=players
    choose(a,PLANTS)
    run=a.post('/api/practice/start',json={}).json()
    assert matches(run['question'],PLANTS)
    result=a.post('/api/quest/answer',json={'choice':correct(run['question'])}).json()
    score=result['profile']['score']
    choose(a,WAR)
    assert a.get('/api/quest/current').json()=={'active':False}
    assert a.get('/api/me').json()['score']==score
    run=a.post('/api/practice/start',json={}).json()
    for _ in range(run['total']):
        assert matches(run['question'],WAR)
        assert 'correct' not in run['question']
        result=a.post('/api/quest/answer',json={'choice':correct(run['question'])}).json()
        if result['finished']: break
        run['question']=result['next_question']
    assert result['finished']


@pytest.mark.parametrize('mode',['arena','race'])
def test_gameplay_keeps_topic_until_end_even_if_next_topic_changes(players,mode):
    a,_=players
    choose(a,PLANTS)
    r=a.post('/api/play/start',json={'mode':mode}).json()
    assert r['focus']==PLANTS
    choose(a,WAR)
    seen=[]
    while not r['finished']:
        r=a.post('/api/play/action',json={'run_id':r['run_id'],'step':r['step'],'card':'focus'}).json()
        q=r['question']
        assert matches(q,PLANTS)
        assert 'correct' not in q
        seen.append(q['id'])
        r=a.post('/api/play/answer',json={'run_id':r['run_id'],'step':r['step'],'choice':correct(q)}).json()['run']
    assert len(set(seen))==len(seen)
    r=a.post('/api/play/start',json={'mode':mode}).json()
    r=a.post('/api/play/action',json={'run_id':r['run_id'],'step':r['step'],'card':'focus'}).json()
    assert matches(r['question'],WAR)


def drain_game(ws):
    seen=[]
    for _ in range(100):
        msg=ws.receive_json()
        if msg.get('status')=='finished': return seen,msg
        if msg.get('question') and not msg.get('reveal'):
            if not seen or seen[-1]['round']!=msg['round']: seen.append(msg)
    raise AssertionError('No finished snapshot')


@pytest.mark.parametrize('mode',['party','arena','siege'])
def test_two_players_receive_three_questions_per_topic_same_order_and_no_answer_leak(players,mode):
    a,b=players
    choose(a,PLANTS);choose(b,WAR)
    with a.websocket_connect('/ws') as wa, a.websocket_connect('/ws',headers={'cookie':'bac_session='+b.cookies['bac_session']}) as wb:
        wa.receive_json();wb.receive_json()
        if mode=='siege':
            wa.send_json({'type':'siege_challenge','username':'TopicBeta'})
            waiting=wa.receive_json();invite=wb.receive_json()
            assert waiting['type']=='siege_waiting'
            wb.send_json({'type':'siege_accept','code':invite['code']})
        else:
            wa.send_json({'type':'create','mode':mode})
            room=wa.receive_json()
            wb.send_json({'type':'join','code':room['code']})
            lobby_b=wb.receive_json();lobby_a=wa.receive_json()
            assert lobby_a['selections']==lobby_b['selections']==[PLANTS,WAR]
            assert [p['focus'] for p in lobby_a['players']]==[PLANTS,WAR]
            wa.send_json({'type':'start'})
        seen_a,done_a=drain_game(wa)
        seen_b,done_b=drain_game(wb)
        assert len(seen_a)==len(seen_b)==6
        assert len({m['question']['id'] for m in seen_a})==6
        assert [m['question'] for m in seen_a]==[m['question'] for m in seen_b]
        categories=Counter(m['question']['category'] for m in seen_a)
        assert categories=={'SVT':3,'HGGSP':3}
        assert all(matches(m['question'],PLANTS) or matches(m['question'],WAR) for m in seen_a)
        assert all('correct' not in m['question'] for m in seen_a)
        assert [x['count'] for x in done_a['topic_counts']]==[3,3]
        assert done_a['selections']==done_b['selections']==[PLANTS,WAR]


def test_choice_required_and_http_updates_after_socket_connection_are_used(players):
    a,b=players
    with a.websocket_connect('/ws') as wa, a.websocket_connect('/ws',headers={'cookie':'bac_session='+b.cookies['bac_session']}) as wb:
        wa.receive_json();wb.receive_json()
        wa.send_json({'type':'create','mode':'party'})
        assert wa.receive_json()['type']=='error'
        choose(a,PLANTS)  # The original authenticated socket user still had an empty focus.
        wa.send_json({'type':'create','mode':'party'})
        lobby=wa.receive_json()
        assert lobby['selections']==[PLANTS]
        wb.send_json({'type':'join','code':lobby['code']})
        assert wb.receive_json()['type']=='error'
        choose(b,WAR)
        wb.send_json({'type':'join','code':lobby['code']})
        wb.receive_json();wa.receive_json()
        choose(b,PLANTS)
        wb.send_json({'type':'refresh_focus'})
        assert wb.receive_json()['selections']==[PLANTS]
        assert wa.receive_json()['selections']==[PLANTS]
        wa.send_json({'type':'start'})
        messages,done=drain_game(wa)
        assert len(messages)==6
        assert all(matches(m['question'],PLANTS) for m in messages)
        assert done['topic_counts']==[{'focus':PLANTS,'count':6}]


def test_overlap_shared_topic_small_pool_and_many_players_never_broaden_or_repeat():
    source=app.QUESTIONS
    broad={'subject':'SVT','theme':PLANTS['theme']}
    for selections in ([PLANTS,PLANTS],[broad,PLANTS],[WAR,PLANTS], [PLANTS]*60):
        plan=mixed_indices(source,selections,6,random.Random(42))
        assert len(plan)==len({i for i,_ in plan})==6
        assert all(any(matches(source[i],f) for f in selections) for i,_ in plan)
    single={**WAR,'subaxis':'Clausewitz : guerre absolue'}
    plan=mixed_indices(source,[single,single],6,random.Random(42))
    assert len(plan)==1  # Do not silently fetch other subjects if a notion has one question.
    assert matches(source[plan[0][0]],single)
    with pytest.raises(ValueError): mixed_indices(source,[{'subject':'NoSuchSubject'}],6)


def test_old_language_focus_alias_is_migrated_without_deleting_account(players):
    a,_=players
    uid=a.get('/api/me').json()['id']
    with app.connect() as db:
        db.execute("UPDATE users SET focus_subject='Anglais',focus_theme='Territory and Memory',focus_axis='Grammar',focus_subaxis='Present perfect' WHERE id=?",(uid,))
    focus=a.get('/api/me').json()['focus']
    assert focus=={'subject':'Anglais','theme':'Territoire et mémoire','axis':'Langue et culture','subaxis':'Present perfect'}
    q=a.post('/api/practice/start',json={}).json()['question']
    assert matches(q,focus)
    assert a.get('/api/me').json()['id']==uid


def test_reconnect_uses_frozen_topic_even_after_profile_changed(players):
    a,b=players
    choose(a,PLANTS);choose(b,WAR)
    with a.websocket_connect('/ws') as wa, a.websocket_connect('/ws',headers={'cookie':'bac_session='+b.cookies['bac_session']}) as wb:
        wa.receive_json();wb.receive_json()
        wa.send_json({'type':'create','mode':'party'})
        lobby=wa.receive_json()
        wb.send_json({'type':'join','code':lobby['code']})
        wb.receive_json();wa.receive_json()
        wa.send_json({'type':'start'})
        first=wa.receive_json()
        assert first['selections']==[PLANTS,WAR]
        choose(b,{'subject':'','theme':'','axis':'','subaxis':''})
        with a.websocket_connect('/ws',headers={'cookie':'bac_session='+b.cookies['bac_session']}) as fresh:
            assert fresh.receive_json()['type']=='hello'
            fresh.send_json({'type':'join','code':lobby['code']})
            resumed=fresh.receive_json()
            assert resumed['type']=='room'
            assert resumed['selections']==[PLANTS,WAR]
            assert resumed['players'][1]['focus']==WAR
            assert matches(resumed['question'],PLANTS) or matches(resumed['question'],WAR)


def test_mission_and_async_raid_never_fall_back_to_other_topics(players):
    a,b=players
    choose(a,PLANTS)
    assert a.post('/api/quest/start',json={'mission':'valmy'}).status_code==400
    leaf={**WAR,'subaxis':'Clausewitz : guerre absolue'}
    choose(a,leaf)
    mission=a.post('/api/quest/start',json={'mission':'valmy'}).json()
    assert mission['total']==1
    assert matches(mission['question'],leaf)
    assert a.post('/api/recruit',json={'unit':'soldiers','amount':1}).status_code==200
    raid=a.post('/api/raid/start',json={'defender':'TopicBeta','soldiers':1,'archers':0,'mages':0})
    assert raid.status_code==200,raid.text
    assert raid.json()['raid']['total']==1
    assert matches(raid.json()['raid']['question'],leaf)


def test_invalid_focus_keeps_active_revision(players):
    a,_=players
    choose(a,PLANTS)
    before=a.post('/api/practice/start',json={}).json()
    assert a.post('/api/focus',json={'subject':'SVT','theme':WAR['theme']}).status_code==400
    assert a.get('/api/quest/current').json()==before
