"""v0.2 smoke/integration tests. Run: pytest -q"""
import sys
from pathlib import Path
import time
import pytest
from fastapi.testclient import TestClient

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app

def correct_choice(public,bank):
    original=next(q for q in bank if q['q']==public['q'])
    return public['options'].index(original['options'][original['correct']])


@pytest.fixture
def game(tmp_path, monkeypatch):
    monkeypatch.setattr(app,'DB_PATH',tmp_path/'test.db')
    app.init_db()
    with TestClient(app.app) as client:
        res=client.post('/api/register',json={'username':'EleveT','password':'correct-password-123','specialties':['SVT','HGGSP']})
        assert res.status_code==200,res.text
        yield client

def test_focus_persists_and_targets_only_selected_question(game):
    response=game.get('/api/curriculum')
    assert response.status_code==200 and len(response.json())>=50
    f={'subject':'HGGSP','theme':'Faire la guerre, faire la paix',
       'axis':'Axe 1 · Dimension politique de la guerre','subaxis':'Clausewitz : guerre absolue'}
    result=game.post('/api/focus',json=f)
    assert result.status_code==200 and result.json()['question_count']==1
    assert game.get('/api/me').json()['focus']==f
    q=game.post('/api/practice/start',json={}).json()
    assert q['total']==1
    assert q['question']['subaxis']==f['subaxis']
    result=game.post('/api/quest/answer',json={'choice':correct_choice(q['question'],app.QUESTIONS)}).json()
    assert result['correct'] and result['finished']
    assert result['earned']['specialty_bonus']


def test_invalid_focus_rejected(game):
    response=game.post('/api/focus',json={'subject':'SVT','theme':'Faire la guerre, faire la paix',
            'axis':'','subaxis':''})
    assert response.status_code==400
    response=game.post('/api/focus',json={'subject':'','theme':'Not valid','axis':'','subaxis':''})
    assert response.status_code==400


def test_streak_exponential_then_reset(game):
    assert game.post('/api/focus',json={'subject':'HGGSP','theme':'Faire la guerre, faire la paix',
        'axis':'Axe 1 · Dimension politique de la guerre','subaxis':'Clausewitz : guerre absolue'}).status_code == 200
    earned=[]
    for _ in range(4):
        q=game.post('/api/practice/start',json={}).json()
        result=game.post('/api/quest/answer',json={'choice':correct_choice(q['question'],app.QUESTIONS)}).json()
        earned.append(result['earned']['score'])
    assert earned==[20,27,36,49]
    q=game.post('/api/practice/start',json={}).json()
    wrong=game.post('/api/quest/answer',json={'choice':(correct_choice(q['question'],app.QUESTIONS)+1)%4}).json()
    assert wrong['earned']['streak']==0
    assert game.get('/api/me').json()['best_streak']==4
    assert game.get('/api/me').json()['streak']==0
    assert app.streak_multiplier(100)==6


def test_boss_win_persistence_and_repeat_rewards(game):
    outcome=game.post('/api/boss/start',json={'boss':'archiviste'})
    assert outcome.status_code==200
    run=outcome.json()
    for i in range(6):
        current=run['question']
        correct=correct_choice(current,app.METHOD_QUESTIONS)
        reply=game.post('/api/boss/answer',json={'choice':correct})
        assert reply.status_code==200,reply.text
        result=reply.json()
        if result['finished']:break
        run={'question':result['next_question']}
    assert result['won'] is True
    assert result['reward']['gold']==160
    assert game.get('/api/boss/current').json()['active'] is False
    assert 'archiviste' in game.get('/api/bosses').json()['defeated_today']
    # Subsequent successes on the same UTC day have sharply reduced rewards.
    run=game.post('/api/boss/start',json={'boss':'archiviste'}).json()
    for i in range(6):
        correct=correct_choice(run['question'],app.METHOD_QUESTIONS)
        result=game.post('/api/boss/answer',json={'choice':correct}).json()
        if result['finished']:break
        run={'question':result['next_question']}
    assert result['won'] and result['reward']['gold']==int(160*.15)


def test_wrong_boss_answer_loses_hp_and_resets_streak(game):
    run=game.post('/api/boss/start',json={'boss':'sphinx'}).json()
    correct=correct_choice(run['question'],app.METHOD_QUESTIONS)
    response=game.post('/api/boss/answer',json={'choice':(correct+1)%4}).json()
    assert response['player_hp']==72
    assert response['boss_hp']==145
    assert response['streak']==0


def test_websocket_host_topic_and_two_players(game,monkeypatch):
    c1=game
    f={'subject':'SVT','theme':'De la plante sauvage à la plante domestiquée',
       'axis':'Échanges et nutrition','subaxis':''}
    assert c1.post('/api/focus',json=f).status_code == 200
    monkeypatch.setattr(app,'ROUND_SECONDS',1)
    monkeypatch.setattr(app,'REVEAL_SECONDS',0.01)
    c2=TestClient(app.app)
    assert c2.post('/api/register',json={'username':'EleveU','password':'correct-password-123',
        'specialties':['SVT','HGGSP']}).status_code == 200
    with c1.websocket_connect('/ws') as w1, c2.websocket_connect('/ws') as w2:
        assert w1.receive_json()['type']=='hello'
        assert w2.receive_json()['type']=='hello'
        w1.send_json({'type':'create','mode':'party'})
        lobby=w1.receive_json()
        assert lobby['focus']==f
        code=lobby['code']
        w2.send_json({'type':'join','code':code})
        assert w2.receive_json()['status']=='waiting'
        assert len(w1.receive_json()['players'])==2
        w1.send_json({'type':'start'})
        first=w1.receive_json()
        assert first['status']=='playing' and first['question']['category']=='SVT'
        assert first['question']['axis']==f['axis']
        # The user sees the very same question in their browser.
        q=first['question']
        correct=correct_choice(q,app.QUESTIONS)
        w1.send_json({'type':'answer','choice':correct,'round':first['round']})
        w2msg=w2.receive_json()
        assert w2msg['question']['q']==q['q']
    c2.close()
