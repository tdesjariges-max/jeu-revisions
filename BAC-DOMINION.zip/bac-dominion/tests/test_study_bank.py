import copy
import json
import pytest
from pydantic import ValidationError
import app
from study_bank import StudyQuestion, append_banks, load_file, ROOT
from study_catalog import catalog, THEMES


def test_bank_is_structured_unique_and_legacy_order_is_retained():
    questions = app.QUESTIONS
    assert len(questions) == 4927
    from questions import QUESTIONS as legacy
    assert [q['q'] for q in questions[:len(legacy)]] == [q['q'] for q in legacy]
    assert len({q['id'] for q in questions}) == len(questions)
    assert len({q['q'] for q in questions}) == len(questions)
    assert all(q['validation'] != 'reviewed' for q in questions)
    for q in questions:
        assert q['options'][q['correct']]
        assert q['reference'] and q['explanation']
        assert 1 <= q['difficulty'] <= 5


def test_import_rejects_missing_metadata_bad_answer_duplicates_and_unknown_fields(tmp_path):
    question = load_file(ROOT/'data/questions/001-lumeria.json')[0].model_dump()
    for change in ({'correct':4},{'difficulty':0},{'id':'bad id'},{'extra':'no'},{'options':['same']*4}):
        with pytest.raises(ValidationError):
            StudyQuestion.model_validate({**question,**change})
    missing = copy.deepcopy(question)
    del missing['reference']
    with pytest.raises(ValidationError):
        StudyQuestion.model_validate(missing)
    path=tmp_path/'duplicate.json'
    path.write_text(json.dumps([question,question]))
    with pytest.raises(ValueError,match='Duplicate'):
        append_banks([],tmp_path)


def test_catalog_includes_six_hggsp_and_seventeen_philosophy_notions_without_claiming_verification():
    result = catalog(app.QUESTIONS)
    available={(r['subject'],r['theme']) for r in result['rows']}
    assert all(('HGGSP',t) in available for t in THEMES['HGGSP'])
    assert len(THEMES['Philosophie']) == 17
    assert all(('Philosophie',t) in available for t in THEMES['Philosophie'])
    assert all(('EMC',t) in available for t in THEMES['EMC'])
    assert all(r['count']>0 for r in result['rows'])
    assert len(result['chapters']) == 96
    assert result['minimum_per_chapter'] >= 50
    assert all(r['count']>=50 for r in result['chapters'])
    assert not result['sources']['hggsp_written_2027_verified']
