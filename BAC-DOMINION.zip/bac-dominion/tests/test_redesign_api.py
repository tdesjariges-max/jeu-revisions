"""Coherent, lightweight initial game state for the redesigned interface."""
import json
import sqlite3
import time

import pytest
from fastapi.testclient import TestClient

import app


@pytest.fixture
def player(tmp_path, monkeypatch):
    monkeypatch.setattr(app, 'DB_PATH', tmp_path / 'redesign.db')
    app.init_db()
    app.auth_attempts.clear()
    with TestClient(app.app) as client:
        response = client.post('/api/register', json={
            'username': 'CartoonPlayer', 'password': 'cartoon-test-password',
            'specialties': ['SVT', 'HGGSP'],
        })
        assert response.status_code == 200
        yield client


def test_bootstrap_requires_login_and_returns_coherent_collected_state(player):
    with TestClient(app.app) as anonymous:
        assert anonymous.get('/api/play/bootstrap').status_code == 401
    before = player.get('/api/me').json()
    with app.connect() as db:
        db.execute('''UPDATE users SET last_collect=?, carry_gold=0,
                   carry_wood=0, carry_stone=0 WHERE id=?''',
                   (time.time() - 3600, before['id']))
    response = player.get('/api/play/bootstrap')
    assert response.status_code == 200, response.text
    snapshot = response.json()
    assert set(snapshot) == {'profile', 'play', 'strategy'}
    profile = snapshot['profile']
    for resource in ('gold', 'wood', 'stone'):
        assert profile[resource] == before[resource] + profile['rates'][resource]
        assert profile['rates'][resource] == snapshot['strategy']['rates'][resource]
    assert len(snapshot['play']['layout']) == 6
    assert snapshot['play']['run'] is None
    assert 'nova' in snapshot['play']['cards']
    for building in snapshot['strategy']['buildings']:
        assert building['level'] == profile['buildings'][building['id']]
        assert building['next_cost'] == app.upgrade_cost(building['id'], building['level'])
    assert snapshot['strategy']['capacity'] == 40 + profile['buildings']['barracks'] * 20
    for key in ('salt', 'password_hash', 'token_hash'):
        assert key not in profile


def test_bootstrap_keeps_saved_customization_and_pending_question_secret(player):
    avatar = {'color': 'gold', 'hair': 'crest', 'cape': False}
    assert player.post('/api/play/avatar', json=avatar).status_code == 200
    assert player.post('/api/play/place', json={'building': 'academy', 'x': 0, 'y': 0}).status_code == 200
    run = player.post('/api/play/start', json={'mode': 'arena'}).json()
    chosen = player.post('/api/play/action', json={
        'run_id': run['run_id'], 'step': run['step'], 'card': 'griffin',
    }).json()
    snapshot = player.get('/api/play/bootstrap').json()
    assert snapshot['play']['avatar'] == avatar
    assert snapshot['play']['layout']['academy'] == {'x': 0, 'y': 0}
    assert snapshot['play']['run'] == chosen
    assert 'questions' not in snapshot['play']['run']
    assert 'correct' not in snapshot['play']['run']['question']
    assert 'explanation' not in snapshot['play']['run']['question']
    assert player.get('/api/play').json() == snapshot['play']


def test_normal_bootstrap_does_not_migrate_schema_or_open_extra_connections(player, monkeypatch):
    assert player.get('/api/play/bootstrap').status_code == 200
    original_connect = sqlite3.connect
    operations = []
    connection_count = 0

    def traced_connect(*args, **kwargs):
        nonlocal connection_count
        connection_count += 1
        connection = original_connect(*args, **kwargs)
        # Record SQL operation names only, never authentication/session values.
        connection.set_trace_callback(lambda statement: operations.append(statement.split(None, 1)[0].upper()))
        return connection

    monkeypatch.setattr(sqlite3, 'connect', traced_connect)
    assert player.get('/api/play/bootstrap').status_code == 200
    assert not {'CREATE', 'ALTER', 'PRAGMA'}.intersection(operations)
    assert connection_count <= 2


def test_bootstrap_migrates_old_profile_snapshot_without_losing_state(player):
    uid = player.get('/api/me').json()['id']
    old_avatar = {'color': 'violet', 'hair': 'long', 'cape': False}
    old_layout = {'academy': {'x': 0, 'y': 9}}
    with app.connect() as db:
        db.execute('DROP TABLE IF EXISTS play_profiles')
        db.execute('''CREATE TABLE play_profiles (
            user_id INTEGER PRIMARY KEY, avatar TEXT NOT NULL, layout TEXT NOT NULL)''')
        db.execute('INSERT INTO play_profiles VALUES(?,?,?)',
                   (uid, json.dumps(old_avatar), json.dumps(old_layout)))
    snapshot = player.get('/api/play/bootstrap').json()
    assert snapshot['play']['avatar'] == old_avatar
    assert snapshot['play']['layout']['academy'] == old_layout['academy']
    assert snapshot['play']['study'] == {'difficulty': 0, 'weak_only': False}
    assert player.get('/api/play/bootstrap').json()['play'] == snapshot['play']
