"""Persistent and live PvP guarantees for v0.3.1."""
import sys
from pathlib import Path
import time
from fastapi.testclient import TestClient
import pytest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import app


def new_user(client,name):
    x=client.post('/api/register',json={'username':name,'password':'strong-password-123','specialties':['SVT','HGGSP']})
    assert x.status_code==200,x.text
    return x.json()


def correct(public):
    src=next(q for q in app.QUESTIONS if q['q']==public['q'])
    return public['options'].index(src['options'][src['correct']])


@pytest.fixture
def clients(tmp_path,monkeypatch):
    monkeypatch.setattr(app,'DB_PATH',tmp_path/'pvp.db')
    app.init_db()
    app.auth_attempts.clear()
    app.online_users.clear()
    app.rooms.clear()
    with TestClient(app.app) as a, TestClient(app.app) as b:
        ua=new_user(a,'Attaquant31')
        ub=new_user(b,'Defenseur31')
        yield a,b,ua,ub


def test_async_raid_prestige_only_troops_return_and_regeneration(clients):
    a,b,ua,ub=clients
    before=b.get('/api/me').json()
    assert a.post('/api/recruit',json={'unit':'soldiers','amount':5}).status_code==200
    army_before=a.get('/api/me').json()['army'].copy()
    raid=a.post('/api/raid/start',json={'defender':'Defenseur31','soldiers':5,'archers':0,'mages':0})
    assert raid.status_code==200,raid.text
    r=raid.json()['raid']
    for i in range(r['total']):
        out=a.post('/api/raid/answer',json={'choice':correct(r['question'])})
        assert out.status_code==200,out.text
        z=out.json()
        if z['finished']:break
        r={'question':z['next_question']}
    assert z['won']
    after=b.get('/api/me').json()
    for key in ('score','xp','gold','wood','stone','buildings','army','territories','kingdom'):
        if key!='kingdom':assert after[key]==before[key],key
    assert after['prestige']==before['prestige']-12
    assert a.get('/api/me').json()['army']==army_before
    public=b.get('/api/kingdoms/Defenseur31').json()
    assert public['damage_percent']>0
    assert public['regenerating_seconds']>0
    assert public['shield_seconds']>0
    assert a.post('/api/raid/start',json={'defender':'Defenseur31','soldiers':1,'archers':0,'mages':0}).status_code in (409,429)
    with app.connect() as db:
        db.execute('UPDATE users SET damage_until=?, shield_until=? WHERE id=?', (time.time()-1,0,ub['id']))
    healed=b.get('/api/kingdoms/Defenseur31').json()
    assert healed['damage_percent']==0
    assert healed['regenerating_seconds']==0


def test_abandon_returns_all_units_and_only_prestige_changes(clients):
    a,b,ua,ub=clients
    assert a.post('/api/recruit',json={'unit':'archers','amount':1}).status_code==200
    army=a.get('/api/me').json()['army'].copy()
    out=a.post('/api/raid/start',json={'defender':'Defenseur31','soldiers':0,'archers':1,'mages':0})
    assert out.status_code==200
    done=a.post('/api/raid/abandon',json={})
    assert done.status_code==200
    assert done.json()['losses']=={'soldiers':0,'archers':0,'mages':0}
    assert a.get('/api/me').json()['army']==army
    assert b.get('/api/me').json()['prestige']==1006


def test_live_siege_invitation_and_outcome(clients,monkeypatch):
    a,b,ua,ub=clients
    for client in (a,b):
        assert client.post('/api/focus',json={'subject':'HGGSP','theme':'Faire la guerre, faire la paix'}).status_code == 200
    monkeypatch.setattr(app,'ROUND_SECONDS',1)
    monkeypatch.setattr(app,'REVEAL_SECONDS',0.001)
    monkeypatch.setattr(app,'ROOM_ROUNDS',1)
    with a.websocket_connect('/ws') as wa, a.websocket_connect('/ws',headers={'cookie':'bac_session='+b.cookies['bac_session']}) as wb:
        assert wa.receive_json()['type']=='hello'
        assert wb.receive_json()['type']=='hello'
        wa.send_json({'type':'siege_challenge','username':'Defenseur31'})
        waiting=wa.receive_json()
        assert waiting['type']=='siege_waiting'
        invite=wb.receive_json()
        assert invite['type']=='siege_invite' and invite['attacker']=='Attaquant31'
        wb.send_json({'type':'siege_accept','code':invite['code']})
        playing=wa.receive_json()
        assert playing['mode']=='siege' and playing['status']=='playing'
        q=playing['question']
        wa.send_json({'type':'answer','round':1,'choice':correct(q),'power':'attack'})
        # Receive until resolution; network can deliver multiple intermediate snapshots.
        done=None
        for _ in range(6):
            msg=wa.receive_json()
            if msg.get('status')=='finished':
                done=msg;break
        assert done is not None
        assert done['siege_outcome']['won'] is True
        assert done['siege_outcome']['attacker_delta']==18
        assert done['siege_outcome']['defender_delta']==-12
        assert done['rewards']
    assert a.get('/api/me').json()['prestige']==1018
    assert b.get('/api/me').json()['prestige']==988
    assert b.get('/api/me').json()['kingdom']['damage_percent']>0
