"""Persistent, authoritative v0.4 slice guarantees."""
import copy
import json

import pytest
from fastapi.testclient import TestClient
import app
from vertical import CARDS, resolve

@pytest.fixture
def player(tmp_path, monkeypatch):
    monkeypatch.setattr(app, 'DB_PATH', tmp_path / 'vertical.db')
    app.init_db()
    app.auth_attempts.clear()
    with TestClient(app.app) as c:
        r = c.post('/api/register', json={'username':'Lumiera','password':'long-password-42','specialties':['SVT','HGGSP']})
        assert r.status_code == 200
        yield c


def start(c, mode='arena'):
    r = c.post('/api/play/start', json={'mode':mode})
    assert r.status_code == 200, r.text
    return r.json()


def choose(c, r, card='spark'):
    x = c.post('/api/play/action', json={'run_id':r['run_id'],'step':r['step'],'card':card})
    assert x.status_code == 200, x.text
    return x.json()


def answer(c, r, good=True):
    q = r['question']
    source = next(q0 for q0 in app.QUESTIONS if q0['q'] == q['q'])
    index = q['options'].index(source['options'][source['correct']])
    if not good:
        index = (index + 1) % 4
    data = {'run_id':r['run_id'],'step':r['step'],'choice':index}
    response = c.post('/api/play/answer', json=data)
    assert response.status_code == 200, response.text
    return response.json(), data


def test_avatar_and_new_tables_preserve_account_and_are_repeatable(player):
    before = player.get('/api/me').json()
    assert player.post('/api/play/avatar', json={'color':'violet','hair':'long','cape':False}).status_code == 200
    app.init_db()
    app.init_db()
    after = player.get('/api/me').json()
    for key in ('id','score','xp','army','buildings','specialties','prestige'):
        assert before[key] == after[key]
    assert player.get('/api/play').json()['avatar'] == {'color':'violet','hair':'long','cape':False}
    player.post('/api/logout')
    assert player.get('/api/play').status_code == 401
    assert player.post('/api/login', json={'username':'Lumiera','password':'long-password-42'}).status_code == 200
    assert player.get('/api/play').json()['avatar']['color'] == 'violet'
    assert player.post('/api/play/avatar',json={'color':'<script>','hair':'long','cape':False}).status_code == 422


def test_construct_cost_production_collision_and_move_annex(player):
    before = player.get('/api/me').json()
    pos = {'building':'mine','x':0,'y':0,'construct':True}
    result = player.post('/api/play/place',json=pos)
    assert result.status_code == 200, result.text
    after = player.get('/api/me').json()
    assert after['gold'] == before['gold'] - 60
    assert after['wood'] == before['wood'] - 40
    assert after['stone'] == before['stone'] - 20
    assert after['rates']['gold'] == before['rates']['gold'] + 19
    assert player.post('/api/play/place',json=pos).status_code == 409
    assert player.post('/api/play/place',json={'building':'sawmill','x':0,'y':0,'construct':True}).status_code == 409
    move = player.post('/api/play/place',json={'building':'mine_annex','x':1,'y':0})
    assert move.status_code == 200, move.text
    assert move.json()['layout']['mine_annex'] == {'x':1,'y':0}
    assert move.json()['layout']['mine'] == {'x':2,'y':2}
    assert player.post('/api/play/place',json={'building':'wall','x':1,'y':0,'construct':True}).status_code == 400
    assert player.post('/api/play/place',json={'building':'mine','x':12,'y':0}).status_code == 422


def test_insufficient_construction_is_atomic(player):
    with app.connect() as db:
        db.execute('UPDATE users SET gold=0')
    before = player.get('/api/play').json()['layout']
    assert player.post('/api/play/place',json={'building':'mine','x':0,'y':0,'construct':True}).status_code == 400
    assert player.get('/api/play').json()['layout'] == before
    assert player.get('/api/me').json()['buildings']['mine'] == 1


def test_action_locked_answers_hidden_and_energy_server_side(player):
    r = start(player)
    assert 'questions' not in r and 'question' not in r
    assert player.post('/api/play/start',json={'mode':'race'}).status_code == 409
    assert player.post('/api/play/action',json={'run_id':r['run_id'],'step':0,'card':'nova'}).status_code == 400
    q = choose(player,r,'griffin')
    assert 'correct' not in q['question']
    assert player.post('/api/play/action',json={'run_id':r['run_id'],'step':0,'card':'spark'}).status_code == 409
    out, _ = answer(player,q)
    assert out['run']['creatures'] == 1
    assert out['run']['energy'] == 2
    assert out['run']['enemy_hp'] == 78
    assert player.post('/api/play/action',json={'run_id':r['run_id'],'step':0,'card':'spark'}).status_code == 409


def test_answer_retry_resume_and_wrong_answer_have_no_duplicate_award(player):
    r = choose(player,start(player))
    saved = player.get('/api/play').json()['run']
    assert saved == r
    out, data = answer(player,r)
    before = player.get('/api/me').json()
    assert player.post('/api/play/answer',json=data).json() == out
    after = player.get('/api/me').json()
    assert before['score'] == after['score']
    assert before['xp'] == after['xp']
    r = choose(player,out['run'])
    out, _ = answer(player,r,False)
    assert not out['correct']
    assert out['run']['enemy_hp'] == 67
    assert out['run']['hp'] < 90
    assert out['earned']['score'] == 0


def test_race_rewards_once_and_persists_across_login(player):
    r = start(player,'race')
    for _ in range(r['total']):
        q = choose(player,r)
        out, data = answer(player,q)
        r = out['run']
    assert r['finished'] and r['won']
    assert r['distance'] == r['total'] * 150
    assert out['reward']['gold'] == r['total'] * 8
    assert player.post('/api/play/answer',json=data).json() == out
    r = start(player,'race')
    for _ in range(r['total']):
        out, _ = answer(player,choose(player,r))
        r = out['run']
    assert out['reward'] == dict(gold=0,wood=0,stone=0)
    player.post('/api/logout')
    player.post('/api/login',json={'username':'Lumiera','password':'long-password-42'})
    assert player.get('/api/play').json()['run']['finished']


def test_focus_frozen_in_run_and_repetition_does_not_farm_points(player):
    focus = {'subject':'HGGSP','theme':'Faire la guerre, faire la paix','axis':'Axe 1 · Dimension politique de la guerre','subaxis':'Clausewitz : guerre absolue'}
    assert player.post('/api/focus',json=focus).status_code == 200
    r = start(player,'race')
    assert r['total'] == 1
    assert player.post('/api/focus',json={'subject':'SVT'}).status_code == 200
    q = choose(player,r)
    assert q['question']['category'] == 'HGGSP'
    first, _ = answer(player,q)
    assert first['earned']['score'] > 0
    player.post('/api/focus',json=focus)
    second, _ = answer(player,choose(player,start(player,'race')))
    assert second['earned']['score'] == 0
    assert second['earned']['repeat']


def test_no_reward_for_all_wrong_and_no_replay_after_abandon(player):
    r = start(player,'race')
    for _ in range(r['total']):
        out, data = answer(player,choose(player,r),False)
        r = out['run']
    assert not r['won']
    assert out['reward']['gold'] == 0
    r = choose(player,start(player))
    assert player.post('/api/play/abandon').status_code == 200
    assert player.post('/api/play/answer',json={'run_id':r['run_id'],'step':r['step'],'choice':0}).status_code == 409


def test_other_account_cannot_answer_run(player):
    r = choose(player,start(player))
    with TestClient(app.app) as other:
        assert other.post('/api/register',json={'username':'Other','password':'another-password','specialties':['SVT','HGGSP']}).status_code == 200
        assert other.post('/api/play/answer',json={'run_id':r['run_id'],'step':0,'choice':0}).status_code == 409


def test_pure_card_rules_shield_heal_creature_and_failure():
    base = dict(mode='arena',step=0,correct=0,hp=60,enemy_hp=85,energy=5,shield=0,creatures=0,questions=[{}]*8)
    shield = copy.deepcopy(base)
    resolve(shield,'ward',True)
    assert shield['hp'] == 60 and shield['shield'] == 10
    heal = copy.deepcopy(base)
    resolve(heal,'heal',True)
    assert heal['hp'] == 68
    fail = copy.deepcopy(base)
    resolve(fail,'nova',False)
    assert fail['enemy_hp'] == 85 and fail['energy'] == 2
    kill = copy.deepcopy(base)
    kill['enemy_hp'] = 30
    resolve(kill,'nova',True)
    assert kill['finished'] and kill['won'] and kill['hp'] == 60


def test_study_filters_persist_and_empty_difficulty_is_explained(player):
    assert player.post('/api/play/study',json={'difficulty':5}).status_code == 200
    empty = player.post('/api/play/start',json={'mode':'race'})
    assert empty.status_code == 400
    assert 'filtre' in empty.json()['detail']
    assert player.post('/api/play/study',json={'difficulty':3}).status_code == 200
    q = choose(player,start(player,'race'))
    assert q['question']['difficulty'] == 3
    assert player.post('/api/play/study',json={'difficulty':6}).status_code == 422
    answer(player,q,False)
    player.post('/api/play/abandon')
    assert player.post('/api/play/study',json={'weak_only':True}).status_code == 200
    q2 = choose(player,start(player,'race'))
    assert q2['question']['q'] == q['question']['q']
    assert player.get('/api/play').json()['study']['weak_only']


def test_profile_schema_upgrade_preserves_existing_avatar(player):
    # Profile schema from the initial slice, before study preferences were added.
    uid=player.get('/api/me').json()['id']
    with app.connect() as db:
        db.execute('DROP TABLE IF EXISTS play_profiles')
        db.execute("CREATE TABLE play_profiles(user_id INTEGER PRIMARY KEY,avatar TEXT NOT NULL,layout TEXT NOT NULL)")
        db.execute('INSERT INTO play_profiles VALUES(?,?,?)',(uid,json.dumps({'color':'gold','hair':'crest','cape':False}),'{}'))
    p = player.get('/api/play').json()
    assert p['avatar']['color'] == 'gold'
    assert p['study'] == {'difficulty':0,'weak_only':False}


def test_focus_preparation_makes_expensive_spell_reachable(player):
    out, _ = answer(player,choose(player,start(player),'focus'))
    assert out['run']['energy'] == 6
    out, _ = answer(player,choose(player,out['run'],'nova'))
    assert out['run']['enemy_hp'] == 50
    assert out['run']['energy'] == 3
