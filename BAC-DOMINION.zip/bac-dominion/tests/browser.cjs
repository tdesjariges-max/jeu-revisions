/* Real UI + rendering regression checks. Use a disposable BAC_DB_PATH; see README-v04.md. */
'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const fs = require('node:fs');
const {chromium} = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root = path.resolve(__dirname, '..');
const python = process.env.PYTHON_BIN || path.resolve(root, '../.venv/bin/python');
const bank = JSON.parse(execFileSync(python, ['-c', "import json; from questions import QUESTIONS; from study_bank import load_file, ROOT; print(json.dumps(QUESTIONS+[q.legacy() for q in load_file(ROOT/'data/questions/001-lumeria.json')]))"], {cwd:root, encoding:'utf8'}));
const base = process.env.BAC_BASE_URL || 'http://127.0.0.1:8001';
const shots = process.env.BAC_SCREENSHOTS || '/tmp/lumeria-redesign-qa';
fs.mkdirSync(shots, {recursive:true});

(async () => {
  const browser = await chromium.launch({
    executablePath:process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless:true,
    args:['--no-sandbox', '--disable-dev-shm-usage'],
  });
  let currentPage, currentErrors = [], currentRequests = [];
  const measurements = [];
  try {
    for (const mobile of [false, true]) {
      const label = mobile ? 'mobile' : 'desktop';
      const context = await browser.newContext({
        viewport:mobile ? {width:390,height:844} : {width:1280,height:900},
        isMobile:mobile, hasTouch:mobile, reducedMotion:mobile ? 'reduce' : 'no-preference',
      });
      const page = await context.newPage();
      page.setDefaultTimeout(15000);
      currentPage = page;
      const errors = currentErrors = [];
      const requests = currentRequests = [];
      page.on('pageerror', error => errors.push(error.message));
      page.on('request', request => requests.push({path:new URL(request.url()).pathname, method:request.method()}));
      const state = () => page.evaluate(() => {
        const s = window.LumeriaUI.state;
        return {profile:s.profile,play:s.play,run:s.run,mode:s.mode,selected:s.selected,busy:s.busy,result:s.result,practice:s.practice};
      });
      const metrics = () => page.evaluate(() => window.LumeriaUI.getMetrics());
      const idle = () => page.waitForFunction(() => window.LumeriaUI?.state.renderer && window.LumeriaUI.state.ready && !window.LumeriaUI.state.busy && !window.LumeriaUI.state.rendererLoading);
      const action = name => page.locator(`[data-action="${name}"]:visible`).first();
      const navigate = async mode => {
        await page.locator(`[data-mode="${mode}"]:visible`).first().click();
        await page.waitForFunction(mode => window.LumeriaUI.state.mode === mode && !window.LumeriaUI.state.rendererLoading, mode);
        if (mode !== 'study') await idle();
      };
      const screenshot = name => page.screenshot({path:path.join(shots, `${name}-${label}.png`),fullPage:true});
      async function tile(x,y,buildingOffset=0) {
        const host = page.locator('#game');
        await host.scrollIntoViewIfNeeded();
        const point = await page.evaluate(({x,y,buildingOffset}) => {const r=window.LumeriaUI.state.renderer;const p=r.cellToScreen(x,y);return{x:p.x,y:p.y-buildingOffset*r.view.zoom};}, {x,y,buildingOffset});
        const box = await host.boundingBox();
        assert(point.x >= 0 && point.x <= box.width && point.y >= 0 && point.y <= box.height, `Target cell ${x},${y} is inside the visible map`);
        if (mobile) await page.touchscreen.tap(box.x+point.x, box.y+point.y);
        else await page.mouse.click(box.x+point.x, box.y+point.y);
      }
      async function answer(good=true) {
        await page.locator('#quiz-dialog[open] #answers [data-answer]').first().waitFor();
        const publicQuestion = await page.evaluate(() => {
          const s = window.LumeriaUI.state;
          return s.quizSource === 'run' ? s.run.question : s.practice.question;
        });
        assert.equal(await page.locator('#quiz-title').textContent(), publicQuestion.q);
        assert.deepEqual(await page.locator('#answers [data-answer] span').allTextContents(), publicQuestion.options, 'Visible choices match the shuffled question');
        const source = bank.find(q => q.q === publicQuestion.q);
        assert(source, 'Rendered question belongs to the authored bank');
        const correct = publicQuestion.options.indexOf(source.options[source.correct]);
        assert(correct >= 0, 'Correct answer is present after option shuffling');
        const choice = good ? correct : (correct+1)%4;
        await page.locator(`#quiz-dialog [data-answer="${choice}"]`).click();
        await page.waitForFunction(() => !window.LumeriaUI.state.busy && Boolean(window.LumeriaUI.state.result) && Boolean(document.querySelector('#quiz-dialog[open] .answer-explanation')));
        const result = (await state()).result;
        assert.equal(result.correct, good);
        assert((await page.locator('.answer-explanation').innerText()).includes(result.explanation));
        await page.locator('#quiz-dialog [data-action="continue-quiz"]').click();
        return result;
      }

      await page.goto(base+'/');
      await page.locator('#auth-form').waitFor();
      assert.equal(await page.evaluate(() => typeof window.Phaser), 'undefined', 'Unauthenticated entrance does not load Phaser');
      assert.equal(requests.some(r => /phaser|world\.js/.test(r.path)), false, 'Cold entrance has no engine/render script requests');
      await screenshot('entrance');
      const username = 'Redesign'+Date.now().toString().slice(-7)+(mobile?'M':'D');
      const password = 'browser-password-42';
      await page.locator('#username').fill(username);
      await page.locator('#password').fill(password);
      await page.locator('#auth-form button').click();
      await idle();
      const originalUser = (await state()).profile;
      assert.equal(originalUser.username, username);
      assert.equal((await metrics()).mapBuilds, 1);
      await screenshot('kingdom');

      // A beginner can revise directly inside the game and finish the whole short session.
      await action('practice').click();
      let practiceResult;
      do { practiceResult = await answer(true); } while (!practiceResult.finished);
      await page.waitForFunction(() => !window.LumeriaUI.state.practice);
      assert((await state()).profile.score > originalUser.score);

      // Construction uses the real shop and the automatic placement affordance.
      const beforeBuild = (await state()).profile;
      await action('shop').click();
      await page.locator('#modal-dialog [data-build="mine"]').click();
      await page.locator('#modal-dialog [data-action="auto-place"]').click();
      await page.waitForFunction(() => !window.LumeriaUI.state.busy && Boolean(window.LumeriaUI.state.play.layout.mine_annex));
      let s = await state();
      assert.equal(s.selected, 'mine_annex');
      assert.equal(s.profile.gold, beforeBuild.gold-60);
      assert.equal(s.profile.wood, beforeBuild.wood-40);
      assert.equal(s.profile.stone, beforeBuild.stone-20);
      await action('move').click();
      await tile(4,4);
      await page.waitForFunction(() => !window.LumeriaUI.state.busy && !window.LumeriaUI.state.moving);
      assert.deepEqual((await state()).play.layout.mine_annex, {x:4,y:4});

      // Avatar, accessible dialogs, and server persistence survive logout and login.
      if (mobile) {
        await page.getByRole('button',{name:'Aide et réglages',exact:true}).click();
        await page.locator('#modal-dialog [data-action="avatar"]').click();
      } else await page.getByRole('button',{name:'Personnaliser mon avatar',exact:true}).click();
      await page.locator('#avatar-color').selectOption('violet');
      await page.locator('#avatar-hair').selectOption('long');
      await page.locator('#avatar-form [name="cape"]').uncheck();
      await page.locator('#avatar-form button').click();
      await page.waitForFunction(() => !window.LumeriaUI.state.busy && !document.querySelector('#modal-dialog').open);
      assert.deepEqual((await state()).play.avatar, {color:'violet',hair:'long',cape:false});
      await page.getByRole('button',{name:'Aide et réglages',exact:true}).click();
      await page.keyboard.press('Escape');
      assert.equal(await page.locator('#modal-dialog').evaluate(dialog => dialog.open), false);
      await page.getByRole('button',{name:'Aide et réglages',exact:true}).click();
      await page.locator('#modal-dialog [data-action="logout"]').click();
      await page.locator('#auth-form').waitFor();
      await page.locator('[data-auth="login"]').click();
      await page.locator('#username').fill(username);
      await page.locator('#password').fill(password);
      await page.locator('#auth-form button').click();
      await idle();
      s = await state();
      assert.equal(s.profile.id, originalUser.id);
      assert.deepEqual(s.play.avatar, {color:'violet',hair:'long',cape:false});
      assert.deepEqual(s.play.layout.mine_annex, {x:4,y:4});

      // Focus form must be enabled and actually persist through bootstrap.
      await page.getByRole('button',{name:'Changer de révision',exact:true}).first().click();
      await page.locator('#focus-form [name="subject"]').selectOption('HGGSP');
      const themes = await page.locator('#focus-form [name="theme"] option').allTextContents();
      assert(themes.includes('De nouveaux espaces de conquête') && themes.includes('L’enjeu de la connaissance'));
      await page.locator('#focus-form [name="theme"]').selectOption('Faire la guerre, faire la paix');
      await page.locator('#focus-form [name="difficulty"]').selectOption('2');
      const saveFocus = page.locator('#focus-form .dialog-actions button').last();
      assert(await saveFocus.isEnabled(), 'Valid nonempty focus selection can be saved');
      await saveFocus.click();
      await page.waitForFunction(() => !window.LumeriaUI.state.busy && !document.querySelector('#modal-dialog').open);
      s = await state();
      assert.equal(s.profile.focus.subject, 'HGGSP');
      assert.equal(s.profile.focus.theme, 'Faire la guerre, faire la paix');
      assert.equal(s.play.study.difficulty, 2);

      // Static scenes stop rendering. Selection/collection preserve the camera and cached map.
      await page.locator('#game').scrollIntoViewIfNeeded();
      await page.getByRole('button',{name:'Zoomer',exact:true}).click();
      const hostBox = await page.locator('#game').boundingBox();
      await page.mouse.move(hostBox.x+hostBox.width*.55, hostBox.y+hostBox.height*.55);
      await page.mouse.down();
      await page.mouse.move(hostBox.x+hostBox.width*.55+22,hostBox.y+hostBox.height*.55+12,{steps:4});
      await page.mouse.up();
      const cameraBefore = await page.evaluate(() => ({...window.LumeriaUI.state.renderer.view}));
      for (const id of ['academy','mine','academy']) {
        const position = (await state()).play.layout[id];
        await tile(position.x, position.y, 75);
        await page.waitForFunction(id => window.LumeriaUI.state.selected === id, id);
        await action('collect').click();
        await idle();
        assert.deepEqual(await page.evaluate(() => ({...window.LumeriaUI.state.renderer.view})), cameraBefore, 'Selection and collection preserve map view');
        assert.equal((await metrics()).mapBuilds, 1, 'Cached island is built once');
      }
      await page.waitForFunction(() => window.LumeriaUI.getMetrics()?.sleeping === true);
      const staticBefore = await metrics();
      await page.waitForTimeout(500);
      const staticAfter = await metrics();
      assert.equal(staticAfter.frames, staticBefore.frames, 'Idle map renders zero additional frames');
      measurements.push({viewport:label, idleFrames500ms:staticAfter.frames-staticBefore.frames, mapBuilds:staticAfter.mapBuilds});
      await screenshot('kingdom-personalized');

      // Tactical duel, creature effect and pending-question reconnect use real UI.
      await navigate('arena');
      await action('start').click();
      await page.locator('[data-card="griffin"]').click();
      await page.locator('#answers').waitFor();
      const pendingQuestion = (await state()).run.question;
      await page.reload();
      await idle();
      await page.locator('#answers').waitFor();
      assert.deepEqual((await state()).run.question, pendingQuestion);
      assert.equal((await state()).profile.focus.subject, 'HGGSP');
      await answer(true);
      s = await state();
      assert.equal(s.run.creatures, 1);
      assert.equal(s.run.enemy_hp, 78, 'Summoned griffin really damages the opponent');
      await screenshot('arena');
      while (!(await state()).run.finished) {
        await page.locator('[data-card="spark"]').click();
        await answer(true);
      }
      assert.equal((await state()).run.won, true);
      assert((await metrics()).animations > 0, 'Server events executed visual animations');

      await navigate('race');
      await action('start').click();
      // The first obstacle opens automatically; later obstacles use the explicit CTA.
      let raceResult = await answer(true);
      let raceIndex = 1;
      while (!raceResult.run.finished) {
        await action('next-obstacle').click();
        raceResult = await answer(raceIndex++ !== 1);
      }
      s = await state();
      assert.equal(s.run.won, true);
      assert.equal(s.run.correct, s.run.total-1, 'One deliberately wrong answer causes a real course penalty');
      assert.equal(s.run.distance, (s.run.total-1)*150+55);
      await screenshot('race');

      // Mode switching keeps a single renderer/canvas and bounded texture/object counts.
      await navigate('kingdom');
      await page.evaluate(() => {window.__qaCanvas=document.querySelector('#game canvas');window.__qaRenderer=window.LumeriaUI.state.renderer;});
      const warm = await metrics();
      for (let cycle=0;cycle<3;cycle++) for (const mode of ['arena','race','kingdom']) await navigate(mode);
      const afterSwitching = await metrics();
      assert(await page.evaluate(() => window.__qaCanvas===document.querySelector('#game canvas') && window.__qaRenderer===window.LumeriaUI.state.renderer), 'World modes reuse one canvas and renderer');
      assert.equal(await page.locator('canvas').count(), 1);
      assert.equal(afterSwitching.mapBuilds, 1);
      assert.equal(afterSwitching.textures, warm.textures, 'Returning to the same mode keeps texture count stable');
      assert.equal(afterSwitching.worldObjects, warm.worldObjects, 'Returning to the same mode keeps world object count stable');
      assert(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth), 'No page overflow at target viewport');
      assert.equal(requests.some(r => r.path==='/api/me' || r.path==='/api/play'), false, 'UI refreshes use bootstrap without duplicate legacy reads');
      assert.deepEqual(errors, [], 'No JavaScript runtime errors');
      await context.close();
      console.log(`${label}: real registration, guided revision, construction/move, avatar/login, focus, duel/resume, race, modal Escape and renderer performance passed`);
    }
    fs.writeFileSync(path.join(shots,'performance.json'),JSON.stringify(measurements,null,2)+'\n');
    console.log(JSON.stringify(measurements));
  } catch (error) {
    if (currentPage && !currentPage.isClosed()) {
      console.error('Page:',currentPage.url());
      console.error('Errors:',currentErrors);
      console.error('Last network requests:',currentRequests.slice(-12));
      console.error('Visible toast:',await currentPage.locator('#toast').textContent().catch(()=>''));
      await currentPage.screenshot({path:path.join(shots,'failure.png'),fullPage:true}).catch(()=>{});
    }
    throw error;
  } finally {await browser.close();}
})().catch(error => {console.error(error);process.exitCode=1;});
