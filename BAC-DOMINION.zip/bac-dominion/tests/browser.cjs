/* Run against a disposable BAC_DB_PATH. See README-v04.md. */
const assert = require('node:assert/strict');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const fs = require('node:fs');
const {chromium} = require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const root=path.resolve(__dirname,'..');
const python=process.env.PYTHON_BIN||path.resolve(root,'../.venv/bin/python');
const bank=JSON.parse(execFileSync(python,['-c',"import json; from questions import QUESTIONS; from study_bank import load_file, ROOT; print(json.dumps(QUESTIONS+[q.legacy() for q in load_file(ROOT/'data/questions/001-lumeria.json')]))"],{cwd:root,encoding:'utf8'}));
const base=process.env.BAC_BASE_URL||'http://127.0.0.1:8001';
const shots=process.env.BAC_SCREENSHOTS||'/tmp/bac-browser';
fs.mkdirSync(shots,{recursive:true});
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 let currentPage;
 try {
 for(const mobile of [false,true]){
   const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1280,height:900},isMobile:mobile,hasTouch:mobile,reducedMotion:'reduce'});
   const page=await context.newPage();currentPage=page;const errors=[];page.on('pageerror',e=>errors.push(e.message));
   // Use the real registration interface, sharing its session with the new scenes.
   await page.goto(base+'/');await page.getByRole('link',{name:'Connexion / inscription'}).click();
   const username='Ui'+Date.now().toString().slice(-9)+(mobile?'M':'D');
   await page.locator('#username').fill(username);await page.locator('#password').fill('browser-password-42');
   await page.getByRole('button',{name:'Fonder mon royaume'}).click();
   await page.getByRole('link',{name:/Entrer dans Luméria/}).click();
   await page.waitForFunction(()=>Boolean(scene?.hero));
   assert.equal(await page.locator('#abandon').isVisible(),false);
   await page.locator('#avatar-panel summary').click();
   await page.locator('#avatar-form [name=color]').selectOption('violet');
   await page.locator('#avatar-form [name=hair]').selectOption('long');
   await page.locator('#avatar-form button').click();await page.getByText('Avatar sauvegardé.',{exact:true}).waitFor();
   await page.getByRole('button',{name:'Construire : Mine d’or',exact:true}).click();
   async function tile(x,y){
     await page.locator("canvas").scrollIntoViewIfNeeded();
     const point=await page.evaluate(({x,y})=>{const c=scene.camera,w=scene.scale.width;const p={x:w/2+(x-y)*38*.9-30,y:40+(x+y)*38*.42};return {x:(p.x-c.worldView.x)*c.zoom,y:(p.y-c.worldView.y)*c.zoom};},{x,y});
     const box=await page.locator('canvas').boundingBox();
     if(mobile)await page.touchscreen.tap(box.x+point.x,box.y+point.y);else await page.mouse.click(box.x+point.x,box.y+point.y);
   }
   await tile(0,9);await page.getByText('Royaume sauvegardé.',{exact:true}).waitFor();
   let p=await (await context.request.get(base+'/api/play')).json();assert.deepEqual(p.layout.mine_annex,{x:0,y:9});
   await page.getByRole('combobox',{name:'Sélectionner un bâtiment'}).selectOption('mine_annex');
   await page.getByRole('button',{name:'Déplacer',exact:true}).click();await tile(1,9);
   await page.waitForFunction(()=>!S.busy&&!S.moving);
   p=await (await context.request.get(base+'/api/play')).json();assert.deepEqual(p.layout.mine_annex,{x:1,y:9});
   await page.reload();await page.waitForFunction(()=>Boolean(scene?.hero));
   assert.equal(await page.locator('#avatar-form [name=color]').inputValue(),'violet');
   await page.screenshot({path:path.join(shots,`kingdom-${mobile?'mobile':'desktop'}.png`),fullPage:true});
   // Topic picker available without leaving the game, including all six HGGSP themes.
   await page.getByRole('button',{name:'Changer de révision',exact:true}).click();
   await page.locator('[name=subject]').selectOption('HGGSP');
   const themes=await page.locator('[name=theme] option').allTextContents();assert(themes.includes('De nouveaux espaces de conquête'));assert(themes.includes('L’enjeu de la connaissance'));
   await page.locator('[name=subject]').selectOption('');
   await page.locator('#focus-form button[type=submit]').click();await page.locator('#focus-dialog').waitFor({state:'hidden'});
   await page.getByRole('button',{name:'Arène · contre Nox',exact:true}).click();await page.getByRole('button',{name:'Commencer',exact:true}).click();
   await page.getByRole('button',{name:/Griffon des pages/}).click();await page.locator('#answers button').first().waitFor();
   const prompt=await page.locator('#question h3').textContent();
   await page.reload();await page.waitForFunction(()=>Boolean(scene?.hero));assert.equal(await page.locator('#question h3').textContent(),prompt);
   async function answer(good=true){
     const prompt=await page.locator('#question h3').textContent();const q=bank.find(x=>x.q===prompt);assert(q,'Question in test bank');
     const opts=await page.locator('#answers button').allTextContents();let choice=opts.indexOf(q.options[q.correct]);assert(choice>=0);if(!good)choice=(choice+1)%4;
     await page.locator('#answers button').nth(choice).click();
     await page.waitForFunction(()=>!S.busy&&Boolean(S.result));
     await page.getByRole('button',{name:/^(Continuer|Voir le résultat)$/}).click();
   }
   await answer();let state=await (await context.request.get(base+'/api/play')).json();assert.equal(state.run.creatures,1);
   await page.screenshot({path:path.join(shots,`arena-${mobile?'mobile':'desktop'}.png`),fullPage:true});
   while(!state.run.finished){await page.getByRole('button',{name:/Éclat solaire/}).click();await answer();state=await (await context.request.get(base+'/api/play')).json();}
   assert.equal(state.run.won,true);const afterArena=await (await context.request.get(base+'/api/me')).json();assert(afterArena.score>0);
   await page.getByRole('button',{name:'Party Games · course solo',exact:true}).click();await page.getByRole('button',{name:'Commencer',exact:true}).click();
   state=await (await context.request.get(base+'/api/play')).json();
   for(let i=0;i<state.run.total;i++){await page.getByRole('button',{name:'Aborder l’obstacle suivant',exact:true}).click();await answer(i!==1);}
   state=await (await context.request.get(base+'/api/play')).json();assert(state.run.finished&&state.run.won);assert.equal(state.run.correct,state.run.total-1);
   await page.screenshot({path:path.join(shots,`race-${mobile?'mobile':'desktop'}.png`),fullPage:true});
   assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'No horizontal overflow');
   assert.deepEqual(errors,[],'No JavaScript runtime errors');
   await context.close();console.log(`${mobile?'Mobile tactile 390×844':'Desktop 1280×900'}: registration, construction, move, avatar, revision, reload/resume, duel victory and course completion passed`);
 }
 }catch(error){if(currentPage&&!currentPage.isClosed()){console.error("Browser feedback:",await currentPage.locator("#feedback").textContent());await currentPage.screenshot({path:path.join(shots,"failure.png"),fullPage:true});}throw error;}finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
