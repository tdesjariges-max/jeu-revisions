"""Original, family-friendly fantasy setting for Bac Dominion.

Story chapters are one-time rewards gated behind demonstrated in-game progress,
not by daily login windows or time spent online.
"""
CHAPTERS = [
    {
        'id': 'etincelle', 'title': 'I · La dernière étincelle', 'icon': '✨',
        'character': 'Pim, le jeune griffon',
        'intro': 'Les livres du royaume de Luméria perdent leurs lettres. Pim, un petit griffon bien trop curieux, découvre sous la bibliothèque une étincelle qui ne s’éteint que lorsque personne ne cherche à comprendre.',
        'resolution': 'Tu redonnes vie à la première page du Grand Livre. Pim t’offre un médaillon d’explorateur et promet de t’accompagner.',
        'objective': 'Fonder ton royaume', 'requires': 'start',
        'reward': {'gold': 55, 'wood': 40, 'stone': 20},
    },
    {
        'id': 'bibliotheque', 'title': 'II · La bibliothèque volante', 'icon': '📜',
        'character': 'Maë, apprentie cartographe',
        'intro': 'Une bibliothèque flotte au-dessus des prairies. Ses escaliers changent de place à chaque nouvelle question. Maë te confie une carte couverte de symboles : les réponses justes font apparaître les chemins cachés.',
        'resolution': 'Les étagères retrouvent leur place. Une petite étoile d’encre brille sur la carte de Maë.',
        'objective': 'Achever une mission RPG ou un entraînement', 'requires': 'quest',
        'reward': {'gold': 75, 'wood': 65, 'stone': 35},
    },
    {
        'id': 'foret', 'title': 'III · Les arbres qui murmurent', 'icon': '🌲',
        'character': 'Orin, gardien des clairières',
        'intro': 'Les arbres de la Forêt des mémoires ne se rappellent plus les saisons. Orin explique que le brouillard de l’Oubli grandit lorsque les habitants cessent de poser des questions.',
        'resolution': 'La forêt reverdit et les oiseaux retrouvent leurs chants. Orin rejoint les défenseurs de ton royaume.',
        'objective': 'Conquérir la Forêt des mémoires', 'requires': 'forest',
        'reward': {'gold': 90, 'wood': 100, 'stone': 50},
    },
    {
        'id': 'pont', 'title': 'IV · Le pont des mille idées', 'icon': '🌉',
        'character': 'Baldric, chevalier du Pourquoi',
        'intro': 'Un chevalier en armure trop grande garde un pont de pierre. Baldric n’accepte pas la force brute : il demande des arguments, des preuves et des explications claires pour révéler le passage.',
        'resolution': 'Le pont s’illumine. Baldric s’incline, impressionné non par la puissance de ton armée, mais par ton raisonnement.',
        'objective': 'Vaincre un boss de méthodologie', 'requires': 'boss',
        'reward': {'gold': 120, 'wood': 70, 'stone': 95},
    },
    {
        'id': 'aurore', 'title': 'V · L’aurore de Luméria', 'icon': '🏰',
        'character': 'Nox, le dragon des pages blanches',
        'intro': 'Au sommet de la Citadelle des oubliés, Nox, un dragon qui a peur de ne rien savoir, a enfermé les souvenirs du royaume dans une sphère. Il n’est pas méchant : il a simplement oublié qu’on peut apprendre petit à petit.',
        'resolution': 'La sphère s’ouvre : les mots reviennent, les habitants célèbrent le courage d’apprendre et Nox devient le gardien bienveillant des nouvelles questions.',
        'objective': 'Conquérir la Citadelle des oubliés', 'requires': 'citadel',
        'reward': {'gold': 180, 'wood': 150, 'stone': 150},
    },
]
