"""Topic-strict, balanced multiplayer sampling. No database or client trust here."""
import random

FOCUS_KEYS = ('subject', 'theme', 'axis', 'subaxis')
QUESTION_KEYS = ('category', 'theme', 'axis', 'subaxis')


def matches(question, focus):
    return all(not focus.get(f) or question[q] == focus[f]
               for f, q in zip(FOCUS_KEYS, QUESTION_KEYS))


def mixed_indices(questions, selections, rounds, rng=None):
    """Round-robin unique questions from each distinct selection, shuffled at end.

    Two disjoint topics and six rounds yield exactly 3+3. Overlapping topics
    never duplicate a question. More topics than rounds rotate via a random
    first cycle; empty pools are an error, never a wider fallback.
    Returns (index, selection_index) pairs; no answers are exposed.
    """
    rng = rng or random.SystemRandom()
    groups, seen = [], set()
    for selection in selections:
        key = tuple(selection.get(k, '') for k in FOCUS_KEYS)
        if key in seen:
            continue
        seen.add(key)
        pool = [i for i, q in enumerate(questions) if matches(q, selection)]
        if not pool:
            raise ValueError('Aucune question pour une des sélections du salon.')
        rng.shuffle(pool)
        groups.append((selections.index(selection), pool))
    if not groups:
        raise ValueError('Choisis un thème avant de jouer avec tes amis.')
    used, chosen = set(), []
    while len(chosen) < rounds:
        cycle = groups[:]
        rng.shuffle(cycle)
        advanced = False
        for origin, pool in cycle:
            while pool and pool[-1] in used:
                pool.pop()
            if not pool:
                continue
            idx = pool.pop()
            used.add(idx)
            chosen.append((idx, origin))
            advanced = True
            if len(chosen) == rounds:
                break
        if not advanced:
            break
    rng.shuffle(chosen)
    return chosen
