# Vérifications de performance — refonte Luméria

Comparaison de l’archive initialement livrée (`SHA-256 23be9ff9b7bf73cf02652b79f574e3d00fffcdb4c8e30d46d614ac890bca9170`) et de la refonte. Ancienne et nouvelle versions sont lancées dans des dossiers et bases de test séparés.

## Protocole

Chromium headless 154, rendu Canvas, ordinateur 1280 × 900 et émulation tactile 390 × 844, processeur ralenti ×6 par le navigateur. Serveurs en localhost, sans limitation artificielle de bande passante. Contextes neufs pour le chargement à froid. Les tests fonctionnels complémentaires utilisent aussi un ordinateur avec animations normales et un mobile avec animations réduites.

## Résultats reproductibles sur les parcours contrôlés

| Vérification | Première tranche | Refonte |
| --- | --- | --- |
| Moteur Phaser demandé avant connexion | 1 196 122 octets | Aucun chargement |
| Images de jeu redessinées pendant 1 seconde immobile | 29 à 54 | 0 |
| Reconstruction du décor sur 10 sélections | 10 | 0 |
| Instances des bâtiments après les sélections | Détruites et recréées | Conservées |
| Requêtes GET pour 10 récoltes | 20 | 10 |
| Zones interactives par case | 120 | Aucune : calcul de coordonnées |
| Textures du nouveau moteur après passage à l’atlas | 20 avant atlas | 8 après atlas, stables |

L’atlas remplace le chargement des treize SVG de jeu par un PNG et un JSON. Les SVG restent utilisés pour les petites illustrations de l’interface. Le décor est construit une fois et conservé. Les retours répétés royaume → arène → course → royaume gardent des nombres d’objets et de textures stables. Les tests vérifient aussi que la caméra n’est pas réinitialisée après sélection et récolte.

Une séquence d’attaque complète a été observée autour de 0,93 seconde avec animations. La réduction des animations applique directement le résultat. Masquer l’onglet pendant une action résout les animations en attente et permet à la réponse serveur de terminer ; la partie ne reste pas bloquée dans une attente graphique.

## Démarrage : limites des mesures

La taille du moteur transféré avec compression passe d’environ 1,20 Mo à 321 Ko. L’accueil sans compte ne demande plus le moteur et était plus rapide dans les essais. Le démarrage complet de la première scène sur un contexte neuf dépend toujours du décodage/compilation de Phaser et des illustrations.

Les temps de démarrage à froid n’ont **pas** donné un gain uniforme sur la machine partagée. Une comparaison a mesuré environ 2,55 s → 3,72 s sur ordinateur et 2,74 s → 2,90 s sur l’émulation mobile ; une série séparée de trois essais a mesuré des médianes de 5,00 s → 3,36 s. Un essai exploratoire a aussi montré un pic plus lent pendant la préparation de l’atlas. Ces résultats ne justifient pas une promesse générale de démarrage plus rapide.

Le moteur et le module de scène sont désormais demandés en parallèle dès que la connexion est validée, avant de construire toute l’interface. Le rendu au repos, les rafales de requêtes et les reconstructions ont des améliorations vérifiées indépendamment de cette variabilité de démarrage. Les tests sur téléphone physique, Safari/iOS et une vraie connexion mobile restent à effectuer.

## Vérifications finales

- 30 tests Python réussis : migration réelle v0.3.1, comptes, économie, questions, combats, sauvegarde, reprise, idempotence et chargement groupé.
- Deux parcours navigateur complets réussis : ordinateur et mobile tactile, avec une erreur volontaire dans la course.
- Aucune erreur JavaScript d’exécution ni débordement horizontal sur ces parcours.
- Aucun chargement de Phaser sur l’accueil déconnecté ; zéro trame supplémentaire sur 500 ms au repos.
- Même canvas et mêmes nombres d’objets/textures après neuf changements de scènes.
- Lanceur Python local : disponibilité HTTP vérifiée avant annonce « prêt ». Le batch Windows est fourni et relu, sans exécution Windows native dans cette session.

Ces contrôles démontrent les parcours testés ; ils ne sont pas un test de charge à 60 joueurs ni une mesure de consommation électrique.
