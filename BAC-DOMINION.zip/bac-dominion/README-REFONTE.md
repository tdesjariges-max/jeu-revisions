# Luméria — refonte cartoon et confort de jeu

Cette version reprend l’interface de la première tranche v0.4 : entrée dans le jeu, navigation, graphismes, manipulation du royaume et moteur de rendu. Les comptes et l’économie existants restent la source de vérité. Les nouveaux duels et la course restent des modes solo ; les salons multijoueurs, missions, raids et classements sont conservés dans les modes classiques.

## Jouer sous Windows

**Lancement le plus simple :** après extraction du ZIP, ouvre `bac-dominion` et double-clique sur **`LANCER-JEU.cmd`**. Il prépare les dépendances si nécessaire, attend que le serveur soit prêt, puis ouvre le jeu dans ton navigateur. Garde sa fenêtre ouverte pendant la partie. Python 3.10+ doit être installé ; Internet est nécessaire à la première installation des dépendances.

Le lanceur Python a été vérifié dans le cloud. Le fichier batch a été relu mais n’a pas été exécuté sur Windows pendant cette session. Les commandes PowerShell restent disponibles si tu préfères un lancement manuel :

```powershell
cd .\bac-dominion
py -3 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
& .\.venv\Scripts\python.exe -m uvicorn app:app --host 0.0.0.0 --port 8000 --workers 1
```

Ouvre `http://localhost:8000` sur ton PC. L’inscription et la connexion sont maintenant intégrées à l’accueil de Luméria. Un compte existant retrouve son mot de passe, ses ressources et son royaume. Garde un seul worker Uvicorn pour les salons classiques.

Pour une sauvegarde existante, conserve son fichier SQLite et son éventuelle variable `BAC_DB_PATH`. Arrête l’ancien serveur et effectue une sauvegarde SQLite avant de remplacer une installation. Ne remplace pas ta base par une base vide livrée ailleurs : cette archive ne contient aucune base de joueur. Le chemin par défaut reste `bac_dominion.db` à côté de `app.py`.

## Les premières minutes

1. Crée ton compte ou connecte-toi. Nox explique les trois premières étapes avec le bouton `?`.
2. Appuie sur **Réviser** ou **C’est parti**. Réponds à une question et lis l’explication.
3. Ouvre **Construire**, choisis une mine, une scierie ou une carrière, puis **Placer pour moi**. Le serveur vérifie le coût et la place disponible.
4. Touche un bâtiment pour voir son rôle, sa production et le coût d’amélioration. La liste des bâtiments est aussi accessible avec le bouton `≡` de la carte.
5. Essaie **Arène** ou **Course** depuis la navigation. Le choix de révision reste accessible avec le bouton du livre.

La construction sur une case précise reste possible. Glisser déplace la carte ; les boutons +/− et le pincement tactile règlent le zoom. Les flèches du clavier déplacent également la carte et la touche Origine la recentre. Les questions s’ouvrent dans une fenêtre lisible et accessible au clavier ; les explications arrivent après les actions animées.

## Refonte livrée

- Palette crème, lavande, ciel bleu, corail et vert lumineux ; textes et actions mieux séparés.
- Six bâtiments isométriques distincts, avatars expressifs, dragon, griffon, décors et cartes illustrées.
- 31 SVG originaux et un atlas de sprites local. Les images de référence de jeux tiers ne sont pas redistribuées.
- Accueil avec inscription/connexion, tutoriel contextualisé et actions principales **Construire / Récolter / Réviser**.
- Placement automatique, prix visibles et explications quand les ressources ou l’énergie manquent.
- Aperçu de personnalisation et sauvegarde de la couleur, de la coiffure et de la cape.
- Questions et corrections dans des fenêtres dédiées ; reprise d’une question après rechargement ; entraînement repris lorsqu’il est encore actif.
- Navigation mobile à cinq entrées et accès aux modes classiques conservés. Leur palette est harmonisée avec le nouvel univers.
- Petits sons de réussite facultatifs, désactivés par défaut ; animations réduites lorsque le système le demande.

Les références visuelles ont été consultées sur les sites officiels de **Supercell / Clash of Clans** et **Ironhide / Kingdom Rush**. Les principes retenus sont la lisibilité des silhouettes, les proportions expressives et une palette limitée. Les URL et les consultations réellement effectuées sont documentées dans [static/art/REFERENCES.md](static/art/REFERENCES.md). Tous les dessins livrés sont originaux.

## Performance : ce qui a changé

- Le moteur Phaser est chargé à la demande, après connexion et seulement lorsqu’une scène est nécessaire. L’accueil n’exécute aucun moteur de jeu.
- Le rendu Canvas se met en veille quand la scène est immobile ou l’onglet masqué ; il se réveille pour les gestes, redimensionnements et animations utiles.
- Le décor est mis en cache ; une sélection ou une récolte ne détruit plus les bâtiments ni la caméra.
- Les trois scènes partagent le même moteur et le même canvas lors des changements de mode.
- Le placement utilise une transformation de coordonnées, avec prévisualisation des cases ; il ne crée plus 120 zones interactives.
- Les sprites sont pré-rendus dans un atlas local afin de réduire le travail de décodage au lancement des scènes.
- Une seule requête `/api/play/bootstrap` remplace l’enchaînement `/api/me` puis `/api/play`. Les migrations SQL ne sont plus rejouées pendant les lectures normales.
- Les réponses volumineuses sont compressées. Les polices externes ont été supprimées.
- Les mises à jour rapprochées des salons classiques sont regroupées sur une trame d’affichage.
- Le service worker a un nouveau cache ; il ne précharge pas le moteur avant qu’un joueur ouvre une scène.

Les mesures détaillées de la session de validation sont conservées dans `PERFORMANCE.md`. Elles décrivent des essais Chromium sur la machine cloud, y compris une émulation tactile et un processeur ralenti ; elles ne garantissent pas un nombre d’images par seconde sur tous les téléphones physiques.

## Tests

```powershell
& .\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
& .\.venv\Scripts\python.exe -m pytest -q
```

Les tests Python couvrent la migration réelle d’une sauvegarde v0.3.1, la connexion, les coûts, la persistance, les dégâts, les récompenses, l’idempotence des nouvelles réponses, les filtres pédagogiques et le nouveau chargement groupé. Le client Starlette/httpx émet un avertissement de dépréciation connu.

`tests/browser.cjs` vérifie les parcours réels sur ordinateur et mobile tactile : inscription, révisions et corrections, construction et déplacement, personnalisation, déconnexion/reconnexion, filtres, reprise d’une question, invocation, victoire au duel, course avec une erreur volontaire et navigation au clavier. Il vérifie aussi l’absence de débordement horizontal, les erreurs JavaScript et plusieurs invariants de performance.

Pour reproduire les tests navigateur : lancer un serveur séparé avec une base jetable sur le port 8001, puis :

```powershell
npm install --prefix .browser-tools --no-audit --no-fund playwright
$env:PLAYWRIGHT_MODULE = Join-Path $PWD '.browser-tools\node_modules\playwright'
$env:PYTHON_BIN = Join-Path $PWD '.venv\Scripts\python.exe'
$env:CHROMIUM_PATH = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$env:BAC_BASE_URL = 'http://127.0.0.1:8001'
$env:BAC_SCREENSHOTS = Join-Path $env:TEMP 'lumeria-captures'
node tests\browser.cjs
```

Adapter le chemin de Chrome si nécessaire. La procédure PowerShell est fournie pour Windows ; les vérifications de cette session sont exécutées dans le cloud Linux avec Chromium.

## Architecture et fichiers

- `static/play.html`, `play.css`, `play.js` : entrée, navigation, commandes, formulaires, questions et état de l’interface.
- `static/world.js` : rendu Phaser Canvas, sprites, caméra, coordonnées, animations et mise en veille.
- `static/art/` : ressources originales ; SVG pour l’interface, atlas pour les scènes.
- `vertical.py` : simulation et routes de jeu persistantes, dont le chargement groupé.
- `app.py` : authentification et systèmes historiques, migrations additives et compression HTTP.
- `static/classic-theme.css` et `static/app.js` : thème des anciens modes et regroupement des rafales de mises à jour des salons.
- `static/sw.js`, `manifest.webmanifest`, `icon.svg` : actualisation du cache et de l’apparence PWA.
- `tests/test_redesign_api.py`, `tests/browser.cjs` : nouvelles vérifications serveur, interface et performance.
- `LANCER-JEU.cmd`, `tools/start_local.py` : préparation et ouverture automatique du jeu après confirmation que le serveur répond.

L’ordre des questions historiques et les anciennes routes sont conservés. Les sessions de duel/courses stockent toujours les questions mélangées et la progression côté serveur. Les graphismes n’attribuent jamais de dégâts ou de ressources.

## Limites conservées

Cette refonte ne termine pas tous les jalons demandés pour BAC DOMINION : nouveaux combats en direct, RPG avec déplacements et PNJ, niveaux 20–30, bâtiments supplémentaires indépendants, autres mini-jeux et tests de charge restent à développer. Les 127 questions de cours et 18 de méthode ne couvrent pas toute l’année ; les nouveaux contenus restent à relire et l’applicabilité officielle 2027 n’est pas certifiée. La répétition espacée complète et la correction des réponses rédigées restent à construire.

Les instructions Docker/Caddy pour un VPS et la structure des données figurent dans `README-v04.md`. Aucun VPS n’a été déployé durant cette refonte.
