> **Guide actuel : [README-REFONTE.md](README-REFONTE.md).** Les descriptions visuelles et mesures ci-dessous documentent la première tranche, avant sa refonte cartoon.

# BAC DOMINION — première tranche jouable v0.4

Cette livraison ajoute un royaume interactif, un duel de cartes animé et une course solo à la v0.3.1. **La v0.4 complète et les jalons suivants ne sont pas terminés.** Le backend, les comptes et l’économie existants restent utilisés. Le dépôt initial ne contenait que `BAC_DOMINION_v0.3.1.zip` ; ses sources ont été extraites dans `bac-dominion/`, et l’archive originale est conservée.

## Lancer sous Windows PowerShell

Prérequis : Python 3.10 ou plus récent et un navigateur moderne prenant en charge Canvas 2D. Python 3.12 a été utilisé pour les vérifications cloud. Les commandes PowerShell ci-dessous sont fournies pour Windows ; elles n’ont pas été exécutées sur une machine Windows dans cette session.

Après extraction de la livraison, ouvre PowerShell dans le dossier qui contient `bac-dominion`, puis :

```powershell
cd .\bac-dominion
py -3 -m venv .venv
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt
& .\.venv\Scripts\python.exe -m uvicorn app:app --host 0.0.0.0 --port 8000 --workers 1
```

Ouvre `http://localhost:8000` sur ton PC. L’accueil propose les nouvelles scènes. « Comptes et modes classiques » ouvre `/classic`, où l’inscription et la connexion existantes sont conservées. Après connexion, utilise « Entrer dans Luméria ». Les deux interfaces partagent le même cookie et les mêmes ressources. Phaser est inclus localement : aucun CDN n’est requis pour les nouvelles scènes.

Pour tester sur un téléphone du même Wi-Fi, utilise l’adresse IP locale du PC et le port 8000 ; autorise le serveur dans le pare-feu Windows pour ce réseau. Le royaume accepte le toucher et le glissement. Les boutons + et − permettent de zoomer.

Garde **un seul worker** : les salons WebSocket classiques sont encore en mémoire.

## Réutiliser une sauvegarde existante

Arrête l’ancien serveur avant de remplacer ses fichiers. Conserve le fichier SQLite utilisé précédemment et la valeur éventuelle de `BAC_DB_PATH`. Le chemin par défaut reste `bac_dominion.db` à côté de `app.py` ; lancer le jeu dans un autre dossier avec une autre base ne retrouve pas automatiquement une ancienne sauvegarde.

Avant le premier lancement de cette version, tu peux effectuer une sauvegarde SQLite cohérente :

```powershell
# Dans le dossier contenant la base existante, après création de .venv :
if (Test-Path .\bac_dominion.db) {
    & .\.venv\Scripts\python.exe -c "import sqlite3; src=sqlite3.connect('bac_dominion.db'); dst=sqlite3.connect('bac_dominion.before-v04.db'); src.backup(dst); dst.close(); src.close()"
}
# Si la base est ailleurs, indique son vrai chemin, sans créer une nouvelle base vide :
# $env:BAC_DB_PATH = 'C:\chemin\vers\bac_dominion.db'
```

Les quatre nouvelles tables sont additives : `play_profiles`, `play_runs`, `play_mastery`, `play_daily`. Les comptes, mots de passe hachés, scores, prestige, ressources, armées, missions, raids et territoires de la v0.3.1 ne sont pas supprimés. L’initialisation est répétable. Un test crée réellement une sauvegarde avec le code archivé v0.3.1, puis vérifie la connexion, les ressources, les bâtiments et l’armée avec le nouveau code.

## Ce qui est réellement jouable

| Parcours | Fonctionnement livré |
| --- | --- |
| Royaume | Carte pseudo-isométrique Phaser, caméra déplaçable, zoom, sélection des six bâtiments existants, déplacement sur cases libres et sauvegarde des positions. |
| Construction | Une annexe de mine, scierie ou carrière peut être construite par type. Coût serveur : 60 or, 40 bois, 20 pierre. L’annexe augmente d’un niveau le producteur correspondant et donc sa production existante ; elle n’a pas encore un niveau indépendant. Collision de case, doublons, coordonnées et ressources sont contrôlés côté serveur. |
| Améliorations | Les améliorations existantes sont accessibles depuis la scène. La limite actuelle reste 10 niveaux. Les variations procédurales de couleur, de forme et de détails sont provisoires. |
| Avatar | Couleur, trois coiffures et cape, enregistrées dans le compte et réutilisées dans les trois scènes. |
| Arène solo | Duel contre un opposant à ripostes déterministes : six cartes, énergie, préparation, attaque, soin, bouclier et deux emplacements de griffons. Les créatures infligent des dégâts à chaque tour. Choisir une carte verrouille l’action avant de montrer la question. Une mauvaise réponse dépense son coût sans activer l’effet. Projectiles, invocations et dégâts sont animés. |
| Course solo | Jusqu’à six obstacles selon le filtre disponible. Une bonne réponse déclenche un saut et un gain de distance ; une erreur déclenche une chute cartoon et un ralentissement. Un rival progresse selon des règles serveur fixes. |
| Révisions | Sélection sans quitter la scène : matière, thème, chapitre, sous-chapitre, difficulté et filtre des erreurs des nouvelles scènes. La sélection s’applique à la prochaine partie. Six thèmes HGGSP et les dix-sept notions de philosophie sont présents dans le catalogue. Les thèmes sans questions sont indiqués comme incomplets. |
| Récompenses | Points scolaires/XP reliés à l’économie existante ; prime de ressources au premier parcours terminé d’un mode avec au moins une bonne réponse dans la journée UTC. Une partie à zéro bonne réponse ne donne pas de prime. Une question déjà réussie dans les nouvelles scènes ne rapporte plus de points/XP lors de répétitions ; ce mécanisme est volontairement simple en attendant la répétition espacée. |
| Reprise | Les nouvelles parties sont sauvegardées en SQLite, y compris la question mélangée et l’action choisie. Rechargement et reconnexion retrouvent la partie. Une réponse renvoyée après perte réseau ne crédite pas deux fois les gains. |
| Modes classiques | Missions, boss QCM, classements, armées, raids, visites et salons privés WebSocket restent accessibles dans `/classic`. Les nouvelles scènes de duel et de course ne sont pas encore synchronisées entre joueurs. |

Les dessins des nouvelles scènes et des cartes sont des ressources vectorielles/procédurales originales et provisoires. Les effets respectent `prefers-reduced-motion`. Les modes classiques conservent leurs anciennes illustrations.

## Architecture et dépendances entre systèmes

- `app.py` conserve l’authentification, les cookies, SQLite, les ressources, les multiplicateurs, les raids et les salons. `/` et `/play` servent le nouvel accueil, `/classic` conserve l’ancienne interface.
- `vertical.py` installe les nouvelles routes. `resolve()` décrit les règles de simulation sans dépendre du rendu. Les actions, dégâts et récompenses sont calculés sur le serveur ; le navigateur n’envoie que le choix de carte et de réponse, avec l’identifiant et l’étape de partie.
- `static/play.js` rend les scènes avec Phaser 3.90.0 en Canvas 2D, pour éviter une dépendance au support WebGL du terminal. Les animations représentent les événements renvoyés par le serveur. Le rendu n’attribue jamais de ressources.
- `study_bank.py` valide les questions JSON et adapte les questions historiques aux métadonnées communes. L’ordre des 61 questions historiques reste inchangé pour les sauvegardes qui stockent leurs indices.
- `study_catalog.py` expose le catalogue de révision et le statut des sources ; il distingue catalogue navigable, questions disponibles et validation pédagogique.
- `curriculum.py`, `questions.py` et `story.py` conservent leur contenu historique. La formule `min(6, 1.35 ** (n - 1))` et le bonus des spécialités sont réutilisés.

La construction dépend des ressources existantes ; les réponses alimentent les scores et les ressources ; l’avatar et les positions sont stockés dans `play_profiles` ; le duel et la course utilisent des instantanés de questions stockés dans `play_runs`. Il n’y a pas encore de service séparé de simulation ni de courtier de messages.

## Banque de questions et import

La banque comprend désormais **127 questions de cours** : 61 historiques et 66 nouvelles, plus les **18 questions de méthodologie** historiques. Les 66 nouvelles questions couvrent les huit matières prioritaires, avec des explications et des références. Elles ont le statut **`draft`** : validation de structure et tests de gameplay ne valent pas validation pédagogique. Les anciennes ont le statut `legacy_review`.

`data/questions/001-lumeria.json` sert aussi d’exemple complet. Chaque question porte un identifiant, une matière, un programme et une session, une hiérarchie, une notion, une difficulté, un type, un énoncé, quatre options distinctes, un index de réponse, une explication, une compétence, une référence et un statut. Les réponses rédigées ne sont pas encore prises en charge.

Pour ajouter un lot :

1. Crée un tableau JSON au même format, avec de nouveaux identifiants et des questions distinctes.
2. Valide-le avant son installation :

```powershell
& .\.venv\Scripts\python.exe study_bank.py .\nouveau-lot.json
```

3. Copie-le dans `data/questions/` avec un nom trié **après** les lots existants, par exemple `002-nouveau-lot.json`, puis redémarre le serveur. Aucune modification du moteur n’est nécessaire. Un schéma invalide ou un doublon d’identifiant/d’énoncé fait échouer le chargement avec une erreur explicite.

Ne renomme, ne réordonne et ne supprime pas les lots/questions déjà chargés tant que des missions classiques sont actives : ces anciens parcours utilisent encore des indices. Les nouvelles scènes stockent des instantanés complets et supportent les ajouts sans modifier une partie engagée. La détection des variantes quasi identiques nécessite encore une revue humaine.

### Programmes officiels 2027

La couverture annuelle exhaustive n’est pas livrée. Des notions historiques peuvent relever de prérequis ; le catalogue reste un plan de travail à relire. Les axes/chapitres des questions sont des regroupements pédagogiques et ne sont pas tous des intitulés officiels.

La consultation de `https://www.education.gouv.fr/bo/2026/Special4/MENE2622655N` a reçu un refus du proxy cloud (HTTP 403). Les domaines `education.gouv.fr`, `www.education.gouv.fr` et `eduscol.education.gouv.fr` sont demandés dans le brouillon de configuration. La liste des thèmes 2, 4, 5 et 6 évaluables à l’écrit HGGSP 2027 est conservée comme information fournie par la demande, avec `hggsp_written_2027_verified: false`. Elle n’est pas annoncée comme vérifiée. Une revue des sources officielles et des contenus reste nécessaire.

## Tests exécutés et reproduction

Dans le dossier `bac-dominion`, sous PowerShell :

```powershell
& .\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
& .\.venv\Scripts\python.exe -m pytest -q
```

Résultat cloud : **26 tests réussis**, dont les 9 tests historiques. Les nouveaux contrôlent la migration réelle v0.3.1, la connexion et la sauvegarde, les coûts et collisions de construction, les cartes et dégâts, le verrouillage d’action, les refus d’action invalide, les filtres, les métadonnées, la reprise et les récompenses sans doublon. Un avertissement de dépréciation du client de test Starlette/httpx subsiste ; il n’a pas fait échouer les tests.

`tests/browser.cjs` a exécuté deux parcours Chromium : ordinateur 1280 × 900 et mobile tactile 390 × 844. Dans les deux cas : inscription par l’interface, personnalisation, construction, déplacement d’annexe, sauvegarde après rechargement, changement de matière, reprise de question, victoire au duel et fin de course avec une erreur volontaire. Aucun débordement horizontal ni erreur JavaScript d’exécution n’a été détecté sur ces parcours.

Pour reproduire ces tests navigateur, Node.js et Playwright sont facultatifs pour le développement Python. Lance d’abord un serveur **avec une base jetable** dans un premier PowerShell :

```powershell
$env:BAC_DB_PATH = Join-Path $env:TEMP 'bac-dominion-browser-test.db'
& .\.venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port 8001 --workers 1
```

Puis dans un second PowerShell, dans `bac-dominion` :

```powershell
npm install --prefix .browser-tools --no-audit --no-fund playwright
$env:PLAYWRIGHT_MODULE = Join-Path $PWD '.browser-tools\node_modules\playwright'
$env:PYTHON_BIN = Join-Path $PWD '.venv\Scripts\python.exe'
# Remplace ce chemin si Chrome est installé ailleurs :
$env:CHROMIUM_PATH = 'C:\Program Files\Google\Chrome\Application\chrome.exe'
$env:BAC_BASE_URL = 'http://127.0.0.1:8001'
$env:BAC_SCREENSHOTS = Join-Path $env:TEMP 'bac-browser-captures'
node tests\browser.cjs
```

Sous Linux cloud, le même scénario utilise `/usr/bin/chromium`, le Python du venv et le module Playwright installé séparément. Les captures de test sont hors du dépôt. Les tests ne couvrent pas Safari/iOS réel, les performances sur téléphone physique, un déploiement Docker/VPS ou 60 joueurs simultanés.

## Environnement cloud réutilisable

Le checkout courant est `/workspace/jeu-revisions`, le code exécutable dans `bac-dominion`, et le venv cloud dans `/workspace/jeu-revisions/.venv`.

```bash
bash /workspace/jeu-revisions/bac-dominion/tools/setup-cloud.sh
bash /workspace/jeu-revisions/bac-dominion/tools/start-cloud.sh
```

Le script d’installation prépare les dépendances et valide le lot JSON. Le script de démarrage conserve un seul worker ; `BAC_PORT` permet de choisir un port différent pour un contrôle isolé. Aucune clé API ou base externe n’est nécessaire. Réutilise le checkout isolé existant : ne crée pas de worktree sans demande explicite.

Les fichiers et dépendances peuvent être retenus dans l’instantané publié ; les processus doivent être redémarrés dans une nouvelle tâche. La sauvegarde du brouillon ne publie pas cet instantané. Les nouveaux fichiers doivent être conservés dans l’instantané ou intégrés au dépôt : le commit Git initial contient uniquement l’archive v0.3.1.

## VPS économique, plus tard

Le chemin Docker/Caddy existant est conservé. Une petite machine Linux avec Docker Compose, un volume persistant et un nom de domaine peut accueillir la bêta à un seul worker ; la capacité réelle reste à mesurer.

```bash
cd bac-dominion
cp .env.example .env
# Éditer BAC_DOMAIN dans .env, configurer le DNS et les ports 80/443.
docker compose -f compose.production.yaml up -d --build
```

Les sauvegardes existantes doivent être transférées explicitement dans le volume SQLite utilisé par le serveur. Avant une ouverture publique : tester les restaurations, la charge, les contrôles d’abus et les obligations de protection des données. Aucun VPS n’a été créé ni déployé pendant cette tâche.

## Fichiers de cette tranche

- Modifiés après extraction : `app.py`, `static/app.js`, `static/sw.js`, `README.md`, `.gitignore`, `.dockerignore`.
- Nouveaux : `vertical.py`, `study_bank.py`, `study_catalog.py`, `data/questions/001-lumeria.json`, `static/play.html`, `static/play.css`, `static/play.js`, `static/vendor/`, `requirements-dev.txt`, `tools/setup-cloud.sh`, `tools/start-cloud.sh`, `tests/test_vertical.py`, `tests/test_study_bank.py`, `tests/test_migration.py`, `tests/browser.cjs`, ce guide.
- À la racine du checkout : `.gitignore` ignore le venv et les outils locaux. Les sources extraites sont de nouveaux fichiers du point de vue Git ; aucune publication ni aucun commit n’a été effectué automatiquement.

## Suite du développement

Restent notamment : tutoriel complet, personnalisation détaillée des avatars, placement tactique manuel des créatures, nouveaux duels en direct, raids animés sur carte, niveaux 20–30 et six évolutions visuelles, bâtiments indépendants et supplémentaires, nouveaux mini-jeux synchronisés, RPG avec déplacements/PNJ, import pédagogique à grande échelle, répétition espacée et sélection de plusieurs chapitres, correction de rédaction avec critères explicites, classements spécialisés et tests de charge 10/20/40/60 joueurs.

L’anti-répétition et l’idempotence renforcés de cette tranche concernent les nouvelles scènes ; les anciennes routes conservent leur fonctionnement et devront être harmonisées lors des prochains jalons.
