"""Validated, append-only JSON bank with legacy API compatibility.

Question order in the original bank must never change: legacy saved runs store indices.
New runs in vertical.py store full shuffled snapshots and stable identifiers.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

ROOT = Path(__file__).resolve().parent

class StudyQuestion(BaseModel):
    model_config = ConfigDict(extra='forbid')
    id: str = Field(pattern=r'^[a-z0-9][a-z0-9_-]{2,100}$')
    subject: str = Field(min_length=1)
    program: str = Field(min_length=1)
    session: int = Field(ge=2020, le=2100)
    theme: str = Field(min_length=1)
    chapter: str = Field(min_length=1)
    subchapter: str = Field(min_length=1)
    concept: str = Field(min_length=1)
    difficulty: int = Field(ge=1, le=5)
    kind: Literal['definition','chronology','recall','understanding','application','reasoning','method']
    prompt: str = Field(min_length=10)
    options: list[str] = Field(min_length=4, max_length=4)
    correct: int = Field(ge=0, le=3)
    explanation: str = Field(min_length=15)
    skill: str = Field(min_length=1)
    reference: str = Field(min_length=1)
    validation: Literal['legacy_review','draft','reviewed']

    @model_validator(mode='after')
    def distinct_options(self):
        if len({s.strip().casefold() for s in self.options}) != 4 or any(not s.strip() for s in self.options):
            raise ValueError('Four distinct, non-empty options are required')
        return self

    def legacy(self):
        return {**self.model_dump(), 'category':self.subject, 'axis':self.chapter,
                'subaxis':self.subchapter, 'q':self.prompt}


def legacy_metadata(q):
    return StudyQuestion(
        id='legacy-'+hashlib.sha256(q['q'].encode()).hexdigest()[:16],
        subject=q['category'], program='Banque historique v0.3.1 — niveau à relire', session=2027,
        theme=q['theme'], chapter=q['axis'], subchapter=q['subaxis'], concept=q['subaxis'],
        difficulty=2, kind='recall', prompt=q['q'], options=q['options'], correct=q['correct'],
        explanation=q['explanation'], skill='Mobiliser une connaissance',
        reference='BAC DOMINION v0.3.1 — référence pédagogique à compléter',validation='legacy_review').legacy()


def load_file(path):
    rows=json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(rows,list):
        raise ValueError('The bank must be a JSON array')
    return [StudyQuestion.model_validate(row) for row in rows]


def append_banks(legacy, directory=ROOT/'data'/'questions'):
    ids={q['id'] for q in legacy}
    prompts={q['q'].strip().casefold() for q in legacy}
    added=[]
    for path in sorted(Path(directory).glob('*.json')):
        for question in load_file(path):
            if question.id in ids or question.prompt.strip().casefold() in prompts:
                raise ValueError(f'Duplicate question in {path.name}: {question.id}')
            ids.add(question.id)
            prompts.add(question.prompt.strip().casefold())
            added.append(question.legacy())
    return legacy+added


def main():
    parser=argparse.ArgumentParser(description='Validate question JSON; importing is an explicit file copy into data/questions.')
    parser.add_argument('path',type=Path)
    args=parser.parse_args()
    questions=load_file(args.path)
    ids=[q.id for q in questions]
    prompts=[q.prompt.strip().casefold() for q in questions]
    if len(set(ids)) != len(ids) or len(set(prompts)) != len(prompts):
        raise ValueError('Duplicate ID or prompt')
    print(f'{len(questions)} questions: schema valid; pedagogical validation remains independent.')

if __name__=='__main__':
    main()
