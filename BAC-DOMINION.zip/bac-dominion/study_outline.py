"""Stable display paths. Legacy prompts, IDs and their indices remain unchanged."""
from study_catalog import THEMES

HGGSP_AXES = [
 ['Axe 1 · Conquêtes, affirmations de puissance et rivalités','Axe 2 · Enjeux diplomatiques et coopérations','Objet conclusif · La Chine, à la conquête de l’espace, des mers et des océans'],
 ['Axe 1 · Dimension politique de la guerre','Axe 2 · Construire la paix','Objet conclusif · Le Moyen-Orient : conflits et tentatives de paix'],
 ['Axe 1 · Histoire et mémoires des conflits','Axe 2 · Histoire, mémoire et justice','Objet conclusif · Le génocide des Juifs et des Tsiganes'],
 ['Axe 1 · Usages sociaux et politiques du patrimoine','Axe 2 · Patrimoine, préservation et tensions','Objet conclusif · La France et le patrimoine'],
 ['Axe 1 · Exploiter, préserver et protéger','Axe 2 · Le changement climatique : approches historique et géopolitique','Objet conclusif · Les États-Unis et l’environnement'],
 ['Axe 1 · Produire et diffuser des connaissances','Axe 2 · La connaissance, enjeu politique et géopolitique','Objet conclusif · Le cyberespace'],
]
SVT_AXES = [
 ['Brassage génétique','Transferts génétiques','Évolution des populations'],
 ['Datation des événements','Dynamique lithosphérique'],
 ['Organisation des plantes','Échanges et nutrition','Reproduction des plantes','Domestication des plantes'],
 ['Indices climatiques','Rétroactions climatiques'],
 ['Communication nerveuse'],
 ['Contraction','Métabolisme'],
 ['Réponse au stress'],
]
CHAPTERS = []
for theme, axes in zip(THEMES['HGGSP'], HGGSP_AXES):
    CHAPTERS += [('HGGSP', theme, axis) for axis in axes]
for theme, axes in zip(THEMES['SVT'], SVT_AXES):
    CHAPTERS += [('SVT', theme, axis) for axis in axes]
CHAPTERS += [('Philosophie', theme, 'Notion et repères') for theme in THEMES['Philosophie']]
CHAPTERS += [('Histoire-géographie', theme, 'Repères et études de cas') for theme in THEMES['Histoire-géographie']]
CHAPTERS += [('Histoire-géographie','Repères historiques','Première Guerre mondiale')]
CHAPTERS += [('Enseignement scientifique',theme,'Connaissances et applications') for theme in THEMES['Enseignement scientifique']]
for subject in ('Anglais','Espagnol'):
    CHAPTERS += [(subject,theme,'Langue et culture') for theme in THEMES[subject]]
CHAPTERS += [('EMC','La démocratie','Démocratie et citoyenneté')]
CHAPTERS += [('HGGSP','Méthode du bac','Étude critique de documents'),('Philosophie','Méthode du bac','Dissertation')]
CHAPTERS += [
 ('Maths','Analyse','Dérivation'),('Maths','Analyse','Logarithme'),('Maths','Suites','Suites géométriques'),
 ('Physique-chimie','Mouvement','Dynamique'),('Physique-chimie','Chimie','Acide-base'),('Physique-chimie','Ondes','Lumière'),
 ('SES','Économie','Croissance'),('SES','Économie','Défaillances du marché'),('SES','Économie','Politique économique'),
 ('HLP','Argumentation','Construire une thèse'),('HLP','Littérature','Figures de style'),('HLP','Humanisme','Renaissance'),
 ('NSI','Structures de données','Structures linéaires'),('NSI','Bases de données','Modèle relationnel'),('NSI','Algorithmique','Complexité'),
]


def canonical_path(subject, theme, axis):
    if (subject,theme,axis) in CHAPTERS:
        return theme,axis
    if subject == 'Philosophie' and theme != 'Méthode du bac':
        return theme,'Notion et repères'
    if subject in ('Anglais','Espagnol'):
        if theme in ('Territory and Memory','Territorio y memoria'):
            theme='Territoire et mémoire'
        return theme,'Langue et culture'
    if subject == 'EMC':
        return 'La démocratie','Démocratie et citoyenneté'
    if subject == 'Enseignement scientifique':
        theme = {'Climat':'Science, climat et société','Énergie et électricité':'Le futur des énergies','Ondes':'Le futur des énergies'}.get(theme,theme)
        return theme,'Connaissances et applications'
    if subject == 'Histoire-géographie':
        theme = {'Crises économiques et politiques':THEMES[subject][0], 'Les guerres mondiales':'Repères historiques','Géographie':THEMES[subject][5]}.get(theme,theme)
        return theme, 'Première Guerre mondiale' if theme == 'Repères historiques' else 'Repères et études de cas'
    if subject == 'HGGSP' and theme in THEMES[subject]:
        n=THEMES[subject].index(theme)
        if n == 0: a=0 if axis == 'Espace extra-atmosphérique' else 1
        elif n == 2: a=1 if axis == 'Justice et mémoire' else 0
        elif n == 3: a=1 if axis == 'Protection du patrimoine' else 0
        elif n == 4: a=1 if axis == 'Gouvernance environnementale' else 0
        elif n == 5: a=1 if axis == 'Connaissance et pouvoir' else 0
        else: return theme,axis
        return theme,HGGSP_AXES[n][a]
    return theme,axis


def canonical_focus(focus):
    focus = {k:focus.get(k,'') for k in ('subject','theme','axis','subaxis')}
    if focus['theme']:
        theme,axis=canonical_path(focus['subject'],focus['theme'],focus['axis'])
        focus['theme']=theme
        if focus['axis']: focus['axis']=axis
    return focus


def normalize_questions(questions):
    for q in questions:
        q['theme'],q['axis']=canonical_path(q['category'],q['theme'],q['axis'])
    return questions
