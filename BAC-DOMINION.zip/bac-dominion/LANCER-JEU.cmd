@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo  LUMERIA - BAC DOMINION
echo  Ton royaume se prepare...
echo.
if exist ".venv\Scripts\python.exe" goto PRET
where py >nul 2>nul
if not errorlevel 1 (
  set "BAC_LAUNCH_PY=py -3"
  goto PYTHON_TROUVE
)
where python >nul 2>nul
if not errorlevel 1 (
  set "BAC_LAUNCH_PY=python"
  goto PYTHON_TROUVE
)
echo Installe Python 3.10 ou plus recent depuis python.org, puis relance ce fichier.
pause
exit /b 1
:PYTHON_TROUVE
%BAC_LAUNCH_PY% -c "import sys; sys.exit(not (sys.version_info >= (3,10)))"
if errorlevel 1 goto PYTHON_TROP_ANCIEN
%BAC_LAUNCH_PY% -m venv .venv
if errorlevel 1 goto ECHEC
:PRET
".venv\Scripts\python.exe" -c "import sys; sys.exit(not (sys.version_info >= (3,10)))"
if errorlevel 1 goto PYTHON_TROP_ANCIEN
".venv\Scripts\python.exe" -c "import importlib.util,sys; sys.exit(not all(importlib.util.find_spec(m) for m in ('fastapi','uvicorn')))"
if not errorlevel 1 goto LANCER
echo Premiere installation : une connexion Internet est necessaire.
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto ECHEC
:LANCER
".venv\Scripts\python.exe" tools\start_local.py
if errorlevel 1 goto ECHEC
exit /b 0
:PYTHON_TROP_ANCIEN
echo Python 3.10 ou plus recent est necessaire. Installe une version recente depuis python.org.
pause
exit /b 1
:ECHEC
echo.
echo Le demarrage a rencontre un probleme. Copie le message affiche ci-dessus pour obtenir de l'aide.
pause
exit /b 1
