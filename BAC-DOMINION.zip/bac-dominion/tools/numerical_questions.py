"""Explicit numerical exercise families with exact independent calculations."""
import math


def exercises():
    out={key:[] for key in ('x0','x1','x2','x3','x4','x5','x12','x14')}
    def add(key,concept,prompt,answer,wrong,explanation):
        options=list(dict.fromkeys([str(answer),*[str(w) for w in wrong]]))
        if len(options)<4 and isinstance(answer,(int,float)):
            for offset in (1,-1,2,-2,3,-3):
                candidate=str(answer+offset)
                if candidate not in options: options.append(candidate)
                if len(options)==4: break
        assert len(options)>=4,(key,prompt,options)
        out[key].append((concept,prompt,options[:4],explanation))
    for n in range(1,11):
        a=n+1
        add('x0','Dérivée d’une puissance',f'Quelle est la dérivée de f(x) = {a}x^{a} ?',f'{a*a}x^{a-1}',[f'{a}x^{a-1}',f'{a*a}x^{a}',f'{a-1}x^{a-1}'],f'La règle (ax^p)′ = apx^(p−1) donne {a*a}x^{a-1}.')
        add('x0','Dérivée polynomiale',f'Pour f(x) = {a}x² + {n}x + 7, que vaut f′(1) ?',2*a+n,[a+n,2*a+n+7,2*a],f'f′(x) = {2*a}x + {n}, donc f′(1) = {2*a+n}.')
        add('x0','Exponentielle composée',f'Quelle est la dérivée de f(x) = exp({a}x) ?',f'{a}exp({a}x)',[f'exp({a}x)',f'{a*a}exp({a}x)',f'{a}exp(x)'],f'La dérivation de exp(u) donne u′exp(u), avec u′ = {a}.')
        add('x0','Dérivée du logarithme',f'Sur x > 0, si f(x) = {a}ln(x), que vaut f′(2) ?',f'{a}/2',[f'{2*a}',f'1/{a}',f'{a}/4'],f'f′(x) = {a}/x ; à x = 2, cela donne {a}/2.')
        add('x0','Dérivée d’un produit',f'Pour f(x) = x(x + {a}), que vaut f′(3) ?',6+a,[3+a,6,6+2*a],f'f(x) = x² + {a}x, donc f′(3) = 2×3 + {a} = {6+a}.')
        add('x1','Logarithme et exponentielle',f'Quelle est la valeur exacte de ln(exp({a})) ?',a,[a+1,2*a,-a],f'ln(exp(t)) = t, donc le résultat est {a}.')
        add('x1','Logarithme d’un produit',f'Si ln(a) = {n} et ln(b) = 2, combien vaut ln(ab) ?',n+2,[n-2,2*n+3,n+3],f'Pour a et b positifs, ln(ab) = ln(a) + ln(b) = {n+2}.')
        add('x1','Logarithme d’un quotient',f'Si ln(a) = {n+4} et ln(b) = 3, que vaut ln(a/b) ?',n+1,[n+7,3*(n+4),-(n+1)],f'ln(a/b) = ln(a) − ln(b) = {n+4} − 3 = {n+1}.')
        add('x1','Équation logarithmique',f'Sur x > 0, résoudre ln(x) = {a}.',f'x = exp({a})',[f'x = {a}',f'x = ln({a})',f'x = exp(-{a})'],f'La fonction exponentielle est réciproque du logarithme : x = exp({a}).')
        add('x1','Puissance et logarithme',f'Pour x > 0 et ln(x) = 2, que vaut ln(x^{a}) ?',2*a,[a,a+2,-2*a],f'ln(x^p) = p ln(x), soit {a}×2 = {2*a}.')
        add('x2','Terme géométrique',f'Une suite vérifie u₀ = {a} et u(k+1) = 2u(k). Que vaut u₄ ?',a*16,[a*8,a+8,a*32],f'u₄ = u₀ × 2⁴ = {a*16}.')
        add('x2','Raison géométrique',f'Deux termes consécutifs non nuls sont u₅ = {a} et u₆ = {a*(a+1)}. Quelle est la raison ?',a+1,[a,a+2,-(a+1)],f'La raison vaut u₆/u₅ = {a*(a+1)}/{a} = {a+1}.')
        add('x2','Somme géométrique',f'Pour u₀ = {a} et une raison 2, combien vaut u₀ + u₁ + u₂ ?',7*a,[3*a,6*a,8*a],f'La somme vaut {a}(1 + 2 + 4) = {7*a}.')
        add('x2','Suite décroissante',f'Une suite géométrique a u₀ = {8*a} et une raison 1/2. Que vaut u₃ ?',a,[2*a,4*a,8*a],f'u₃ = {8*a} × (1/2)³ = {a}.')
        add('x2','Récurrence géométrique',f'Une suite géométrique de raison −2 vérifie u₃ = {a}. Que vaut u₅ ?',4*a,[-4*a,2*a,-2*a],f'Deux passages multiplient par (−2)² = 4 : u₅ = {4*a}.')
        add('x3','Deuxième loi de Newton',f'Une masse constante de {a} kg subit une résultante de {3*a} N. Quelle est la norme de son accélération ?', '3 m/s²',['1 m/s²',f'{3*a} m/s²','0 m/s²'],f'ΣF = ma, donc a = {3*a}/{a} = 3 m/s², dans la direction de la résultante.')
        add('x3','Résultante colinéaire',f'Deux forces opposées de {5*a} N et {2*a} N agissent sur un objet. Quelle est la norme de la résultante ?',f'{3*a} N',[f'{7*a} N',f'{2*a} N','0 N'],f'Les forces opposées se soustraient : {5*a} − {2*a} = {3*a} N.')
        add('x3','Poids',f'Avec g = 10 N/kg, quel est le poids d’une masse de {a} kg ?',f'{10*a} N',[f'{a} N',f'{a+10} N',f'{100*a} N'],f'P = mg = {a}×10 = {10*a} N.')
        add('x3','Accélération moyenne',f'Une vitesse rectiligne passe de {a} à {a+12} m/s en 4 s. Quelle est l’accélération moyenne ?', '3 m/s²',['4 m/s²','12 m/s²','48 m/s²'],f'Δv/Δt = ({a+12} − {a})/4 = 3 m/s².')
        add('x3','Mouvement uniforme',f'Un objet se déplace en ligne droite à vitesse constante {a} m/s dans un référentiel galiléen. Quelle est la résultante des forces ?', 'Nulle',[f'{a} N','Nécessairement dans le sens du mouvement','Nécessairement opposée au mouvement'],f'Vecteur vitesse constant implique accélération nulle, donc résultante nulle, même à {a} m/s.')
        add('x4','Calcul du pH',f'À 25 °C dans le modèle dilué, [H₃O⁺] = 10^(-{n}) mol/L. Quel pH donne −log₁₀[H₃O⁺] ?',n,[-n,n+1,n+2],f'pH = −log₁₀(10^(-{n})) = {n}. Il s’agit du calcul à partir de la concentration indiquée.')
        ph=round(.5+n/10,1)
        add('x4','Dilution et pH',f'Une solution d’acide fort de pH {ph} est diluée cent fois, dans le modèle dilué où l’eau reste négligeable. Quel est le nouveau pH ?',round(ph+2,1),[round(ph+1,1),round(ph-2,1),round(ph+3,1)],f'La concentration est divisée par 100, donc le pH augmente de log₁₀(100) = 2 : {round(ph+2,1)}.')
        add('x4','Quantité de matière',f'Une solution a c = {a} mmol/L et V = 2 L. Quelle quantité de soluté contient-elle ?',f'{2*a} mmol',[f'{a} mmol',f'{3*a+1} mmol',f'{4*a} mmol'],f'n = cV = {a}×2 = {2*a} mmol.')
        add('x4','Neutralisation stœchiométrique',f'On mélange {3*a} mmol de H₃O⁺ et {a} mmol de HO⁻. Combien de mmol de H₃O⁺ restent après réaction complète 1:1 ?',2*a,[a,3*a,4*a],f'H₃O⁺ + HO⁻ → 2H₂O. Il reste {3*a} − {a} = {2*a} mmol de H₃O⁺.')
        pka=round(3+n/10,1)
        add('x4','Rapport base-acide',f'Un couple HA/A⁻ a un pKa de {pka}. Pour [A⁻]/[HA] = 10, que donne pH = pKa + log₁₀([A⁻]/[HA]) ?',round(pka+1,1),[round(pka-1,1),pka,round(pka+2,1)],f'log₁₀(10) = 1, donc pH = {pka} + 1 = {round(pka+1,1)} dans les conditions de validité de cette relation.')
        add('x5','Trajet de la lumière',f'Dans le vide, avec c = 3,0×10⁸ m/s, quelle distance parcourt la lumière en {n} ns ?',f'{3*n}/10 m',[f'{3*n} m',f'{30*n} m',f'{n}/10 m'],f'd = cΔt = 3,0×10⁸×{n}×10⁻⁹ = {3*n}/10 m.')
        add('x5','Indice optique',f'La lumière se propage dans un milieu à c/{a}. Quel est l’indice n = c/v ?',a,[a+1,2*a,a+2],f'n = c/(c/{a}) = {a}. La valeur est calculée dans le milieu hypothétique décrit.')
        add('x5','Fréquence et période',f'Une onde a une fréquence de {a} Hz. Quelle est sa période ?',f'1/{a} s',[f'{a} s',f'{2*a} s',f'1/{2*a} s'],f'T = 1/f = 1/{a} s.')
        add('x5','Longueur d’onde',f'Une onde de célérité {12*a} m/s a une fréquence de {a} Hz. Quelle est sa longueur d’onde ?', '12 m',['6 m','24 m',f'{12*a+1} m'],f'λ = v/f = {12*a}/{a} = 12 m.')
        add('x5','Énergie du photon',f'Un photon a une fréquence {a}f₀. Si E₀ = hf₀, quelle est son énergie ?',f'{a}E₀',[f'E₀/{a}',f'{a*a}E₀','E₀'],f'E = hf ; la fréquence multipliée par {a} multiplie l’énergie par {a}.')
        stack=[n,n+1,n+2]
        add('x12','Pile LIFO',f'Une pile vide reçoit, dans cet ordre, {stack}. Quelle valeur retire le premier dépilement ?',n+2,[n,n+1,n+3],f'Le dernier élément entré est retiré : {n+2}.')
        add('x12','File FIFO',f'Une file vide reçoit, dans cet ordre, {stack}. Quelle valeur retire le premier défilement ?',n,[n+1,n+2,n+3],f'Le premier élément entré est retiré : {n}.')
        add('x12','Indice de liste',f'En Python, pour L = [{n}, {n+3}, {n+8}, {n+12}], que vaut L[2] ?',n+8,[n,n+3,n+12],f'Les indices commencent à 0 ; L[2] est le troisième élément, {n+8}.')
        add('x12','Longueur de liste',f'Une liste contient {n+5} éléments. On effectue append(0), puis pop(), puis append(1). Quelle est sa longueur finale ?',n+6,[n+4,n+5,n+7],f'Les variations sont +1, −1, +1 ; le total passe de {n+5} à {n+6}.')
        add('x12','Sommet de pile',f'Une pile vide reçoit {n}, puis {n+4}. On dépile une fois, puis on empile {n+9}. Quelle valeur est au sommet ?',n+9,[n,n+4,n+8],f'Après retrait de {n+4}, il reste {n}. Le nouvel élément {n+9} devient le sommet.')
        size=2**n-1
        add('x14','Recherche dichotomique',f'Une recherche dichotomique équilibrée porte sur {size} valeurs triées. Combien de valeurs peut-elle examiner au maximum ?',n,[n+1,n+2,n+3],f'{size} = 2^{n} − 1 ; un arbre de recherche équilibré a {n} niveaux de comparaisons.')
        add('x14','Boucles imbriquées',f'Deux boucles parcourent chacune range({a}). Combien de fois leur instruction interne s’exécute-t-elle ?',a*a,[a,2*a,a*a+1],f'Chaque passage extérieur exécute {a} passages intérieurs : {a}² = {a*a}.')
        add('x14','Recherche linéaire',f'Une recherche linéaire vérifie une liste de {n+12} éléments. Si la cible est absente, combien d’éléments sont examinés ?',n+12,[n+11,n+13,2*(n+12)],f'Chaque élément doit être vérifié une fois ; cela fait {n+12} examens.')
        add('x14','Paires non ordonnées',f'Un algorithme traite une fois chaque paire d’indices i < j parmi {a} éléments. Combien de paires traite-t-il ?',a*(a-1)//2,[a*a,a*(a+1)//2,a*a+1],f'Le nombre de paires vaut n(n−1)/2 = {a}×{a-1}/2 = {a*(a-1)//2}.')
        count=2**n
        add('x14','Modèle n log n',f'Un modèle de coût est C(N) = N log₂(N). Pour N = {count}, quelle est la valeur exacte de C(N) ?',count*n,[count*(n+1),count*n+1,count*(n+2)],f'log₂({count}) = {n}, donc C = {count}×{n} = {count*n}.')
    assert all(len(v)==50 for v in out.values())
    return out
