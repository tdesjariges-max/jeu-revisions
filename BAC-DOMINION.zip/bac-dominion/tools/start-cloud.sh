#!/usr/bin/env bash
set -euo pipefail
REPOSITORY="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPOSITORY/bac-dominion"
exec ../.venv/bin/python -m uvicorn app:app --host 0.0.0.0 --port "${BAC_PORT:-8000}" --workers 1
