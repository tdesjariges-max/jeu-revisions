"""Start the installed game, open the browser only when HTTP is ready.

Uses only the standard library; the Windows launcher prepares the venv first.
Existing SQLite paths are inherited and never replaced.
"""
from pathlib import Path
import os
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parents[1]


def main():
    try:
        port = int(os.environ.get('BAC_PORT', '8000'))
        if not 1024 <= port <= 65535:
            raise ValueError
    except ValueError:
        print('BAC_PORT doit etre un nombre entre 1024 et 65535.', flush=True)
        return 1
    try:
        with socket.socket() as check:
            check.bind(('127.0.0.1', port))
    except OSError:
        print(f'Le port {port} est deja utilise. Ferme l’ancien serveur du jeu puis relance.', flush=True)
        return 1
    url = f'http://localhost:{port}'
    print('Demarrage de Lumeria... Garde cette fenetre ouverte pendant la partie.', flush=True)
    server = subprocess.Popen([sys.executable, '-m', 'uvicorn', 'app:app', '--host', '0.0.0.0', '--port', str(port), '--workers', '1'], cwd=ROOT)
    # This request is strictly local and must not be sent through an Internet proxy.
    local_http = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        deadline = time.monotonic() + 30
        while server.poll() is None and time.monotonic() < deadline:
            try:
                with local_http.open(url, timeout=1) as response:
                    if response.status == 200:
                        print(f'Le jeu est pret : {url}', flush=True)
                        if os.environ.get('BAC_NO_BROWSER') != '1':
                            webbrowser.open(url)
                        break
            except (OSError, urllib.error.URLError):
                time.sleep(.2)
        else:
            print('Le serveur n’a pas pu demarrer. Consulte le message ci-dessus.', flush=True)
            if server.poll() is None:
                server.terminate()
            return server.wait()
        return server.wait()
    except KeyboardInterrupt:
        if server.poll() is None:
            try:
                server.wait(timeout=3)
            except subprocess.TimeoutExpired:
                server.terminate()
                server.wait()
        return 0


if __name__ == '__main__':
    raise SystemExit(main())
