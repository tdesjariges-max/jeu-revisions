"""Compile authored concept/definition/application cards into playable QCMs.

Each chapter contains 25 distinct learning points and two different tasks each:
recognise a precise definition/repère, then transfer it to an authored example.
Distractors come from that same chapter. No network, AI or runtime generation.
The committed JSON is authoritative for play; this compiler is for editors only.
"""
import hashlib
import json
from pathlib import Path
import random
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from study_bank import StudyQuestion
from numerical_questions import exercises
from study_outline import CHAPTERS, HGGSP_AXES, SVT_AXES, THEMES
ROOT=Path(__file__).resolve().parents[1]
CODES={}
for n,(theme,axes) in enumerate(zip(THEMES['HGGSP'],HGGSP_AXES)):
    for a,axis in enumerate(axes): CODES[f'h{n}a{a}']=('HGGSP',theme,axis)
for n,(theme,axes) in enumerate(zip(THEMES['SVT'],SVT_AXES)):
    for a,axis in enumerate(axes): CODES[f's{n}a{a}']=('SVT',theme,axis)
for prefix,subject in [('p','Philosophie'),('g','Histoire-géographie'),('e','Enseignement scientifique'),('en','Anglais'),('es','Espagnol')]:
    for n,theme in enumerate(THEMES[subject]):
        CODES[f'{prefix}{n}']=next(c for c in CHAPTERS if c[:2]==(subject,theme))
CODES['g8']=('Histoire-géographie','Repères historiques','Première Guerre mondiale')
CODES['emc']=('EMC','La démocratie','Démocratie et citoyenneté')
CODES['mh']=('HGGSP','Méthode du bac','Étude critique de documents')
CODES['mp']=('Philosophie','Méthode du bac','Dissertation')
for n,c in enumerate(c for c in CHAPTERS if c[0] in ('Maths','Physique-chimie','SES','HLP','NSI')): CODES[f'x{n}']=c
REFS={
 'HGGSP':'https://eduscol.education.gouv.fr/1676/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g',
 'SVT':'https://eduscol.education.gouv.fr/1714/programmes-et-ressources-en-sciences-de-la-vie-et-de-la-terre-voie-g',
 'Philosophie':'https://eduscol.education.gouv.fr/1702/programmes-et-ressources-en-philosophie-voie-gt',
 'Histoire-géographie':'https://eduscol.education.gouv.fr/1667/programmes-et-ressources-en-histoire-geographie-voie-gt',
 'Enseignement scientifique':'https://eduscol.education.gouv.fr/1750/programmes-et-ressources-en-enseignement-scientifique-voie-g',
 'Anglais':'https://eduscol.education.gouv.fr/1726/programmes-et-ressources-en-langues-vivantes-voie-gt',
 'Espagnol':'https://eduscol.education.gouv.fr/1726/programmes-et-ressources-en-langues-vivantes-voie-gt',
 'EMC':'https://eduscol.education.gouv.fr/1681/programmes-et-ressources-en-enseignement-moral-et-civique-voie-gt',
}


def compile_cards():
    chapters={}
    for path in sorted((ROOT/'data/authoring').glob('*.tsv')):
        code=None
        for line in path.read_text().splitlines():
            if not line.strip() or line.startswith('#'): continue
            if line.startswith('@ '):
                code=line[2:].strip()
                if code not in CODES: raise ValueError((path,code))
                if code in chapters: raise ValueError('Repeated chapter '+code)
                chapters[code]=[]
                continue
            cols=[v.strip() for v in line.split('|')]
            if code is None or len(cols)!=3 or any(not v for v in cols): raise ValueError((path,line))
            chapters[code].append(cols)
    result=[]
    for code,cards in chapters.items():
        if len(cards)!=25: raise ValueError(f'{code}: {len(cards)} cards instead of 25')
        if len({v[0].casefold() for v in cards})!=len(cards): raise ValueError('Duplicate concept '+code)
        subject,theme,axis=CODES[code]
        for n,(term,definition,case) in enumerate(cards):
            for kind,text in [('definition',f'Quel repère ou quelle notion correspond à cette description : « {definition} » ?'),('application',f'Quel repère ou quelle notion correspond précisément au cas suivant ? {case}')]:
                if subject in ('Anglais','Espagnol'):
                    language = 'anglaise' if subject == 'Anglais' else 'espagnole'
                    text = f'Quelle expression {language} signifie « {definition} » ?' if kind == 'definition' else f'Quelle entrée de vocabulaire correspond au passage manquant ? Les choix sont donnés sous leur forme de dictionnaire. {case}'
                # Stable IDs and deterministic distractors, independent of Python hash order.
                qid=f'course-{code}-{n+1:02d}-{kind}'
                rng=random.Random(qid)
                alternatives=rng.sample([row[0] for row in cards if row[0]!=term],3)
                options=[term,*alternatives]
                rng.shuffle(options)
                row=dict(id=qid,subject=subject,program='Terminale générale — entraînement par chapitre',session=2027,
                    theme=theme,chapter=axis,subchapter='Lexique en contexte' if subject in ('Anglais','Espagnol') else 'Notions et applications',concept=term,difficulty=2 if kind=='definition' else 3,
                    kind=kind,prompt=text,options=options,correct=options.index(term),
                    explanation=f'{term} : {definition[0].lower()+definition[1:]}. Dans cet exercice : {case}',
                    skill='Identifier un repère ou une notion' if kind=='definition' else 'Appliquer une connaissance à un exemple',
                    reference=REFS.get(subject,'https://eduscol.education.gouv.fr/')+' — cadre de programme ; rédaction originale Luméria, relecture enseignante à effectuer',
                    validation='draft')
                result.append(StudyQuestion.model_validate(row).model_dump())
    for code,items in exercises().items():
        if code in chapters: raise ValueError('Numerical chapter duplicated '+code)
        chapters[code] = items
        subject,theme,axis = CODES[code]
        for n,(concept,prompt,options,explanation) in enumerate(items):
            qid=f'course-{code}-calc-{n+1:02d}'
            answer=options[0]
            random.Random(qid).shuffle(options)
            row=dict(id=qid,subject=subject,program='Terminale générale — entraînement par chapitre',session=2027,
                theme=theme,chapter=axis,subchapter=concept,concept=concept,difficulty=2 if n%2==0 else 3,
                kind='application',prompt=prompt,options=options,correct=options.index(answer),explanation=explanation,
                skill='Calculer et appliquer une relation',reference='https://eduscol.education.gouv.fr/ — cadre de programme ; exercices originaux Luméria, relecture enseignante à effectuer',validation='draft')
            result.append(StudyQuestion.model_validate(row).model_dump())
    # Shared concepts legitimately occur in different subjects. Disambiguate their
    # prompts by path, keeping question-text based old saves and mastery unambiguous.
    from questions import QUESTIONS as original
    used={q['q'].strip().casefold() for q in original}
    used.update(q.prompt.strip().casefold() for q in __import__('study_bank').load_file(ROOT/'data/questions/001-lumeria.json'))
    for row in result:
        prompt=row['prompt']
        if prompt.strip().casefold() in used:
            prompt += f" ({row['subject']} · {row['theme']} · {row['chapter']})"
        if prompt.strip().casefold() in used: raise ValueError('Duplicate prompt '+prompt)
        used.add(prompt.strip().casefold())
        row['prompt']=prompt
    output=ROOT/'data/questions/010-chapitres.json'
    if output.exists():
        old_ids=[q['id'] for q in json.loads(output.read_text())]
        by_id={q['id']:q for q in result}
        if any(qid not in by_id for qid in old_ids):
            raise ValueError('Removing published IDs would break saved index-based runs')
        previous=set(old_ids)
        result=[by_id[qid] for qid in old_ids]+[q for q in result if q['id'] not in previous]
    return result,chapters

if __name__=='__main__':
    rows,chapters=compile_cards()
    missing=set(CODES)-set(chapters)
    if missing: raise ValueError('Chapters missing: '+str(sorted(missing)))
    output=ROOT/'data/questions/010-chapitres.json'
    output.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    missing=set(CODES)-set(chapters)
    print(f'{len(rows)} questions / {len(chapters)} chapitres ; à écrire : {sorted(missing)}')
