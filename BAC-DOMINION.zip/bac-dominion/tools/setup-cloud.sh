#!/usr/bin/env bash
set -euo pipefail
REPOSITORY="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$REPOSITORY"
python3 -m venv .venv
.venv/bin/python -m pip install -r bac-dominion/requirements.txt -r bac-dominion/requirements-dev.txt
cd bac-dominion
../.venv/bin/python -m compileall -q app.py vertical.py study_bank.py study_catalog.py
../.venv/bin/python study_bank.py data/questions/001-lumeria.json
