"""v0.4 vertical slice: persistent state and authoritative solo simulation.

No in-memory sessions: a restart or a lost response can resume via GET /api/play.
Existing account/economy tables remain the source of truth.
"""
import json
import random
import secrets
import sqlite3
from typing import Literal

from fastapi import HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

CARDS = {
    'focus': {'name': 'Souffle de la clairière', 'cost': 0, 'text': 'Prépare ton énergie : +1 en plus de la régénération du tour', 'kind': 'prepare'},
    'spark': {'name': 'Éclat solaire', 'cost': 2, 'text': '18 dégâts à Nox', 'kind': 'attack'},
    'ward': {'name': 'Rempart de cristal', 'cost': 2, 'text': 'Absorbe 20 dégâts', 'kind': 'defense'},
    'griffin': {'name': 'Griffon des pages', 'cost': 3, 'text': 'Créature : 7 dégâts par tour, 2 places', 'kind': 'creature'},
    'heal': {'name': 'Source de mémoire', 'cost': 2, 'text': 'Récupère 18 PV', 'kind': 'heal'},
    'nova': {'name': 'Aurore', 'cost': 5, 'text': '35 dégâts, à préparer avec son énergie', 'kind': 'spell'},
}

class Avatar(BaseModel):
    color: Literal['teal', 'violet', 'gold'] = 'teal'
    hair: Literal['short', 'crest', 'long'] = 'short'
    cape: bool = True

class StudyPreferences(BaseModel):
    difficulty: int = Field(default=0, ge=0, le=5)
    weak_only: bool = False

class Placement(BaseModel):
    building: str
    x: int = Field(ge=0, le=11)
    y: int = Field(ge=0, le=9)
    construct_building: bool = Field(default=False, alias="construct")

class Start(BaseModel):
    mode: Literal['arena', 'race']

class Action(BaseModel):
    run_id: str
    step: int = Field(ge=0)
    card: str = 'spark'

class Answer(BaseModel):
    run_id: str
    step: int = Field(ge=0)
    choice: int = Field(ge=0, le=3)


def init_tables(db):
    db.execute('''CREATE TABLE IF NOT EXISTS play_profiles (
        user_id INTEGER PRIMARY KEY, avatar TEXT NOT NULL DEFAULT '{}',
        layout TEXT NOT NULL DEFAULT '{}', study TEXT NOT NULL DEFAULT '{}')''')
    columns = {row[1] for row in db.execute('PRAGMA table_info(play_profiles)')}
    if 'study' not in columns:
        db.execute("ALTER TABLE play_profiles ADD COLUMN study TEXT NOT NULL DEFAULT '{}'")
    db.execute('''CREATE TABLE IF NOT EXISTS play_runs (
        user_id INTEGER PRIMARY KEY, state TEXT NOT NULL)''')
    db.execute('''CREATE TABLE IF NOT EXISTS play_mastery (
        user_id INTEGER NOT NULL, question TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
        correct INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,question))''')
    db.execute('''CREATE TABLE IF NOT EXISTS play_daily (
        user_id INTEGER NOT NULL, day TEXT NOT NULL, mode TEXT NOT NULL,
        PRIMARY KEY(user_id,day,mode))''')


def resolve(s, card, good):
    """Pure game rules. Rendering never supplies damage, positions or rewards."""
    s['correct'] += int(good)
    events = []
    if s['mode'] == 'race':
        s['distance'] += 150 if good else 55
        s['rival'] += 105
        events.append({'kind': 'jump' if good else 'stumble', 'amount': 150 if good else 55})
    else:
        s['energy'] -= CARDS[card]['cost']
        if good:
            if card == 'focus':
                s['energy'] = min(10, s['energy'] + 1)
                events.append({'kind': 'energy', 'amount': 3})
            elif card in ('spark', 'nova'):
                damage = 18 if card == 'spark' else 35
                s['enemy_hp'] = max(0, s['enemy_hp'] - damage)
                events.append({'kind': 'projectile', 'amount': damage})
            elif card == 'ward':
                s['shield'] += 20
                events.append({'kind': 'shield', 'amount': 20})
            elif card == 'heal':
                s['hp'] = min(100, s['hp'] + 18)
                events.append({'kind': 'heal', 'amount': 18})
            elif card == 'griffin':
                s['creatures'] += 1
                events.append({'kind': 'summon', 'amount': 1})
        if s['creatures']:
            damage = s['creatures'] * 7
            s['enemy_hp'] = max(0, s['enemy_hp'] - damage)
            events.append({'kind': 'creature', 'amount': damage})
        if s['enemy_hp']:
            incoming = 10 + (s['step'] % 3) * 3
            blocked = min(s['shield'], incoming)
            s['shield'] -= blocked
            s['hp'] = max(0, s['hp'] - (incoming - blocked))
            events.append({'kind': 'enemy', 'amount': incoming - blocked})
        s['energy'] = min(10, s['energy'] + 2)
    s['step'] += 1
    s['finished'] = s['step'] >= len(s['questions']) or (s['mode'] == 'arena' and (not s['hp'] or not s['enemy_hp']))
    s['won'] = (s['distance'] > s['rival']) if s['mode'] == 'race' else s['enemy_hp'] == 0
    return events


def install(g):
    app, connect = g.app, g.connect
    def initialize():
        with connect() as db:
            init_tables(db)
    initialize()

    def profile(db, uid):
        # Normal reads never run schema migrations. The narrow fallback also
        # supports legacy snapshots opened without an explicit startup migration.
        query = 'SELECT avatar,layout,study FROM play_profiles WHERE user_id=?'
        try:
            row = db.execute(query, (uid,)).fetchone()
        except sqlite3.OperationalError as error:
            if str(error) not in ('no such table: play_profiles', 'no such column: study'):
                raise
            init_tables(db)
            row = db.execute(query, (uid,)).fetchone()
        if row is None:
            db.execute('INSERT OR IGNORE INTO play_profiles(user_id) VALUES(?)', (uid,))
            row = db.execute(query, (uid,)).fetchone()
        layout = json.loads(row['layout'])
        for i, key in enumerate(g.BUILDINGS):
            layout.setdefault(key, {'x': 2 + (i % 3) * 3, 'y': 2 + (i // 3) * 3})
        return {'avatar': json.loads(row['avatar']) or Avatar().model_dump(), 'layout': layout,
                'study': json.loads(row['study']) or StudyPreferences().model_dump()}

    def read(db, uid):
        try:
            row = db.execute('SELECT state FROM play_runs WHERE user_id=?', (uid,)).fetchone()
        except sqlite3.OperationalError as error:
            if str(error) != 'no such table: play_runs':
                raise
            init_tables(db)
            row = db.execute('SELECT state FROM play_runs WHERE user_id=?', (uid,)).fetchone()
        return json.loads(row['state']) if row else None

    def save(db, uid, s):
        db.execute('INSERT OR REPLACE INTO play_runs VALUES(?,?)', (uid, json.dumps(s)))

    def public(s):
        if not s:
            return None
        result = {k: v for k, v in s.items() if k not in ('questions', 'pending', 'last')}
        result['total'] = len(s['questions'])
        result['pending'] = s.get('pending')
        if s.get('pending') and not s['finished']:
            result['question'] = g.question_public(s['questions'][s['step']])
        return result

    @app.get('/play')
    def play_page():
        return FileResponse(g.ROOT / 'static' / 'play.html')

    @app.get('/api/play')
    def state(request: Request):
        u = g.require_user(request)
        with connect() as db:
            p = profile(db, u['id'])
            return {**p, 'run': public(read(db, u['id'])), 'cards': CARDS}

    @app.get('/api/play/bootstrap')
    def bootstrap(request: Request):
        """Return one coherent game snapshot instead of serial profile/state calls.

        Collection, profile, layout and active run share the same transaction;
        no question bank or hidden answers are included in the initial payload.
        """
        uid = g.require_user(request)['id']
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            g.collect(db, uid)
            user = g.fresh_user(db, uid)
            rates = g.production_rates(user)
            current_profile = {**g.public_user(user), 'rates': rates}
            play = {**profile(db, uid), 'run': public(read(db, uid)), 'cards': CARDS}
            strategy = {
                'rates': rates,
                'buildings': [
                    {'id': name, **{k: v for k, v in conf.items() if k != 'base'},
                     'level': user[name], 'next_cost': g.upgrade_cost(name, user[name]),
                     'max_level': 10}
                    for name, conf in g.BUILDINGS.items()
                ],
                'units': [
                    {'id': name, **config,
                     'cost': dict(zip(('gold', 'wood', 'stone'), config['cost'])),
                     'owned': user[name]}
                    for name, config in g.UNITS.items()
                ],
                'capacity': 40 + user['barracks'] * 20,
                'territories': [
                    {'id': name, **conf, 'owned': name in json.loads(user['territories'])}
                    for name, conf in g.TERRITORIES.items()
                ],
            }
            return {'profile': current_profile, 'play': play, 'strategy': strategy}

    @app.get('/api/study/catalog')
    def study_catalog(request: Request):
        g.require_user(request)
        from study_catalog import catalog
        return catalog(g.QUESTIONS)

    @app.post('/api/play/study')
    def study_preferences(data: StudyPreferences, request: Request):
        uid = g.require_user(request)['id']
        with connect() as db:
            profile(db, uid)
            db.execute('UPDATE play_profiles SET study=? WHERE user_id=?', (data.model_dump_json(), uid))
        return data.model_dump()

    @app.post('/api/play/avatar')
    def avatar(data: Avatar, request: Request):
        uid = g.require_user(request)['id']
        with connect() as db:
            profile(db, uid)
            db.execute('UPDATE play_profiles SET avatar=? WHERE user_id=?', (data.model_dump_json(), uid))
        return data.model_dump()

    @app.post('/api/play/place')
    def place(data: Placement, request: Request):
        uid = g.require_user(request)['id']
        base = data.building.removesuffix('_annex')
        if base not in g.BUILDINGS or (data.construct_building and data.building != base):
            raise HTTPException(400, 'Bâtiment inconnu.')
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            p = profile(db, uid)
            key = data.building
            # One additional functional production building per type in this slice.
            if data.construct_building:
                if key not in ('mine', 'sawmill', 'quarry'):
                    raise HTTPException(400, 'Seuls les producteurs peuvent être construits ici.')
                key += '_annex'
                if key in p['layout']:
                    raise HTTPException(409, 'Annexe déjà construite.')
            elif key not in p['layout']:
                raise HTTPException(400, 'Bâtiment absent.')
            if any(k != key and v == {'x': data.x, 'y': data.y} for k, v in p['layout'].items()):
                raise HTTPException(409, 'Case occupée.')
            if data.construct_building:
                g.collect(db, uid)
                u = g.fresh_user(db, uid)
                if u[data.building] >= 10:
                    raise HTTPException(400, 'Production maximale atteinte dans cette tranche.')
                cost = {'gold': 60, 'wood': 40, 'stone': 20}
                if any(u[k] < v for k, v in cost.items()):
                    raise HTTPException(400, 'Ressources insuffisantes.')
                # Production uses existing authoritative level/rate calculation.
                db.execute(f'UPDATE users SET gold=gold-60,wood=wood-40,stone=stone-20,{data.building}={data.building}+1 WHERE id=?', (uid,))
            p['layout'][key] = {'x': data.x, 'y': data.y}
            db.execute('UPDATE play_profiles SET layout=? WHERE user_id=?', (json.dumps(p['layout']), uid))
            return p

    @app.post('/api/play/start')
    def start(data: Start, request: Request):
        uid = g.require_user(request)['id']
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = read(db, uid)
            if old and not old['finished']:
                raise HTTPException(409, 'Termine ou abandonne la partie en cours.')
            u = g.fresh_user(db, uid)
            focus = g.user_focus(u)
            pool = g.pool_for_focus(focus)
            preferences = profile(db, uid)['study']
            if preferences['difficulty']:
                pool = [i for i in pool if g.QUESTIONS[i]['difficulty'] == preferences['difficulty']]
            if preferences['weak_only']:
                attempts = {r['question']: r for r in db.execute('SELECT * FROM play_mastery WHERE user_id=?', (uid,))}
                pool = [i for i in pool if g.QUESTIONS[i]['q'] in attempts and attempts[g.QUESTIONS[i]['q']]['correct'] / attempts[g.QUESTIONS[i]['q']]['attempts'] < .8]
            if not pool:
                raise HTTPException(400, 'Aucune question pour ce filtre. Élargis la révision ou désactive le filtre des erreurs.')
            # Fresh shuffled question copies preserve a run across bank imports/restarts.
            indices = random.sample(pool, min(8 if data.mode == 'arena' else 6, len(pool)))
            s = dict(run_id=secrets.token_hex(16), mode=data.mode, focus=focus, step=0, correct=0,
                     hp=100, enemy_hp=85, energy=3, shield=0, creatures=0,
                     distance=0, rival=0, finished=False, won=False, pending=None,
                     questions=[g.shuffled_question(g.QUESTIONS[i]) for i in indices])
            save(db, uid, s)
            return public(s)

    @app.post('/api/play/action')
    def action(data: Action, request: Request):
        uid = g.require_user(request)['id']
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            s = read(db, uid)
            if not s or s['run_id'] != data.run_id or s['step'] != data.step or s['finished']:
                raise HTTPException(409, 'Cette manche n’est plus active.')
            card = data.card if s['mode'] == 'arena' else 'jump'
            if s['pending'] and s['pending'] != card:
                raise HTTPException(409, 'Action déjà choisie pour cette question.')
            if s['mode'] == 'arena':
                if card not in CARDS or CARDS[card]['cost'] > s['energy']:
                    raise HTTPException(400, 'Carte indisponible ou énergie insuffisante.')
                if card == 'griffin' and s['creatures'] >= 2:
                    raise HTTPException(400, 'Les deux places de créature sont occupées.')
            s['pending'] = card
            save(db, uid, s)
            return public(s)

    @app.post('/api/play/answer')
    def answer(data: Answer, request: Request):
        uid = g.require_user(request)['id']
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            s = read(db, uid)
            if not s or s['run_id'] != data.run_id:
                raise HTTPException(409, 'Partie inconnue.')
            # Idempotent replay after response loss; never award twice.
            if s.get('last') and s['last']['answered_step'] == data.step:
                return s['last']
            if s['finished'] or s['step'] != data.step or not s['pending']:
                raise HTTPException(409, 'Action ou manche invalide.')
            q = s['questions'][s['step']]
            good = data.choice == q['correct']
            previous = db.execute('SELECT * FROM play_mastery WHERE user_id=? AND question=?', (uid, q['q'])).fetchone()
            # Repeated successes on the same question cannot generate unlimited rewards.
            eligible = not previous or previous['correct'] == 0
            earned = g.award_answer(db, uid, q['category'], good, q['q']) if eligible or not good else {'score': 0, 'xp': 0, 'repeat': True}
            db.execute('''INSERT INTO play_mastery VALUES(?,?,1,?) ON CONFLICT(user_id,question)
                DO UPDATE SET attempts=attempts+1,correct=correct+excluded.correct''', (uid, q['q'], int(good)))
            events = resolve(s, s['pending'], good)
            s['pending'] = None
            reward = {'gold': 0, 'wood': 0, 'stone': 0}
            if s['finished'] and s['correct']:
                day = g.datetime.now(g.timezone.utc).date().isoformat()
                first = db.execute('INSERT OR IGNORE INTO play_daily VALUES(?,?,?)', (uid, day, s['mode'])).rowcount
                if first:
                    reward = dict(gold=s['correct'] * 8, wood=s['correct'] * 5, stone=s['correct'] * 3)
                    db.execute('UPDATE users SET gold=gold+?,wood=wood+?,stone=stone+? WHERE id=?', (*reward.values(), uid))
            result = {'answered_step': data.step, 'correct': good, 'correct_index': q['correct'],
                      'explanation': q['explanation'], 'earned': earned, 'events': events,
                      'reward': reward, 'run': public(s)}
            s['last'] = result
            save(db, uid, s)
            return result

    @app.post('/api/play/abandon')
    def abandon(request: Request):
        uid = g.require_user(request)['id']
        with connect() as db:
            db.execute('BEGIN IMMEDIATE')
            s = read(db, uid)
            if s:
                s['finished'] = True
                s['won'] = False
                s['pending'] = None
                save(db, uid, s)
        return {'ok': True}
