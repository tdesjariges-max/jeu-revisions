/* Luméria world renderer. Rendering is cosmetic; rules and rewards stay on the server.
   Public API: await LumeriaWorld.mount(host,state,callbacks) -> controller.
   controller.update(state), animate(events,oldRun,newRun?), zoom(delta), center(),
   resize(), pause(), resume(), destroy(), metrics(), cellToScreen(col,row).
   A sleeping Canvas renderer wakes only for input, state changes and finite effects. */
(() => {
  'use strict';
  const ART = '/static/art/';
  const COL = {ink:0x343151, cream:0xfff1ce, lavender:0x9270d4, coral:0xed7c66, gold:0xffc85b, grass:0x71bc66, leaf:0x429767, sky:0x9bd8e9};
  const LABELS = {academy:'Académie',mine:'Mine d’or',sawmill:'Scierie',quarry:'Carrière',barracks:'Caserne',wall:'Remparts'};
  const BUILDINGS = Object.keys(LABELS);
  const STEP_X = 54, STEP_Y = 30;
  const clamp = (v,a,b) => Math.min(b,Math.max(a,v));
  const project = (x,y) => ({x:(x-y)*STEP_X,y:(x+y)*STEP_Y});
  const signature = value => JSON.stringify(value ?? null);

  class Controller {
    constructor(host,state,callbacks) {
      this.host=host;this.state=state;this.callbacks=callbacks||{};this.scene=null;this.game=null;
      this.mode=null;this.root=null;this.layers=null;this.buildings=new Map();this.pointers=new Map();
      this.view={zoom:1,panX:0,panY:0,focusX:75,focusY:225};
      this._destroyed=false;this._paused=false;this._sleepTimer=null;this._animations=0;this._animationResolvers=new Set();
      this._counts={frames:0,modeBuilds:0,mapBuilds:0,stateUpdates:0,wakes:0,animations:0};
      this._events=[];this._avatarSig='';this._lastLayout='';
      this._resizeRaf=0;this._lastWidth=0;this._lastHeight=0;this._lastVisual='';this._manualView=false;
      this._reduced=Boolean(state.reducedMotion ?? matchMedia('(prefers-reduced-motion: reduce)').matches);
    }
    async start(){
      if(!window.Phaser)throw new Error('Le moteur de jeu n’a pas pu être chargé.');
      const self=this;
      return new Promise((resolve,reject)=>{
        class Scene extends Phaser.Scene {
          constructor(){super('lumeria-world');}
          preload(){
            self._assetStartedAt=performance.now();
            // Pre-rasterized original SVGs: one image decode, two requests, no runtime SVG rasterization.
            this.load.atlas('lumeria-sprites',ART+'sprites.png',ART+'sprites.json');
            this.load.on('loaderror',file=>{self._loadError='Illustration introuvable : '+file.key;});
          }
          create(){
            self.scene=this;
            self._counts.assetLoadMs=Math.round(performance.now()-self._assetStartedAt);
            const sceneStarted=performance.now();
            if(self._loadError){reject(new Error(self._loadError));queueMicrotask(()=>self.destroy());return;}
            self._createSharedTextures();
            self._bindInputs();
            self._renderMode(true);
            self.update(self.state);
            self._counts.sceneBuildMs=Math.round(performance.now()-sceneStarted);
            self._wake(160);
            (self.callbacks.ready||self.callbacks.onReady)?.(self);
            resolve(self);
          }
          update(){self._counts.frames++;}
        }
        const width=Math.max(280,Math.round(this.host.clientWidth||800));
        const height=Math.max(240,Math.round(this.host.clientHeight||480));
        this._lastWidth=width;this._lastHeight=height;
        this.game=new Phaser.Game({
          type:Phaser.CANVAS,parent:this.host,width,height,resolution:Math.min(devicePixelRatio||1,1.5),
          transparent:false,backgroundColor:'#b8e7ee',banner:false,
          scale:{mode:Phaser.Scale.NONE},fps:{target:30,forceSetTimeOut:false},
          render:{antialias:true,roundPixels:false},
          input:{mouse:{enabled:false},touch:{enabled:false},keyboard:false,gamepad:false},
          audio:{noAudio:true},scene:Scene
        });
      });
    }
    _image(x,y,key){return key.startsWith('art-')?this.scene.add.image(x,y,'lumeria-sprites',key.slice(4)):this.scene.add.image(x,y,key);}
    _setSprite(image,key){return image.setTexture('lumeria-sprites',key.replace(/^art-/,''));}
    _on(target,event,handler,options){target.addEventListener(event,handler,options);this._events.push(()=>target.removeEventListener(event,handler,options));}
    _bindInputs(){
      this.host.style.touchAction='none';
      if(!this.host.hasAttribute('tabindex'))this.host.tabIndex=0;
      this.host.setAttribute('role','img');
      this._on(this.host,'pointerdown',e=>this._pointerDown(e));
      this._on(this.host,'pointermove',e=>this._pointerMove(e));
      this._on(this.host,'pointerup',e=>this._pointerUp(e));
      this._on(this.host,'pointercancel',e=>{this.pointers.delete(e.pointerId);this._pinch=null;});
      this._on(this.host,'pointerleave',()=>{if(!this.pointers.size&&this.hover){this.hover.clear();this.ghost?.setVisible(false);this._wake();}});
      this._on(this.host,'wheel',e=>{if(this.mode!=='kingdom')return;e.preventDefault();this.zoom(-e.deltaY*.001);},{passive:false});
      this._on(this.host,'keydown',e=>{
        if(this.mode!=='kingdom')return;
        const moves={ArrowLeft:[35,0],ArrowRight:[-35,0],ArrowUp:[0,35],ArrowDown:[0,-35]};
        if(moves[e.key]){this._manualView=true;e.preventDefault();this.view.panX+=moves[e.key][0];this.view.panY+=moves[e.key][1];this._applyView();}
        else if(e.key==='+'||e.key==='='){e.preventDefault();this.zoom(.12);}
        else if(e.key==='-'){e.preventDefault();this.zoom(-.12);}
        else if(e.key==='Home'){e.preventDefault();this.center();}
      });
      this._on(document,'visibilitychange',()=>{if(document.hidden)this.pause();else this.resume();});
      this._resizeObserver=new ResizeObserver(()=>{
        if(this._resizeRaf)return;
        this._resizeRaf=requestAnimationFrame(()=>{this._resizeRaf=0;this.resize();});
      });
      this._resizeObserver.observe(this.host);
    }
    _local(event){const b=this.host.getBoundingClientRect();return {x:event.clientX-b.left,y:event.clientY-b.top};}
    _pointerDown(e){
      if(this._destroyed||this.mode!=='kingdom'||this._animations)return;
      const p=this._local(e);this.pointers.set(e.pointerId,{...p,startX:p.x,startY:p.y,moved:false});
      try{this.host.setPointerCapture(e.pointerId);}catch{}
      if(this.pointers.size===2){const ps=[...this.pointers.values()];this._pinch={distance:Math.hypot(ps[0].x-ps[1].x,ps[0].y-ps[1].y),zoom:this.view.zoom};ps.forEach(p=>p.moved=true);}
      this._wake();
    }
    _pointerMove(e){
      if(this.mode!=='kingdom'||this._animations)return;
      const p=this._local(e),old=this.pointers.get(e.pointerId);
      if(old){
        const dx=p.x-old.x,dy=p.y-old.y;
        old.x=p.x;old.y=p.y;
        if(Math.hypot(p.x-old.startX,p.y-old.startY)>6)old.moved=true;
        if(this.pointers.size===2&&this._pinch){
          this._manualView=true;const ps=[...this.pointers.values()];this.view.zoom=clamp(this._pinch.zoom*Math.hypot(ps[0].x-ps[1].x,ps[0].y-ps[1].y)/Math.max(1,this._pinch.distance),.32,1.5);this._applyView();
        }else if(old.moved&&!this.state.moving&&!this.state.construct){this._manualView=true;this.view.panX+=dx;this.view.panY+=dy;this._applyView();}
      }
      if(this.state.moving||this.state.construct)this._showPlacement(p);
    }
    _pointerUp(e){
      const p=this.pointers.get(e.pointerId);this.pointers.delete(e.pointerId);
      if(this.pointers.size<2)this._pinch=null;
      if(!p||p.moved||this.mode!=='kingdom'||this._animations)return;
      const point=this._local(e);
      if(this.state.moving||this.state.construct){
        const cell=this.screenToCell(point.x,point.y);
        if(cell&&(this.callbacks.place||this.callbacks.onPlace)){
          (this.callbacks.place||this.callbacks.onPlace)(cell.x,cell.y);
        }
      }else{
        const world=this._screenToWorld(point.x,point.y);
        const entries=[...this.buildings.values()].sort((a,b)=>b.pos.y-a.pos.y);
        const hit=entries.find(b=>Math.abs(world.x-b.pos.x)<76&&world.y>b.pos.y-135&&world.y<b.pos.y+14);
        if(hit)(this.callbacks.selectBuilding||this.callbacks.onSelect)?.(hit.id);
        else if(this.hero)this._walkHero(world);
      }
      this._wake(180);
    }
    _screenToWorld(x,y){return {x:(x-this.root.x)/this.view.zoom,y:(y-this.root.y)/this.view.zoom};}
    screenToCell(x,y){
      if(this.mode!=='kingdom'||!this.root)return null;
      const p=this._screenToWorld(x,y);
      const col=Math.round((p.y/STEP_Y+p.x/STEP_X)/2),row=Math.round((p.y/STEP_Y-p.x/STEP_X)/2);
      return col>=0&&col<12&&row>=0&&row<10?{x:col,y:row}:null;
    }
    cellToScreen(col,row){const p=project(col,row);return {x:this.root.x+p.x*this.view.zoom,y:this.root.y+p.y*this.view.zoom};}
    getPlacement(col,row){return this.cellToScreen(col,row);}
    _wake(ms=100){
      if(this._destroyed||!this.game||this._paused||document.hidden)return;
      this.game.loop.wake();this._counts.wakes++;
      clearTimeout(this._sleepTimer);
      this._sleepTimer=setTimeout(()=>{if(!this._animations&&!this._destroyed)this.game.loop.sleep();},Math.max(80,ms));
    }
    pause(){
      this._paused=true;clearTimeout(this._sleepTimer);this.game?.loop.sleep();
      // A hidden tab must never leave an answer waiting for a paused tween.
      if(this._animations){this.scene?.tweens?.killAll();this._animationResolvers.forEach(resolve=>resolve());this._animationResolvers.clear();this.effects?.removeAll(true);}
    }
    resume(){if(this._destroyed)return;this._paused=false;this.resize();this._wake(160);}
    _createSharedTextures(){
      if(this.scene.textures.exists('lumeria-island'))return;
      const started=performance.now();
      const tex=this.scene.textures.createCanvas('lumeria-island',1420,1060),ctx=tex.context;
      ctx.translate(690,160);
      const outline=()=>{ctx.beginPath();ctx.moveTo(-34,-60);ctx.bezierCurveTo(175,2,521,190,652,295);ctx.quadraticCurveTo(681,328,643,354);ctx.lineTo(124,680);ctx.quadraticCurveTo(80,712,28,689);ctx.lineTo(-596,365);ctx.quadraticCurveTo(-634,330,-592,298);ctx.closePath();};
      ctx.save();ctx.translate(0,120);outline();ctx.shadowColor='#445b7850';ctx.shadowBlur=35;ctx.shadowOffsetY=27;ctx.fillStyle='#9f8a87';ctx.fill();ctx.shadowBlur=0;ctx.lineWidth=8;ctx.strokeStyle='#645170';ctx.stroke();ctx.restore();
      ctx.save();ctx.translate(0,38);outline();ctx.fillStyle='#bd9d85';ctx.fill();ctx.lineWidth=7;ctx.strokeStyle='#756278';ctx.stroke();ctx.restore();
      outline();ctx.fillStyle='#7fc877';ctx.fill();ctx.lineWidth=9;ctx.strokeStyle='#47986c';ctx.stroke();
      ctx.save();outline();ctx.clip();
      // Warm winding paths connecting the original six building sites.
      ctx.strokeStyle='#f2db99';ctx.lineWidth=34;ctx.lineCap='round';ctx.lineJoin='round';
      ctx.beginPath();ctx.moveTo(-220,130);ctx.bezierCurveTo(-48,205,113,249,315,322);ctx.moveTo(-120,340);ctx.bezierCurveTo(26,270,128,226,282,138);ctx.stroke();
      ctx.strokeStyle='#fff1c1';ctx.lineWidth=5;ctx.stroke();
      let seed=35;const rand=()=>{seed=(seed*16807)%2147483647;return seed/2147483647;};
      for(let i=0;i<135;i++){
        const x=rand()*1200-600,y=rand()*730-40;
        ctx.fillStyle=i%4===0?'#ffe898':'#a8de87';ctx.beginPath();ctx.ellipse(x,y,3+rand()*4,2+rand()*2,0,0,7);ctx.fill();
      }
      for(let i=0;i<38;i++){const x=rand()*1200-600,y=rand()*730;ctx.strokeStyle='#58ad72';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x-3,y+4);ctx.quadraticCurveTo(x-4,y,x-6,y-2);ctx.moveTo(x,y+4);ctx.quadraticCurveTo(x+2,y,x+5,y-3);ctx.stroke();}
      ctx.restore();tex.refresh();this._counts.mapBuilds++;this._counts.groundBakeMs=Math.round(performance.now()-started);
    }
    _renderMode(initial=false){
      const next=this.state.mode||'kingdom';
      if(this.mode===next&&!initial)return;
      if(this.layers)this.layers.destroy(true);
      this.scene.tweens.killAll();this.buildings.clear();this._avatarSig='';this._lastLayout='';
      this.mode=next;this.layers=this.scene.add.container();this._counts.modeBuilds++;
      this.back=this.scene.add.graphics();this.layers.add(this.back);
      this.root=this.scene.add.container();this.layers.add(this.root);
      if(next==='kingdom')this._createKingdom();
      else if(next==='arena')this._createArena();
      else this._createRace();
      this.effects=this.scene.add.container();this.layers.add(this.effects);
      this._paintBackdrop();this._layoutMode(true);
    }
    _cloud(g,x,y,s,alpha=1){g.fillStyle(0xffffff,alpha);g.fillEllipse(x,y,110*s,36*s);g.fillCircle(x-22*s,y-15*s,25*s);g.fillCircle(x+12*s,y-23*s,32*s);g.fillCircle(x+42*s,y-7*s,20*s);}
    _paintBackdrop(){
      const g=this.back,w=this.width,h=this.height;g.clear();
      if(this.mode==='kingdom'){
        g.fillStyle(0xb4e5ec);g.fillRect(0,0,w,h);g.fillStyle(0xa3dce4,.55);g.fillEllipse(w*.5,h*1.1,w*1.5,h*.9);
        this._cloud(g,w*.14,h*.16,.8,.6);this._cloud(g,w*.86,h*.2,.7,.5);this._cloud(g,w*.52,h*.83,.6,.65);
        g.lineStyle(3,0xd7f2f0,.8);g.strokeEllipse(w*.2,h*.8,75,8);g.strokeEllipse(w*.85,h*.85,100,10);
      }else if(this.mode==='arena'){
        g.fillStyle(0xe5d9f6);g.fillRect(0,0,w,h);g.fillStyle(0xc9c1e8);g.fillEllipse(w*.5,h*.6,w*1.8,h*.95);
        this._cloud(g,w*.16,h*.18,.7,.5);this._cloud(g,w*.78,h*.18,.8,.5);
        g.fillStyle(0xaaa3ca);g.fillEllipse(w*.5,h*.87,w*.92,h*.23);g.fillStyle(0xe4d0a4);g.fillEllipse(w*.5,h*.78,w*.92,h*.29);
        g.lineStyle(4,0xfff1ce);g.strokeEllipse(w*.5,h*.78,w*.88,h*.25);
        g.lineStyle(2,0xc5ac86,.5);g.strokeEllipse(w*.5,h*.78,w*.65,h*.17);
        for(let i=0;i<7;i++){const x=w*(.12+i*.125);g.fillStyle(0xbab1d7);g.fillRoundedRect(x-11,h*.31,22,h*.22,6);g.fillStyle(0x9588bd);g.fillTriangle(x-18,h*.32,x,h*.24,x+18,h*.32);}
      }else{
        g.fillStyle(0xb8e8f1);g.fillRect(0,0,w,h);this._cloud(g,w*.2,h*.15,.65,.9);this._cloud(g,w*.75,h*.24,.8,.8);
        g.fillStyle(0x9ecfbe);g.fillEllipse(w*.15,h*.72,w*.9,h*.75);g.fillStyle(0x89c7a4);g.fillEllipse(w*.75,h*.73,w*1.2,h*.66);
        g.fillStyle(0x71bc66);g.fillRect(0,h*.63,w,h*.37);
        g.fillStyle(0xf6d7a0);g.fillRoundedRect(-20,h*.68,w+40,h*.12,16);g.fillRoundedRect(-20,h*.86,w+40,h*.1,16);
        g.lineStyle(3,0xffefc4);g.lineBetween(0,h*.69,w,h*.69);g.lineBetween(0,h*.87,w,h*.87);
        for(let i=0;i<6;i++){const x=w*(.08+i*.18),y=h*.61;g.fillStyle(0x4b9a65);g.fillCircle(x,y,18);g.fillCircle(x+12,y+3,14);g.fillStyle(0xffd578);g.fillCircle(x-5,y-1,3);}
        g.fillStyle(COL.ink);g.fillRoundedRect(w-23,h*.37,5,h*.32,2);g.fillStyle(0xfff1ce);g.fillRect(w-18,h*.37,23,23);
        g.fillStyle(COL.lavender);for(let row=0;row<3;row++)for(let col=0;col<3;col++)if((row+col)%2===0)g.fillRect(w-18+col*7.67,h*.37+row*7.67,7.67,7.67);
      }
    }
    _createKingdom(){
      this.map=this._image(0,0,'lumeria-island').setOrigin(690/1420,160/1060);this.root.add(this.map);
      this.paths=this.scene.add.graphics();this.root.add(this.paths);
      this.grid=this.scene.add.graphics().setVisible(false);this.root.add(this.grid);
      this.selection=this.scene.add.graphics();this.root.add(this.selection);
      this.ornaments=this.scene.add.container();this.root.add(this.ornaments);
      const trees=[[-220,125,.9],[-390,280,.86],[-235,385,.8],[383,225,.88],[470,318,.9],[220,465,.9],[-65,445,.86],[20,42,.65],[218,127,.65],[-60,505,.8],[395,425,.7]];
      for(const [x,y,s] of trees){const image=this._image(x,y,'art-tree').setOrigin(.5,.95).setScale(s);this.ornaments.add(image);}
      for(const [x,y,s] of [[-310,337,.7],[455,350,.7],[225,500,.55],[-155,145,.5]])this.ornaments.add(this._image(x,y,'art-rock').setOrigin(.5,.9).setScale(s));
      this.structureLayer=this.scene.add.container();this.root.add(this.structureLayer);
      this.hero=this._makeHero(this.root,this.state.play?.avatar);this.hero.setPosition(45,420).setScale(.64);
      this.ghost=this._image(0,0,'art-building-mine').setOrigin(.5,218/240).setScale(.62).setAlpha(.6).setVisible(false);this.root.add(this.ghost);
      this.hover=this.scene.add.graphics();this.root.add(this.hover);
      const grid=this.grid;grid.lineStyle(1.8,0xfff6ce,.8);
      for(let row=0;row<10;row++)for(let col=0;col<12;col++){const p=project(col,row);grid.strokePoints([{x:p.x,y:p.y-29},{x:p.x+53,y:p.y},{x:p.x,y:p.y+29},{x:p.x-53,y:p.y}],true);}
      this._updateBuildings();
    }
    _makeHero(parent,avatar){
      const c=this.scene.add.container();parent.add(c);
      c.cape=this.scene.add.graphics();c.hairBack=this.scene.add.graphics();c.body=this._image(0,0,'art-hero-'+(avatar?.color||'teal')).setOrigin(.5,.95);c.hairFront=this.scene.add.graphics();
      c.add([c.cape,c.hairBack,c.body,c.hairFront]);this._styleHero(c,avatar||{});return c;
    }
    _styleHero(c,avatar){
      this._setSprite(c.body,'art-hero-'+(avatar.color||'teal'));c.cape.clear();c.hairBack.clear();c.hairFront.clear();
      const ink=COL.ink;
      if(avatar.cape!==false){c.cape.fillStyle(0x7552ac);c.cape.lineStyle(3,ink);c.cape.fillPoints([{x:-30,y:-90},{x:28,y:-90},{x:36,y:-15},{x:0,y:-25},{x:-55,y:-15}],true);c.cape.strokePoints([{x:-30,y:-90},{x:28,y:-90},{x:36,y:-15},{x:0,y:-25},{x:-55,y:-15}],true);}
      if(avatar.hair==='long'){c.hairBack.fillStyle(0x684748);c.hairBack.lineStyle(3,ink);c.hairBack.fillRoundedRect(-40,-145,78,73,24);c.hairBack.strokeRoundedRect(-40,-145,78,73,24);}
      if(avatar.hair==='crest'){c.hairFront.fillStyle(0x684748);c.hairFront.lineStyle(3,ink);const p=[{x:-16,y:-163},{x:-8,y:-190},{x:12,y:-168},{x:27,y:-182},{x:29,y:-151}];c.hairFront.fillPoints(p,true);c.hairFront.strokePoints(p,true);}
    }
    _updateBuildings(){
      const layout=this.state.play?.layout||{},levels=this.state.profile?.buildings||{};
      for(const [id,entry] of [...this.buildings])if(!layout[id]){entry.container.destroy(true);this.buildings.delete(id);}
      for(const [id,cell] of Object.entries(layout)){
        const type=id.replace('_annex','');if(!BUILDINGS.includes(type))continue;
        let entry=this.buildings.get(id);const pos=project(cell.x,cell.y),level=levels[type]||1;
        if(!entry){
          const container=this.scene.add.container();this.structureLayer.add(container);
          const image=this._image(0,0,'art-building-'+type).setOrigin(.5,218/240).setScale(.62);
          const label=this.scene.add.text(0,17,'',{fontFamily:'Arial, sans-serif',fontSize:'17px',fontStyle:'bold',color:'#343151',stroke:'#fff8e7',strokeThickness:5}).setOrigin(.5,0);
          const flag=this.scene.add.graphics();container.add([image,flag,label]);
          entry={id,type,container,image,label,flag,pos,level:0};this.buildings.set(id,entry);
        }
        entry.pos=pos;entry.container.setPosition(pos.x,pos.y);entry.container.setDepth(pos.y);
        if(entry.level!==level){entry.level=level;entry.label.setText(`${LABELS[type]} · ${level}`);entry.flag.clear();if(level>=5){entry.flag.fillStyle(COL.gold);entry.flag.lineStyle(2,COL.ink);entry.flag.fillCircle(41,-95,12);entry.flag.strokeCircle(41,-95,12);}}
      }
      this.structureLayer.sort('depth');this._updateSelection();
    }
    _updateSelection(){
      if(this.mode!=='kingdom')return;this.selection.clear();
      const selected=this.buildings.get(this.state.selected);
      if(selected){const p=selected.pos;this.selection.fillStyle(COL.gold,.22);this.selection.lineStyle(4,COL.gold,1);const points=[{x:p.x,y:p.y-39},{x:p.x+76,y:p.y},{x:p.x,y:p.y+39},{x:p.x-76,y:p.y}];this.selection.fillPoints(points,true);this.selection.strokePoints(points,true);}
      const placing=Boolean(this.state.moving||this.state.construct);this.grid.setVisible(placing);if(!placing){this.hover.clear();this.ghost.setVisible(false);}
      this.host.style.cursor=placing?'crosshair':'grab';
      for(const entry of this.buildings.values()){entry.label.setVisible(entry.id===this.state.selected||this.view.zoom>.66);entry.image.setAlpha(this.state.moving&&entry.id===this.state.selected? .65:1);}
    }
    _showPlacement(screen){
      const cell=this.screenToCell(screen.x,screen.y);this.hover.clear();
      if(!cell){this.ghost.setVisible(false);this._wake();return;}
      const p=project(cell.x,cell.y);
      const occupied=Object.entries(this.state.play?.layout||{}).some(([id,v])=>!(this.state.moving&&id===this.state.selected)&&v.x===cell.x&&v.y===cell.y);
      const color=occupied?0xe5676b:0xffd463;
      this.hover.fillStyle(color,.26);this.hover.lineStyle(3,color);const points=[{x:p.x,y:p.y-29},{x:p.x+53,y:p.y},{x:p.x,y:p.y+29},{x:p.x-53,y:p.y}];this.hover.fillPoints(points,true);this.hover.strokePoints(points,true);
      const type=(this.state.construct||this.state.selected||'mine').replace('_annex','');
      this._setSprite(this.ghost,'art-building-'+type).setPosition(p.x,p.y).setVisible(true).setAlpha(occupied ? .25 : .65);
      this._wake(120);
    }
    _createArena(){
      this.hero=this._makeHero(this.root,this.state.play?.avatar);
      this.enemy=this._image(0,0,'art-dragon').setOrigin(.5,220/240);this.root.add(this.enemy);
      this.shield=this.scene.add.graphics();this.root.add(this.shield);
      this.creatures=[];for(let i=0;i<2;i++){const c=this._image(0,0,'art-griffin').setOrigin(.5,148/160).setVisible(false);this.root.add(c);this.creatures.push(c);}
      this.heroLabel=this._makeLabel('TOI',this.root);this.enemyLabel=this._makeLabel('NOX',this.root);
      this.hp=this.scene.add.graphics();this.root.add(this.hp);
    }
    _createRace(){
      this.obstacles=this.scene.add.graphics();this.root.add(this.obstacles);
      this.hero=this._makeHero(this.root,this.state.play?.avatar);
      this.enemy=this._image(0,0,'art-hero-gold').setOrigin(.5,.95);this.root.add(this.enemy);
      this.heroLabel=this._makeLabel('TOI',this.root);this.enemyLabel=this._makeLabel('MAË',this.root);
    }
    _makeLabel(text,parent){const label=this.scene.add.text(0,0,text,{fontFamily:'Arial, sans-serif',fontStyle:'bold',fontSize:'15px',color:'#343151',stroke:'#fff8e7',strokeThickness:4}).setOrigin(.5);parent.add(label);return label;}
    _layoutMode(reset=false){
      const w=this.width,h=this.height;
      if(this.mode==='kingdom'){
        if(reset||!this._manualView){this.view.panX=0;this.view.panY=0;this._fitVillage();}
        this._applyView();return;
      }
      this.root.setPosition(0,0).setScale(1);
      const scale=clamp(Math.min(w/940,h/480),.42,1.1);
      if(this.mode==='arena'){
        this.hero.setPosition(w*.23,h*.78).setScale(scale*1.06);this.enemy.setPosition(w*.78,h*.77).setScale(scale*1.15);
        this.heroLabel.setPosition(w*.23,h*.9);this.enemyLabel.setPosition(w*.78,h*.9);
        this.creatures.forEach((c,i)=>c.setPosition(w*(.41+i*.1),h*.76).setScale(scale*.6));
        this._updateArena();
      }else{
        this.hero.setScale(scale*.65);this.enemy.setScale(scale*.58);this.heroLabel.setPosition(45,h*.64);this.enemyLabel.setPosition(45,h*.84);this._paintObstacles();this._updateRace();
      }
    }
    _fitVillage(){
      const entries=[...this.buildings.values()].filter(e=>!e.id.endsWith('_annex'));
      if(entries.length){const xs=entries.map(e=>e.pos.x),ys=entries.map(e=>e.pos.y);const minX=Math.min(...xs)-93,maxX=Math.max(...xs)+93,minY=Math.min(...ys)-165,maxY=Math.max(...ys)+65;this.view.focusX=(minX+maxX)/2;this.view.focusY=(minY+maxY)/2;this.view.zoom=clamp(Math.min((this.width-28)/(maxX-minX),(this.height-35)/(maxY-minY)),.36,1.1);}
    }
    _applyView(){
      if(this.mode!=='kingdom'||!this.root)return;
      this.view.panX=clamp(this.view.panX,-this.width*.9,this.width*.9);this.view.panY=clamp(this.view.panY,-this.height*.8,this.height*.8);
      this.root.setScale(this.view.zoom).setPosition(this.width/2-this.view.focusX*this.view.zoom+this.view.panX,this.height/2-this.view.focusY*this.view.zoom+this.view.panY);
      this._updateSelection();this._wake(100);
    }
    zoom(delta){if(this.mode!=='kingdom')return;this._manualView=true;this.view.zoom=clamp(this.view.zoom+delta,.32,1.5);this._applyView();}
    setZoom(delta){this.zoom(delta);}
    center(){if(this.mode==='kingdom'){this._manualView=false;this._fitVillage();this.view.panX=0;this.view.panY=0;this._applyView();}}
    _updateArena(){
      const r=this.state.run||{};this.heroLabel.setText(`TOI · ${r.hp??100} PV`);this.enemyLabel.setText(`NOX · ${r.enemy_hp??85} PV`);
      this.creatures.forEach((c,i)=>c.setVisible(i<(r.creatures||0)));
      this.shield.clear();if(r.shield){this.shield.lineStyle(5,0x88dfec,.8);this.shield.fillStyle(0x88dfec,.12);this.shield.fillEllipse(this.hero.x,this.hero.y-65*this.hero.scaleX,160*this.hero.scaleX,205*this.hero.scaleY);this.shield.strokeEllipse(this.hero.x,this.hero.y-65*this.hero.scaleX,160*this.hero.scaleX,205*this.hero.scaleY);}
      const barWidth=clamp(this.width*.19,62,150),y=this.height*.94;
      this.hp.clear();[[this.hero.x,r.hp??100,100,0x53aa79],[this.enemy.x,r.enemy_hp??85,85,0x9270d4]].forEach(([x,hp,max,color])=>{this.hp.fillStyle(0xffffff,.75);this.hp.fillRoundedRect(x-barWidth/2,y,barWidth,10,5);this.hp.fillStyle(color);this.hp.fillRoundedRect(x-barWidth/2,y,Math.max(1,barWidth*hp/max),10,5);});
    }
    _raceX(distance,total){const margin=this.width<500?32:60;return margin+(this.width-margin*2)*clamp(distance/Math.max(150,total*150),0,1);}
    _updateRace(){const r=this.state.run||{},total=r.total||6;this.hero.setPosition(this._raceX(r.distance||0,total),this.height*.8);this.enemy.setPosition(this._raceX(r.rival||0,total),this.height*.96);this.heroLabel.setPosition(clamp(this.hero.x,28,this.width-28),this.hero.y-205*this.hero.scaleY-8);this.enemyLabel.setPosition(clamp(this.enemy.x,28,this.width-28),this.enemy.y-205*this.enemy.scaleY-8);}
    _paintObstacles(){
      const g=this.obstacles,w=this.width,h=this.height,total=this.state.run?.total||6;g.clear();const ratio=clamp(w/900,.48,1);
      for(let i=0;i<total;i++){
        const x=this._raceX((i+.72)*150,total),y=h*.8;
        g.lineStyle(2.5,COL.ink);
        if(i%3===0){g.fillStyle(0xbd835a);g.fillRoundedRect(x-10*ratio,y-24*ratio,20*ratio,24*ratio,5);g.strokeRoundedRect(x-10*ratio,y-24*ratio,20*ratio,24*ratio,5);g.fillStyle(0xf6d7a0);g.fillEllipse(x,y-23*ratio,24*ratio,8*ratio);}
        else if(i%3===1){g.fillStyle(0xffefc4);g.fillRoundedRect(x-5*ratio,y-23*ratio,10*ratio,23*ratio,3);g.fillStyle(COL.coral);g.fillEllipse(x,y-22*ratio,34*ratio,17*ratio);g.strokeEllipse(x,y-22*ratio,34*ratio,17*ratio);g.fillStyle(0xfff1ce);g.fillCircle(x-6*ratio,y-23*ratio,3*ratio);g.fillCircle(x+6*ratio,y-20*ratio,3*ratio);}
        else{g.fillStyle(0xa6a4b7);const pts=[{x:x-15*ratio,y},{x:x-10*ratio,y:y-20*ratio},{x:x+4*ratio,y:y-27*ratio},{x:x+18*ratio,y}];g.fillPoints(pts,true);g.strokePoints(pts,true);g.fillStyle(0xc9c9d8);g.fillTriangle(x-9*ratio,y-19*ratio,x+4*ratio,y-25*ratio,x+2*ratio,y-7*ratio);}
      }
    }
    update(state,options={}){
      if(this._destroyed)return;this.state=state;this._reduced=Boolean(state.reducedMotion??this._reduced);this._counts.stateUpdates++;
      if(!this.scene)return;
      const run=state.run;
      const visual=signature([state.mode,state.selected,state.moving,state.construct,state.play?.avatar,state.play?.layout,state.profile?.buildings,run&&[run.hp,run.enemy_hp,run.shield,run.creatures,run.distance,run.rival,run.total,run.step,run.finished]]);
      if(visual===this._lastVisual)return;this._lastVisual=visual;
      const oldMode=this.mode;this._renderMode();
      if(this.mode==='kingdom'){
        const layoutSig=signature([state.play?.layout,state.profile?.buildings]);
        if(layoutSig!==this._lastLayout){this._updateBuildings();this._lastLayout=layoutSig;}
        this._updateSelection();
      }
      const avatarSig=signature(state.play?.avatar);
      if(avatarSig!==this._avatarSig){this._styleHero(this.hero,state.play?.avatar||{});this._avatarSig=avatarSig;}
      if(!options.keepActorPositions){if(this.mode==='arena')this._updateArena();else if(this.mode==='race')this._updateRace();}
      this.host.setAttribute('aria-label',this.mode==='kingdom'?'Carte de ton royaume. Choisis un bâtiment ou déplace la carte.':this.mode==='arena'?'Plateau du duel contre Nox. Les cartes et les questions sont sous la scène.':'Course à obstacles. Les bonnes réponses font sauter ton personnage.');
      this._wake(oldMode!==this.mode?150:100);
    }
    async _walkHero(world){
      if(this._reduced||!this.hero||this._animations)return;
      const x=clamp(world.x,-220,390),y=clamp(world.y,150,480);
      this._animations++;this._wake(400);
      await this._tween(this.hero,{x,y},300,'Sine.easeInOut');this._animations--;this._wake(80);
    }
    _tween(target,properties,duration=300,ease='Sine.easeInOut'){
      if(this._destroyed||!target?.active)return Promise.resolve();
      if(this._paused||document.hidden){for(const [key,value] of Object.entries(properties))target[key]=value;return Promise.resolve();}
      return new Promise(resolve=>{
        let done=false;const finish=()=>{if(done)return;done=true;this._animationResolvers.delete(finish);resolve();};this._animationResolvers.add(finish);
        this.scene.tweens.add({targets:target,...properties,duration:this._reduced?1:duration,ease,onComplete:finish,onStop:finish});
      });
    }
    _floating(x,y,text,color='#fff1ce'){
      if(this._paused||document.hidden||this._reduced)return Promise.resolve();
      const label=this.scene.add.text(x,y,text,{fontFamily:'Arial, sans-serif',fontSize:this.width<500?'24px':'31px',fontStyle:'bold',color,stroke:'#343151',strokeThickness:4}).setOrigin(.5);this.effects.add(label);
      return this._tween(label,{y:y-32,alpha:0},260,'Cubic.easeOut').then(()=>label.destroy());
    }
    _burst(x,y,color=COL.gold){
      if(this._paused||document.hidden||this._reduced)return Promise.resolve();
      const particles=[];for(let i=0;i<8;i++){const angle=i*Math.PI/4;const p=this.scene.add.circle(x,y,3+(i%2),color);this.effects.add(p);particles.push(this._tween(p,{x:x+Math.cos(angle)*34,y:y+Math.sin(angle)*34,alpha:0,scale:0},120,'Cubic.easeOut').then(()=>p.destroy()));}return Promise.all(particles);
    }
    async _projectile(from,to,amount,color){
      const orb=this.scene.add.circle(from.x,from.y-65*from.scaleY,10,color).setStrokeStyle(3,0xfff1ce);this.effects.add(orb);
      const targetY=to.y-85*to.scaleY;
      await this._tween(orb,{x:to.x,y:targetY},160,'Cubic.easeIn');orb.destroy();
      if(this._paused||document.hidden)return;
      await Promise.all([this._burst(to.x,targetY,color),this._floating(to.x,targetY-18,'−'+amount)]);
    }
    async _friendlyEvent(event){
      if(this._destroyed||this._paused||document.hidden)return;
      if(event.kind==='projectile')await this._projectile(this.hero,this.enemy,event.amount,COL.gold);
      else if(event.kind==='creature'){
        const bird=this.creatures.find(c=>c.visible)||this.creatures[0];
        if(bird){const ox=bird.x,oy=bird.y;bird.setVisible(true);await this._tween(bird,{x:this.enemy.x-35,y:this.enemy.y-40},120,'Cubic.easeIn');await Promise.all([this._burst(this.enemy.x,this.enemy.y-45,COL.gold),this._floating(this.enemy.x,this.enemy.y-95,'−'+event.amount),this._tween(bird,{x:ox,y:oy},120)]);}
      }else if(event.kind==='summon'){
        const bird=this.creatures.find(c=>!c.visible)||this.creatures[1];bird.setVisible(true);const size=bird.scaleX;bird.setScale(0);await this._tween(bird,{scaleX:size,scaleY:size},170,'Back.easeOut');await this._burst(bird.x,bird.y-25,COL.gold);
      }else if(event.kind==='shield'){
        this.shield.clear();this.shield.lineStyle(5,0x88dfec,.85);this.shield.fillStyle(0x88dfec,.18);this.shield.fillEllipse(this.hero.x,this.hero.y-65*this.hero.scaleX,165*this.hero.scaleX,210*this.hero.scaleY);this.shield.strokeEllipse(this.hero.x,this.hero.y-65*this.hero.scaleX,165*this.hero.scaleX,210*this.hero.scaleY);await this._floating(this.hero.x,this.hero.y-95,'Bouclier !','#b8f3fc');
      }else await this._floating(this.hero.x,this.hero.y-95,event.kind==='energy'?'+'+event.amount+' énergie':'+'+event.amount+' PV',event.kind==='heal'?'#c5f7ac':'#fff1ce');
    }
    async animate(events,oldRun,newRun){
      if(this._destroyed||!this.scene)return;
      this._counts.animations++;
      // Reduced motion and hidden tabs apply the result immediately, without waiting.
      if(this._reduced||this._paused||document.hidden){if(newRun)this.update({...this.state,run:newRun});return;}
      this._animations++;this._wake(1000);
      try{
        if(this.mode==='race'){
          const event=(events||[]).find(e=>e.kind==='jump'||e.kind==='stumble');
          if(event){
            const oldX=this._raceX(oldRun?.distance||0,oldRun?.total||6),nextX=this._raceX((oldRun?.distance||0)+event.amount,oldRun?.total||6),ground=this.height*.8;
            this.hero.setPosition(oldX,ground);const nextRival=this._raceX((oldRun?.rival||0)+105,oldRun?.total||6);
            const rival=this._tween(this.enemy,{x:nextRival},360,'Linear');
            if(event.kind==='jump'){
              const move=this._tween(this.hero,{x:nextX},360,'Linear');await this._tween(this.hero,{y:ground-60*clamp(this.width/700,.65,1)},180,'Sine.easeOut');await this._tween(this.hero,{y:ground},180,'Sine.easeIn');await Promise.all([move,rival]);await this._burst(nextX,ground-5,COL.gold);
            }else{
              await this._tween(this.hero,{x:nextX,angle:22},220,'Sine.easeOut');await this._tween(this.hero,{angle:0},140);await rival;await this._floating(nextX,ground-65,'Oups !','#fff1ce');
            }
          }
        }else if(this.mode==='arena'){
          // Friendly effects are grouped; Nox then responds. A full turn stays below a second.
          const friendly=(events||[]).filter(e=>e.kind!=='enemy');
          await Promise.all(friendly.map(event=>this._friendlyEvent(event)));
          if(!this._destroyed&&!this._paused&&!document.hidden){const enemy=(events||[]).find(e=>e.kind==='enemy');if(enemy)await this._projectile(this.enemy,this.hero,enemy.amount,COL.lavender);}
        }
      }finally{
        this._animations=Math.max(0,this._animations-1);
        if(newRun)this.update({...this.state,run:newRun});
        this._wake(100);
      }
    }
    resize(){
      if(this._destroyed||!this.scene)return;
      const width=Math.max(280,Math.round(this.host.clientWidth||this._lastWidth)),height=Math.max(240,Math.round(this.host.clientHeight||this._lastHeight));
      if(width===this._lastWidth&&height===this._lastHeight)return;
      this._lastWidth=width;this._lastHeight=height;this.game.scale.resize(width,height);this._paintBackdrop();this._layoutMode(false);this._wake(160);
    }
    get width(){return this._lastWidth;}
    get height(){return this._lastHeight;}
    metrics(){return {...this._counts,mode:this.mode,sleeping:!this.game?.loop.running,objects:this.scene?.children?.list?.length||0,worldObjects:this._objectCount(this.layers),textures:this.scene?.textures?.getTextureKeys()?.length||0,animationsActive:this._animations};}
    getMetrics(){return this.metrics();}
    _objectCount(container){if(!container)return 0;return 1+(container.list||[]).reduce((n,obj)=>n+(obj.list?this._objectCount(obj):1),0);}
    destroy(){
      if(this._destroyed)return;this._destroyed=true;clearTimeout(this._sleepTimer);cancelAnimationFrame(this._resizeRaf);this._resizeObserver?.disconnect();this._events.forEach(off=>off());this._events=[];
      this._animationResolvers.forEach(resolve=>resolve());this._animationResolvers.clear();this.scene?.tweens?.killAll();this.game?.destroy(true);this.pointers.clear();this.buildings.clear();this.scene=null;this.game=null;
    }
  }
  window.LumeriaWorld={async mount(host,state,callbacks){const controller=new Controller(host,state,callbacks);await controller.start();return controller;},project};
})();
