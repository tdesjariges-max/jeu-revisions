# Luméria — original cartoon art

This pack was drawn specifically for BAC DOMINION. All SVG artwork in this folder is original; no game art, characters, logos, screenshots or third-party asset files have been copied into the game.

## Public visual references actually consulted

- [Clash of Clans — Supercell official presentation](https://supercell.com/en/games/clashofclans/) — page retrieved successfully; its official gameplay illustration `https://supercell.com/images/e6f04ebde8a85ae7d5f9a0a851e664fa/bg_intro_clashofclans.134fece1.webp` was downloaded into a temporary research directory and visually inspected. Useful principles: readable isometric silhouettes, generous spacing between interactive buildings, a consistent light direction and clear distinctions between production, military and defensive buildings. No assets or protected visual designs were reused.
- [Kingdom Rush — Ironhide official presentation](https://www.kingdomrush.com/) — page retrieved successfully; `https://kingdomrush.com/img/posters-juegos/KR_800x604.jpg` was downloaded into a temporary research directory and visually inspected. Useful principles: expressive cartoon faces, strong outlines, exaggerated friendly proportions and a small set of contrasting colors. No characters or illustrations were reused.
- `https://kenney.nl/assets/isometric-buildings` was attempted but returned HTTP 403 in this environment; it was not used as a viewed reference.

Internet requests retained the configured cloud proxy and TLS verification. Reference images remain outside the shipped project.

## Art direction

Warm cream, ink-purple outlines, lavender, bright grass, coral, honey-gold and sky blue. Rounded expressive characters and distinct small building silhouettes replace monochrome geometry and emoji placeholders. Shadows are simple vector ellipses; gradients are local SVG definitions, with no expensive blur/filter effects and no external network resources.

## Asset contract

- `building-*.svg`: 240 × 240, shared bottom-center ground anchor approximately (120, 218).
- `hero.svg` and `hero-{teal,violet,gold}.svg`: 160 × 200, feet at (80, 190), head centered approximately (80, 67). Base artwork has short hair and no cape; renderer overlays preserve hairstyle/cape customization.
- `dragon.svg`: 240 × 240, ground at (120, 220).
- `griffin.svg`: 160 × 160, ground at (80, 148).
- `tree.svg`: 160 × 200, ground at (80, 190).
- `rock.svg`: 120 × 100, ground at (60, 90).
- `icon-*.svg`: 64 × 64; `card-*.svg` reuse the same original motifs, except the larger griffin artwork.
- `island.svg`: 1200 × 760, standalone landing illustration assembled from the original sprites, without labels or UI text. It can be used as a normal image; it requires no JavaScript or animation loop.

Each SVG is self-contained. No SVG filter, embedded raster image, font or external link is required. Scene textures should be cached once and drawn from the cache during gameplay rather than rebuilding SVG markup every frame.
