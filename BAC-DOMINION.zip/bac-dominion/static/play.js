/* Luméria: Phaser rendering. Only server responses change persistent game state. */
'use strict';
const $ = s => document.querySelector(s);
const escapeHTML = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const S = {mode:'kingdom', profile:null, play:null, run:null, selected:null, moving:false, construct:null, busy:false, result:null};
const names = {academy:'Académie royale',mine:'Mine d’or',sawmill:'Scierie enchantée',quarry:'Carrière',barracks:'Caserne',wall:'Remparts'};
const palette = {teal:0x218878,violet:0x875db3,gold:0xe4aa40};
const cardArt={focus:'<path d="M15 45Q22 12 70 10Q75 48 42 53Z" fill=#9cdbad/><path d="M23 48L65 18" stroke=#eaf0bf stroke-width=4/>',spark:'<circle cx=45 cy=27 r=15 fill=#ffd579/><path d="M25 6L19 1M68 5L73 0M18 29H7M72 29H83M28 47L22 55M64 46L72 54" stroke=#ffda86 stroke-width=3/>',ward:'<path d="M45 2L70 12L66 36L45 57L24 36L20 12Z" fill=#91d5ce stroke=#e1efdb stroke-width=3/><path d="M45 13V44M32 28H58" stroke=#fff5c9 stroke-width=4/>',griffin:'<path d="M21 44L9 6L42 27L64 16L66 38L81 41L64 52Z" fill=#f3d39b/><circle cx=62 cy=29 r=3 fill=#173e43/><path d="M67 24L80 29L67 33Z" fill=#d69a50/>',heal:'<path d="M45 2Q78 36 63 50Q45 65 27 50Q12 36 45 2Z" fill=#7ed6c4/><path d="M45 22V45M34 34H56" stroke=#f4f3cb stroke-width=5/>',nova:'<path d="M45 0L53 19L76 12L62 32L81 48L57 45L45 62L35 44L9 49L27 31L15 12L37 19Z" fill=#dfb1e5/><circle cx=45 cy=32 r=11 fill=#fff0c3/>'};
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
let scene, game;
async function api(path, data) {
  const response = await fetch('/api/'+path, {method:data===undefined?'GET':'POST', headers:{'Content-Type':'application/json'}, body:data===undefined?undefined:JSON.stringify(data)});
  const value = await response.json();
  if(!response.ok) throw new Error(typeof value.detail==='string'?value.detail:'Action impossible. Vérifie les champs.');
  return value;
}
function message(text){$('#feedback').textContent=text;}
async function busy(fn){if(S.busy)return;S.busy=true;controls();try{await fn();}catch(e){message(e.message);}finally{S.busy=false;controls();if(!S.result)document.querySelectorAll('#answers button').forEach(b=>b.disabled=false);}}
async function refresh(){S.profile=await api('me');S.play=await api('play');$('#resources').textContent=`${S.profile.username} · Or ${S.profile.gold} · Bois ${S.profile.wood} · Pierre ${S.profile.stone} · ${S.profile.score} points`;}
function texture(sc, key, draw, w=100,h=120){if(sc.textures.exists(key))return;const g=sc.make.graphics({x:0,y:0,add:false});draw(g);g.generateTexture(key,w,h);g.destroy();}
function avatarTexture(sc, avatar, key){texture(sc,key,g=>{
 const c=palette[avatar.color];
 if(avatar.cape){g.fillStyle(0x4c3b6d);g.fillTriangle(29,39,13,94,64,94);}
 g.fillStyle(0x203d50);g.fillRoundedRect(25,72,13,26,5);g.fillRoundedRect(45,72,13,26,5);
 g.fillStyle(c);g.fillRoundedRect(20,40,44,42,13);g.fillStyle(0xffd4a1);g.fillCircle(42,29,20);g.fillRoundedRect(13,48,9,28,4);g.fillRoundedRect(63,48,9,28,4);
 g.fillStyle(0x513c3f);g.fillRoundedRect(21,8,41,17,8);
 if(avatar.hair==='crest')g.fillTriangle(31,12,38,0,53,16);
 if(avatar.hair==='long'){g.fillRect(20,16,9,30);g.fillRect(55,16,9,30);}
 g.fillStyle(0x193b42);g.fillCircle(35,29,2);g.fillCircle(49,29,2);g.lineStyle(2,0xa15c50);g.lineBetween(37,38,46,38);
},85,105);}
function buildingTexture(sc,key,type,level){texture(sc,key,g=>{
 const tier=Math.min(5,Math.floor(level/5)), roof=type==='academy'?0x9672ba:type==='barracks'?0xbd665b:0x438879;
 g.fillStyle(0x365b4b,.18);g.fillEllipse(60,117,108,25);
 g.fillStyle(0xc7af83);g.fillPoints([{x:10,y:70},{x:64,y:90},{x:112,y:65},{x:112,y:102},{x:64,y:128},{x:10,y:105}],true);
 g.fillStyle(0xf3ddaa);g.fillPoints([{x:10,y:55},{x:64,y:76},{x:64,y:112},{x:10,y:91}],true);
 g.fillStyle(0xd0b782);g.fillPoints([{x:64,y:76},{x:112,y:51},{x:112,y:89},{x:64,y:112}],true);
 g.fillStyle(roof);g.fillPoints([{x:2,y:56},{x:54,y:17-tier*2},{x:120,y:51},{x:64,y:83}],true);
 g.lineStyle(2,0xffffff,.2);g.lineBetween(54,18,64,82);
 g.fillStyle(0x35555b);g.fillRoundedRect(30,72,18,27,6);g.fillStyle(0xffd974);g.fillRect(78,78,10,13);g.fillRect(96,68,9,13);
 if(type==='mine'||type==='quarry'){g.fillStyle(type==='mine'?0xf5c15c:0x8fa9ae);g.fillTriangle(75,105,88,80,106,112);g.fillTriangle(8,112,20,97,37,122);}
 if(type==='sawmill'){g.fillStyle(0x735540);g.fillRoundedRect(72,102,38,10,5);g.fillStyle(0xddb886);g.fillCircle(105,107,6);}
 if(type==='wall'){g.fillStyle(0xabbec1);for(let i=0;i<4;i++)g.fillRect(15+i*25,55+i*2,17,14);}
 if(type==='academy'){g.fillStyle(0xdbc18f);g.fillRect(48,1,14,30);g.fillStyle(roof);g.fillTriangle(43,4,55,0,68,4);g.fillStyle(0xfce18c);g.fillCircle(55,13,4);}
 for(let i=0;i<tier;i++){g.fillStyle(0xffe8a1);g.fillCircle(22+i*17,63,3);}
 },125,140);}
class World extends Phaser.Scene {
 constructor(){super('world');}
 create(){scene=this;this.board=this.add.container();this.camera=this.cameras.main;this.input.on('pointermove',p=>{if(S.mode==='kingdom'&&p.isDown&&!S.moving&&!S.construct){this.camera.scrollX-=(p.x-p.prevPosition.x)/this.camera.zoom;this.camera.scrollY-=(p.y-p.prevPosition.y)/this.camera.zoom;}});this.input.on('wheel',(_p,_o,_x,y)=>{if(S.mode==='kingdom')this.camera.setZoom(Phaser.Math.Clamp(this.camera.zoom-y*.001,.4,1.6));});this.scale.on('resize',()=>this.redraw());this.redraw();}
 clear(){this.tweens.killAll();this.board.removeAll(true);this.camera.setScroll(0,0).setZoom(1);}
 text(x,y,t,size=16,color='#234b46'){const label=this.add.text(x,y,t,{fontFamily:'Georgia',fontSize:size,color,align:'center'}).setOrigin(.5);this.board.add(label);return label;}
 redraw(){this.clear();if(!S.play)return;if(S.mode==='kingdom')this.kingdom();else if(S.mode==='arena')this.arena();else this.race();}
 kingdom(){
 const w=this.scale.width,h=this.scale.height;this.camera.setBounds(-w/2,-h/2,w*2,h*2);this.camera.setZoom(Math.max(.4,Math.min(1,(w-20)/760,(h-20)/380)));this.camera.setBackgroundColor('#9ac8aa');
 const tile=38, baseX=w/2,baseY=40;
 const grid=this.add.graphics();this.board.add(grid);
 for(let y=0;y<10;y++)for(let x=0;x<12;x++){
 const px=baseX+(x-y)*tile*.9-30,py=baseY+(x+y)*tile*.42;
 grid.fillStyle((x+y)%2?0x86b68c:0x92c095);grid.lineStyle(1,0xc2daa7,.35);const points=[{x:px,y:py-16},{x:px+34,y:py},{x:px,y:py+16},{x:px-34,y:py}];grid.fillPoints(points,true);grid.strokePoints(points,true);
 const hit=this.add.zone(px,py,65,29).setInteractive();this.board.add(hit);hit.on('pointerup',()=>{if(S.moving||S.construct)place(x,y);});
 }
 this.text(w/2,21,'LA CLAIRIÈRE DES PREMIÈRES LUMIÈRES',12);
 const entries=Object.entries(S.play.layout).sort((a,b)=>(a[1].x+a[1].y)-(b[1].x+b[1].y));
 for(const [id,pos] of entries){const type=id.replace('_annex',''),level=S.profile.buildings[type],key=`building-${type}-${level}`;buildingTexture(this,key,type,level);
 const px=baseX+(pos.x-pos.y)*tile*.9-30,py=baseY+(pos.x+pos.y)*tile*.42;
 const image=this.add.image(px,py+12,key).setOrigin(.5,1).setScale(.68).setInteractive({useHandCursor:true});this.board.add(image);if(S.selected===id)image.setTint(0xffdf82);
 image.on('pointerup',()=>{if(S.moving||S.construct){place(pos.x,pos.y);return;}S.selected=id;controls();this.redraw();});
 }
 avatarTexture(this,S.play.avatar,'avatar-'+JSON.stringify(S.play.avatar));this.hero=this.add.image(w*.18,h*.72,'avatar-'+JSON.stringify(S.play.avatar)).setScale(.7);this.board.add(this.hero);
 for(let i=0;i<7;i++){const x=25+(i*173)%(w-40),y=h-25-(i%3)*22;const tree=this.add.graphics();tree.fillStyle(0x74583f);tree.fillRect(x-3,y-24,6,28);tree.fillStyle(i%2?0x377361:0x568c65);tree.fillTriangle(x,y-70,x-24,y-15,x+24,y-15);this.board.add(tree);}
 }
 arena(){
 const w=this.scale.width,h=this.scale.height;this.camera.setBackgroundColor('#345861');const g=this.add.graphics();this.board.add(g);g.fillStyle(0xbeb88b);g.fillEllipse(w/2,h*.7,w*.92,h*.42);g.lineStyle(4,0xead3a0);g.strokeEllipse(w/2,h*.7,w*.92,h*.42);
 avatarTexture(this,S.play.avatar,'avatar-'+JSON.stringify(S.play.avatar));avatarTexture(this,{color:'violet',hair:'crest',cape:true},'nox');this.hero=this.add.image(w*.22,h*.63,'avatar-'+JSON.stringify(S.play.avatar)).setScale(1.15);this.enemy=this.add.image(w*.78,h*.55,'nox').setScale(1.4);this.board.add([this.hero,this.enemy]);
 const r=S.run;this.text(w*.22,h*.88,`TOI · ${r?.hp??100} PV`,18,'#fff4d4');this.text(w*.78,h*.88,`NOX · ${r?.enemy_hp??85} PV`,18,'#fff4d4');this.text(w/2,35,'LE CERCLE DES MANUSCRITS',17,'#fce9bc');
 if(r?.shield){g.lineStyle(4,0x8be4e2);g.strokeCircle(w*.22,h*.63,70);}
 for(let i=0;i<(r?.creatures||0);i++){const bird=this.add.graphics();bird.fillStyle(0xf8dc94);bird.fillEllipse(w*.4+i*45,h*.54,32,18);bird.fillTriangle(w*.4-7+i*45,h*.54,w*.4-25+i*45,h*.45,w*.4+10+i*45,h*.54);this.board.add(bird);}
 }
 race(){
 const w=this.scale.width,h=this.scale.height;this.camera.setBackgroundColor('#b6ded7');const g=this.add.graphics();this.board.add(g);g.fillStyle(0x91bfa1);for(let i=0;i<5;i++)g.fillTriangle(i*w/4-60,h*.65,i*w/4+75,h*.14,i*w/4+210,h*.65);g.fillStyle(0x71966b);g.fillRect(0,h*.66,w,h*.34);g.fillStyle(0xd8c59d);g.fillRect(0,h*.7,w,38);g.fillRect(0,h*.88,w,25);
 avatarTexture(this,S.play.avatar,'avatar-'+JSON.stringify(S.play.avatar));avatarTexture(this,{color:'violet',hair:'long',cape:false},'runner');const r=S.run,max=Math.max(1,r?.total||6)*150;
 this.hero=this.add.image(30+(w-85)*(r?.distance||0)/max,h*.7,'avatar-'+JSON.stringify(S.play.avatar)).setOrigin(.5,1).setScale(.63);this.enemy=this.add.image(30+(w-85)*(r?.rival||0)/max,h*.88,'runner').setOrigin(.5,1).setScale(.6);this.board.add([this.hero,this.enemy]);
 for(let i=1;i<=6;i++){const x=30+(w-85)*i/7;g.fillStyle(i%2?0x84606b:0x7b8885);g.fillRoundedRect(x,h*.7-27,16,27,4);g.fillStyle(0xf8d38e);g.fillRect(x-4,h*.7-30,24,7);}
 g.fillStyle(0xfaf2d8);g.fillRect(w-35,h*.3,4,h*.4);g.fillStyle(0x46776b);g.fillTriangle(w-31,h*.3,w-4,h*.34,w-31,h*.39);
 this.text(w/2,35,'LA COURSE DES ÎLES VERTES',17);this.text(w/2,64,`Une question par obstacle · ${r?.total||6} étapes`,13);
 }
 async animate(events,oldRun){
 const duration=reduceMotion?1:650;
 for(const e of events){
 if(e.kind==='jump'||e.kind==='stumble'){
   const startX=30+(this.scale.width-85)*(oldRun.distance||0)/(Math.max(1,oldRun.total)*150);
   this.hero.x=startX;const ground=this.hero.y;
   this.tweens.add({targets:this.hero,y:ground-(e.kind==='jump'?80:8),angle:e.kind==='stumble'?35:0,duration:duration/2,yoyo:true,ease:'Sine.easeOut'});
   this.tweens.add({targets:this.hero,x:startX+(this.scale.width-85)*e.amount/(Math.max(1,oldRun.total)*150),duration});
 }else if(e.kind==='projectile'||e.kind==='enemy'||e.kind==='creature'){
   const from=e.kind==='enemy'?this.enemy:this.hero,to=e.kind==='enemy'?this.hero:this.enemy;
   const orb=this.add.circle(from.x,from.y,9,e.kind==='enemy'?0xc69be5:0xffd57a);this.board.add(orb);
   this.tweens.add({targets:orb,x:to.x,y:to.y,duration:duration*.7,onComplete:()=>{orb.destroy();const label=this.text(to.x,to.y-55,'−'+e.amount,26,'#fff0b7');this.tweens.add({targets:label,y:label.y-40,alpha:0,duration,onComplete:()=>label.destroy()});}});
 }else{const label=this.text(this.hero.x,this.hero.y-70,e.kind==='summon'?'Griffon invoqué':'+'+e.amount,22,'#fff0b7');this.tweens.add({targets:label,y:label.y-30,alpha:0,duration});}
 }
 await new Promise(r=>setTimeout(r,reduceMotion?20:1100));this.redraw();
 }
}
function button(text,fn,disabled=false,cls=''){const b=document.createElement('button');b.textContent=text;b.className=cls;b.disabled=disabled;b.onclick=fn;return b;}
function controls(){
 if(!S.play)return;const c=$('#controls');c.replaceChildren();$('#scene-title').textContent={kingdom:'La clairière royale',arena:'Le duel des manuscrits',race:'La course des îles vertes'}[S.mode];
 $('#abandon').hidden=!S.run||S.run.finished||S.mode==='kingdom';
 document.querySelectorAll('[data-mode]').forEach(b=>b.setAttribute('aria-pressed',b.dataset.mode===S.mode));
 $('#stats').textContent=S.mode==='kingdom'?`${S.profile.kingdom.knowledge} notions maîtrisées` : S.run?S.mode==='arena'?`Énergie ${S.run.energy}/10 · Bouclier ${S.run.shield} · Tour ${Math.min(S.run.step+1,S.run.total)}/${S.run.total}`:`Toi ${S.run.distance} m · Maë ${S.run.rival} m`:'';
 if(S.mode==='kingdom'){
 $('#help').textContent=S.construct?'Choisis une case libre pour construire ton annexe (60 or, 40 bois, 20 pierre). Elle augmente la production du bâtiment correspondant.':S.moving?'Touche une case libre pour y déplacer le bâtiment.':'Touche un bâtiment pour le sélectionner. Glisse pour déplacer la caméra. Les commandes sont aussi disponibles ci-dessous.';
 c.append(button('−',()=>scene.camera.setZoom(Math.max(.4,scene.camera.zoom-.15))),button('+',()=>scene.camera.setZoom(Math.min(1.6,scene.camera.zoom+.15))));
 const select=document.createElement('select');select.setAttribute('aria-label','Sélectionner un bâtiment');select.innerHTML='<option value="">Choisir un bâtiment</option>'+Object.keys(S.play.layout).map(id=>`<option value="${id}" ${S.selected===id?'selected':''}>${names[id.replace('_annex','')]}${id.endsWith('_annex')?' · annexe':''}</option>`).join('');select.onchange=()=>{S.selected=select.value;scene.redraw();controls();};c.append(select);
 if(S.selected){const type=S.selected.replace('_annex',''),level=S.profile.buildings[type];c.append(button('Déplacer',()=>{S.moving=true;S.construct=null;controls();},S.busy));c.append(button(`Améliorer · niv. ${level} → ${level+1}`,()=>busy(async()=>{const r=await api('upgrade',{building:type});message(r.message);await refresh();scene.redraw();}),S.busy||level>=10));}
 for(const type of ['mine','sawmill','quarry'])c.append(button('Construire : '+names[type],()=>{S.construct=type;S.moving=false;controls();},S.busy||Boolean(S.play.layout[type+'_annex'])));
 if(S.moving||S.construct)c.append(button('Annuler',()=>{S.moving=false;S.construct=null;controls();}));
 c.append(button('Récolter / actualiser',()=>busy(async()=>{await refresh();message('Production récoltée. Les fractions sont conservées jusqu’à la prochaine unité entière.');}),S.busy));
 }else{
 $('#help').textContent=S.mode==='arena'?'Choisis une carte, puis réponds. Une erreur consomme son énergie. Nox riposte ; tes griffons attaquent à chaque tour. Répéter une question déjà réussie ne rapporte plus de points dans ces scènes.':'Réponds pour sauter au-dessus de chaque obstacle. Une erreur déclenche une chute cartoon et un ralentissement. Le déplacement et le résultat sont validés par le serveur.';
 if(!S.run||S.run.finished){c.append(button(S.run?'Rejouer':'Commencer',()=>busy(async()=>{S.run=await api('play/start',{mode:S.mode});S.result=null;message('');question();scene.redraw();}),S.busy));if(S.run?.finished)message(`${S.run.won?'Victoire !':'Parcours terminé.'} ${S.run.correct}/${S.run.total} réponses justes. Consulte la correction avant de rejouer.`);}
 else if(!S.run.pending&&!S.result){
 if(S.mode==='race')c.append(button('Aborder l’obstacle suivant',()=>choose('jump'),S.busy));
 else for(const [id,card] of Object.entries(S.play.cards)){const b=button('',()=>choose(id),S.busy||card.cost>S.run.energy||(id==='griffin'&&S.run.creatures>=2),'card');b.innerHTML=`<svg viewBox="0 0 90 64" width="84" height="60" aria-hidden="true">${cardArt[id]}</svg><div class="cost">${card.cost} énergie · ${escapeHTML(card.kind)}</div><b>${escapeHTML(card.name)}</b><span>${escapeHTML(card.text)}</span>`;c.append(b);}
 }
 }
}
async function place(x,y){await busy(async()=>{S.play={...S.play,...await api('play/place',{building:S.construct||S.selected,x,y,construct:Boolean(S.construct)})};S.moving=false;S.construct=null;await refresh();scene.redraw();message('Royaume sauvegardé.');});}
async function choose(card){await busy(async()=>{S.run=await api('play/action',{run_id:S.run.run_id,step:S.run.step,card});question();});}
function question(){const target=$('#question');target.replaceChildren();target.hidden=S.mode==='kingdom'||!S.run?.pending;if(target.hidden)return;const q=S.run.question;const heading=document.createElement('h3');heading.textContent=q.q;const meta=document.createElement('p');meta.textContent=[q.category,q.theme,q.subaxis].filter(Boolean).join(' · ');target.append(meta,heading);const answers=document.createElement('div');answers.id='answers';q.options.forEach((option,choice)=>answers.append(button(option,()=>submitAnswer(choice),S.busy)));target.append(answers);}
async function submitAnswer(choice){await busy(async()=>{
 const old={...S.run};document.querySelectorAll('#answers button').forEach(b=>b.disabled=true);
 const r=await api('play/answer',{run_id:S.run.run_id,step:S.run.step,choice});S.result=r;
 const answerButtons=document.querySelectorAll('#answers button');answerButtons.forEach((b,i)=>{b.classList.toggle('correct',i===r.correct_index);b.classList.toggle('wrong',i===choice&&!r.correct);});
 await scene.animate(r.events,old);S.run=r.run;await refresh();scene.redraw();
 const note=document.createElement('p');note.textContent=(r.correct?'Bonne réponse. ':'À retravailler. ')+r.explanation;$('#question').append(note);
 const reward=Object.values(r.reward).reduce((a,b)=>a+b,0);message(`${r.correct?'Action réussie !':'Action manquée.'} +${r.earned.score} points, +${r.earned.xp} XP.${reward?' Butin sauvegardé : '+r.reward.gold+' or, '+r.reward.wood+' bois, '+r.reward.stone+' pierre.':''}`);
 $('#question').append(button(r.run.finished?'Voir le résultat':'Continuer',()=>{S.result=null;question();controls();}));
 });}
async function switchMode(mode){if(S.busy)return;if(S.run&&!S.run.finished&&mode!==S.run.mode&&mode!=='kingdom'){message('Une partie est en cours. Termine-la ou abandonne-la avant de changer de jeu.');return;}if(S.run?.finished&&S.run.mode!==mode)S.run=null;S.mode=mode;S.result=null;S.moving=false;S.construct=null;scene.redraw();controls();question();}
$('#abandon').onclick=()=>busy(async()=>{await api('play/abandon',{});S.run=(await api('play')).run;S.result=null;scene.redraw();question();});
$('#avatar-form').onsubmit=e=>{e.preventDefault();const f=new FormData(e.target);busy(async()=>{S.play.avatar=await api('play/avatar',{color:f.get('color'),hair:f.get('hair'),cape:f.has('cape')});scene.redraw();message('Avatar sauvegardé.');});};
let rows=[],focus={};const levels=['subject','theme','axis','subaxis'];
function focusFields(){const root=$('#focus-fields');root.replaceChildren();levels.forEach((key,index)=>{const label=document.createElement('label');label.textContent=['Matière','Thème','Axe / chapitre','Sous-axe / notion'][index];const select=document.createElement('select');select.name=key;select.innerHTML='<option value="">Tout</option>';const candidates=rows.filter(r=>levels.slice(0,index).every(k=>!focus[k]||r[k]===focus[k]));[...new Set(candidates.map(r=>r[key]))].sort().forEach(v=>{const o=document.createElement('option');o.value=v;o.textContent=v;select.append(o);});select.value=focus[key]||'';select.disabled=index>0&&!focus[levels[index-1]];select.onchange=()=>{focus[key]=select.value;levels.slice(index+1).forEach(k=>focus[k]='');focusFields();};label.append(select);root.append(label);});const extras=document.createElement('div');extras.innerHTML='<label>Difficulté <select id=study-difficulty><option value=0>Toutes</option>'+[1,2,3,4,5].map(n=>`<option value=${n}>${n} / 5</option>`).join('')+'</select></label><label><input id=study-weak type=checkbox> Uniquement mes erreurs (scènes 2D)</label>';root.append(extras);$('#study-difficulty').value=S.play.study.difficulty;$('#study-weak').checked=S.play.study.weak_only;$('#study-difficulty').onchange=e=>S.play.study.difficulty=Number(e.target.value);$('#study-weak').onchange=e=>S.play.study.weak_only=e.target.checked;const count=rows.filter(r=>levels.every(k=>!focus[k]||r[k]===focus[k])).reduce((n,r)=>n+r.count,0);$('#focus-count').textContent=count+' questions dans cette sélection. Couverture partielle ; les thèmes à zéro sont à compléter. Contenu 2027 à vérifier.';$('#focus-form button[type=submit]').disabled=!count;}
$('#revision').onclick=()=>busy(async()=>{const catalog=await api('study/catalog');rows=catalog.rows;focus={...S.profile.focus};focusFields();$('#focus-dialog').showModal();});
$('#revision-nav').onclick=()=>$('#revision').click();
$('#close-focus').onclick=()=>$('#focus-dialog').close();
$('#focus-form').onsubmit=e=>{e.preventDefault();busy(async()=>{await api('focus',focus);await api('play/study',S.play.study);await refresh();$('#focus-dialog').close();message('Révision enregistrée pour la prochaine partie.');});};
document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>switchMode(b.dataset.mode));
(async()=>{try{await refresh();S.run=S.play.run;if(S.run&&!S.run.finished)S.mode=S.run.mode;$('#workspace').hidden=false;const avatar=S.play.avatar;$('#avatar-form [name=color]').value=avatar.color;$('#avatar-form [name=hair]').value=avatar.hair;$('#avatar-form [name=cape]').checked=avatar.cape;
 game=new Phaser.Game({type:Phaser.CANVAS,parent:'game',width:$('#game').clientWidth,height:$('#game').clientHeight,transparent:false,scale:{mode:Phaser.Scale.RESIZE},scene:World,render:{antialias:true},input:{activePointers:2}});controls();question();
 }catch(e){$('#login').hidden=false;$('#login p').textContent=e.message+' Connecte-toi dans les modes classiques pour retrouver ton compte.';$('#avatar-panel').hidden=true;$('#revision').disabled=true;document.querySelectorAll('[data-mode]').forEach(b=>b.disabled=true);}})();
