"""Navigable program outline. This is a working outline, not certified official coverage."""
THEMES = {
    'HGGSP': ['De nouveaux espaces de conquête','Faire la guerre, faire la paix','Histoire et mémoires',
              'Identifier, protéger et valoriser le patrimoine','L’environnement, entre exploitation et protection','L’enjeu de la connaissance'],
    'SVT': ['Génétique et évolution','À la recherche du passé géologique de notre planète',
            'De la plante sauvage à la plante domestiquée','Les climats de la Terre',
            'Comportements, mouvement et système nerveux',
            'Produire le mouvement : contraction musculaire et apport d’énergie',
            'Comportements et stress : vers une vision intégrée de l’organisme'],
    'Philosophie': ['L’art','Le bonheur','La conscience','Le devoir','L’État','L’inconscient','La justice',
                    'Le langage','La liberté','La nature','La raison','La religion','La science','La technique','Le temps','Le travail','La vérité'],
    'Histoire-géographie': ['Fragilités des démocraties, totalitarismes et Seconde Guerre mondiale',
        'La multiplication des acteurs internationaux dans un monde bipolaire',
        'Les remises en cause économiques, politiques et sociales des années 1970 à 1991',
        'Le monde, l’Europe et la France depuis les années 1990',
        'Mers et océans : au cœur de la mondialisation',
        'Dynamiques territoriales, coopérations et tensions dans la mondialisation',
        'L’Union européenne dans la mondialisation','La France et ses régions dans l’Union européenne et dans la mondialisation'],
    'Enseignement scientifique': ['Science, climat et société','Le futur des énergies','Une histoire du vivant'],
    'Anglais': ['Identités et échanges','Espace privé et espace public','Art et pouvoir','Citoyenneté et mondes virtuels',
                'Fictions et réalités','Innovations scientifiques et responsabilité','Diversité et inclusion','Territoire et mémoire'],
    'Espagnol': ['Identités et échanges','Espace privé et espace public','Art et pouvoir','Citoyenneté et mondes virtuels',
                'Fictions et réalités','Innovations scientifiques et responsabilité','Diversité et inclusion','Territoire et mémoire'],
    'EMC': ['La démocratie'],
}

SOURCES = {
    'status': 'not_verified_in_this_environment',
    'notice': 'Banque originale d’entraînement : au moins 50 questions par chapitre affiché. Relecture enseignante et applicabilité des programmes 2027 à vérifier ; aucune certification officielle.',
    'official_urls': ['https://www.education.gouv.fr','https://eduscol.education.gouv.fr',
        'https://eduscol.education.gouv.fr/1676/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g'],
    'hggsp_written_2027_user_supplied': [2,4,5,6],
    'hggsp_written_2027_verified': False,
}


def catalog(questions):
    groups={}
    for q in questions:
        key=(q['category'],q['theme'],q['axis'],q['subaxis'],q['difficulty'])
        groups[key]=groups.get(key,0)+1
    rows=[dict(subject=k[0],theme=k[1],axis=k[2],subaxis=k[3],difficulty=k[4],count=n) for k,n in sorted(groups.items())]
    covered={(r['subject'],r['theme']) for r in rows}
    for subject,themes in THEMES.items():
        for theme in themes:
            if (subject,theme) not in covered:
                rows.append(dict(subject=subject,theme=theme,axis='Contenu à compléter',subaxis='Questions à rédiger',difficulty=0,count=0))
    chapters={}
    for q in questions:
        key=(q['category'],q['theme'],q['axis'])
        chapters[key]=chapters.get(key,0)+1
    chapter_rows=[dict(subject=s,theme=t,axis=a,count=n) for (s,t,a),n in sorted(chapters.items())]
    return {'rows':rows,'chapters':chapter_rows,'minimum_per_chapter':min(chapters.values(),default=0),'sources':SOURCES,'course_count':len(questions),
            'reviewed_count':sum(q['validation']=='reviewed' for q in questions)}
